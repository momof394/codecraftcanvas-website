# BodyDouble Orb - Mental Health & Wellness App

A compassionate mental health and wellness web application designed for neurodivergent individuals, featuring mood tracking, breathing exercises, journaling, and task management.

## 🌟 Features

- **Mood Tracking**: Simple 1-5 scale mood entries with optional notes
- **Breathing Exercises**: 4-7-8 and box breathing techniques with guided animations
- **Brain Dump Journaling**: Auto-saving text editor for stream-of-consciousness writing
- **Task Management**: Gentle task tracking with positive reinforcement
- **Self-Care Activities**: Grounding exercises and gentle reminders
- **Ambient Sounds**: Nature sounds for focus and relaxation

## 🚀 Static Deployment (No Server Required)

This application has been converted to work as a client-only static site using localStorage for data persistence.

### Build for Production

```bash
npm run build
```

This creates a static build in `client/dist/` that can be deployed to any static hosting service.

### Deploy to Static Hosting

The built files in `client/dist/` can be deployed to:

- **Netlify**: Drag and drop the `client/dist` folder
- **Vercel**: Connect your repository and set build output to `client/dist`
- **GitHub Pages**: Upload the contents of `client/dist` to your GitHub Pages repository
- **Surge.sh**: Run `surge client/dist` after installing surge globally
- **Any static web server**: Serve the files from `client/dist/`

### Local Testing

Test the production build locally:

```bash
cd client/dist
python3 -m http.server 8080
# or with Node.js
npx serve .
```

Then visit `http://localhost:8080`

## 🛠️ Development

For development with hot reload:

```bash
npm run dev
```

## 📁 Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── pages/         # Application pages
│   │   ├── lib/           # Utilities and localStorage adapter
│   │   └── hooks/         # Custom React hooks
│   └── dist/              # Production build output
├── shared/                # Shared TypeScript schemas
└── server/                # Backend (not used in static deployment)
```

## 💾 Data Storage

In static deployment mode, all data is stored locally in the browser's localStorage:

- **Mood Entries**: Your mood tracking history
- **Journal Entries**: Personal journal entries
- **Tasks**: Task list and completion status  
- **Settings**: User preferences and app settings

**Note**: Data is tied to the specific browser and domain. Clearing browser data will remove all stored information.

## 🎨 Design Philosophy

This application prioritizes:
- Gentle, non-judgmental user experience
- Accessibility for neurodivergent individuals
- Privacy-first approach with local data storage
- Calming, supportive interface design
- Executive function support through thoughtful UX

## 🔧 Technology Stack

- **Frontend**: React 18 + TypeScript
- **Build Tool**: Vite
- **UI Framework**: shadcn/ui (Radix UI + Tailwind CSS)
- **State Management**: TanStack Query with localStorage adapter
- **Animations**: Framer Motion
- **Deployment**: Static hosting (no server required)

---

*Built with care for mental health and neurodivergent communities.*