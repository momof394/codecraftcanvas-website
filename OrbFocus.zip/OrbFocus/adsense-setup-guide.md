# Google AdSense Setup Guide for Orb Focus Studio

## ✅ AdSense Integration Complete

Your AdSense code has been successfully integrated into your Orb Focus Studio platform!

### Current Implementation:

1. **AdSense Script** - Already in `client/index.html`:
   ```html
   <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8064547227653641" crossorigin="anonymous"></script>
   ```

2. **Ad Placement** - Added between header and footer:
   - **Header Banner** - Below navigation, above main content
   - **Footer Banner** - Above footer, below main content

3. **Ad Components Created**:
   - `HeaderAdBanner` - Horizontal banner at top
   - `FooterAdBanner` - Horizontal banner at bottom
   - `SidebarAdBanner` - Vertical ads for sidebars (optional)

### Next Steps - Replace Placeholder Ad Slots:

You need to get your actual ad slot IDs from Google AdSense and replace the placeholders:

#### 1. Get Ad Slot IDs from AdSense:
1. Go to [Google AdSense Console](https://www.google.com/adsense/)
2. Click **Ads** > **By ad unit**
3. Create new ad units:
   - **Header Banner**: Display ad, horizontal format
   - **Footer Banner**: Display ad, horizontal format
   - **Sidebar Ad**: Display ad, vertical format (optional)

#### 2. Update the Ad Slot IDs:

Edit `client/src/components/adsense-banner.tsx`:

```typescript
// Replace these placeholder IDs with your actual ad slot IDs:
export function HeaderAdBanner() {
  return (
    <AdSenseBanner 
      adSlot="YOUR_HEADER_AD_SLOT_ID" // Replace this
      adFormat="horizontal"
    />
  );
}

export function FooterAdBanner() {
  return (
    <AdSenseBanner 
      adSlot="YOUR_FOOTER_AD_SLOT_ID" // Replace this
      adFormat="horizontal"
    />
  );
}
```

### Ad Positions in Your App:

```
┌─────────────────┐
│     Navbar      │
├─────────────────┤
│  Header Ad      │ ← New ad banner
├─────────────────┤
│                 │
│  Main Content   │
│                 │
├─────────────────┤
│  Footer Ad      │ ← New ad banner
├─────────────────┤
│     Footer      │
└─────────────────┘
```

### Benefits of This Implementation:

- **Non-intrusive**: Ads don't interfere with user experience
- **Responsive**: Automatically adapts to different screen sizes
- **Performance**: Lazy loads ads for faster page loading
- **Policy Compliant**: Follows Google AdSense placement guidelines

### Testing:

Once you add your real ad slot IDs, ads will start showing within 24-48 hours after deployment.

## Current Status:
✅ AdSense script loaded in HTML head  
✅ Ad components created and integrated  
✅ Strategic placement between header and footer  
⏳ Waiting for your actual ad slot IDs from AdSense console