import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, real } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  plan: text("plan").default("free"), // "free", "pro", "enterprise"
  createdAt: timestamp("created_at").defaultNow(),
});

// Design Projects - Main projects users create
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(), // "journal", "planner", "cover", "artwork", "document"
  templateId: varchar("template_id").references(() => templates.id),
  canvasData: jsonb("canvas_data").notNull(), // Complete canvas state with elements
  dimensions: jsonb("dimensions").notNull(), // {width, height} in pixels
  backgroundColor: text("background_color").default("#ffffff"),
  isPublic: boolean("is_public").default(false),
  exportSettings: jsonb("export_settings"), // Export preferences
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Templates - Preloaded design templates
export const templates = pgTable("templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(), // "journal", "planner", "cover", "social_media"
  thumbnail: text("thumbnail"), // URL or base64 thumbnail
  canvasData: jsonb("canvas_data").notNull(), // Template canvas structure
  dimensions: jsonb("dimensions").notNull(), // {width, height}
  tags: text("tags").array(), // searchable tags
  isPremium: boolean("is_premium").default(false),
  usageCount: integer("usage_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Design Elements - Text, shapes, images, drawings
export const designElements = pgTable("design_elements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id),
  type: text("type").notNull(), // "text", "shape", "image", "drawing", "sticker"
  content: jsonb("content").notNull(), // Element-specific data
  position: jsonb("position").notNull(), // {x, y, width, height, rotation}
  style: jsonb("style"), // Colors, fonts, borders, etc.
  layerOrder: integer("layer_order").default(0),
  isLocked: boolean("is_locked").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Drawing Layers - For Procreate-style drawing
export const drawingLayers = pgTable("drawing_layers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id),
  name: text("name").notNull(),
  data: text("data").notNull(), // SVG path data or canvas image data
  opacity: real("opacity").default(1.0),
  blendMode: text("blend_mode").default("normal"),
  isVisible: boolean("is_visible").default(true),
  layerOrder: integer("layer_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Assets - Free images, shapes, icons, stickers
export const assets = pgTable("assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // "image", "shape", "icon", "sticker", "font"
  category: text("category"), // "backgrounds", "decorative", "business", etc.
  fileUrl: text("file_url").notNull(), // Asset file location
  thumbnail: text("thumbnail"), // Thumbnail URL
  tags: text("tags").array(),
  isPremium: boolean("is_premium").default(false),
  license: text("license").default("royalty_free"), // License type
  usageCount: integer("usage_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Brushes - Drawing tools for Procreate-style functionality
export const brushes = pgTable("brushes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // "pen", "pencil", "brush", "marker", "textural"
  settings: jsonb("settings").notNull(), // Brush properties, opacity, size ranges
  icon: text("icon"), // Brush preview icon
  isPremium: boolean("is_premium").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Export History - Track user exports
export const exports = pgTable("exports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id),
  userId: varchar("user_id").references(() => users.id),
  format: text("format").notNull(), // "pdf", "png", "jpeg"
  quality: text("quality").default("high"), // "low", "medium", "high"
  fileUrl: text("file_url"), // Export file location
  settings: jsonb("settings"), // Export settings used
  createdAt: timestamp("created_at").defaultNow(),
});

// User Settings
export const userSettings = pgTable("user_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).unique(),
  canvasSettings: jsonb("canvas_settings"), // Grid, guides, snap settings
  exportPreferences: jsonb("export_preferences"), // Default export settings
  uiPreferences: jsonb("ui_preferences"), // Theme, layout preferences
  brushSettings: jsonb("brush_settings"), // Default brush preferences
  autoSaveInterval: integer("auto_save_interval").default(30), // seconds
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTemplateSchema = createInsertSchema(templates).omit({
  id: true,
  createdAt: true,
});

export const insertDesignElementSchema = createInsertSchema(designElements).omit({
  id: true,
  createdAt: true,
});

export const insertDrawingLayerSchema = createInsertSchema(drawingLayers).omit({
  id: true,
  createdAt: true,
});

export const insertAssetSchema = createInsertSchema(assets).omit({
  id: true,
  createdAt: true,
});

export const insertBrushSchema = createInsertSchema(brushes).omit({
  id: true,
  createdAt: true,
});

export const insertExportSchema = createInsertSchema(exports).omit({
  id: true,
  createdAt: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({
  id: true,
  userId: true,
  updatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Template = typeof templates.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type DesignElement = typeof designElements.$inferSelect;
export type InsertDesignElement = z.infer<typeof insertDesignElementSchema>;
export type DrawingLayer = typeof drawingLayers.$inferSelect;
export type InsertDrawingLayer = z.infer<typeof insertDrawingLayerSchema>;
export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type Brush = typeof brushes.$inferSelect;
export type InsertBrush = z.infer<typeof insertBrushSchema>;
export type Export = typeof exports.$inferSelect;
export type InsertExport = z.infer<typeof insertExportSchema>;
export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  projects: many(projects),
  exports: many(exports),
  settings: one(userSettings, {
    fields: [users.id],
    references: [userSettings.userId],
  }),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  user: one(users, {
    fields: [projects.userId],
    references: [users.id],
  }),
  template: one(templates, {
    fields: [projects.templateId],
    references: [templates.id],
  }),
  designElements: many(designElements),
  drawingLayers: many(drawingLayers),
  exports: many(exports),
}));

export const templatesRelations = relations(templates, ({ many }) => ({
  projects: many(projects),
}));

export const designElementsRelations = relations(designElements, ({ one }) => ({
  project: one(projects, {
    fields: [designElements.projectId],
    references: [projects.id],
  }),
}));

export const drawingLayersRelations = relations(drawingLayers, ({ one }) => ({
  project: one(projects, {
    fields: [drawingLayers.projectId],
    references: [projects.id],
  }),
}));

export const exportsRelations = relations(exports, ({ one }) => ({
  project: one(projects, {
    fields: [exports.projectId],
    references: [projects.id],
  }),
  user: one(users, {
    fields: [exports.userId],
    references: [users.id],
  }),
}));

export const userSettingsRelations = relations(userSettings, ({ one }) => ({
  user: one(users, {
    fields: [userSettings.userId],
    references: [users.id],
  }),
}));
