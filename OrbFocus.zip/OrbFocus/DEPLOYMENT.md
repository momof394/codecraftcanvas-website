# Cloud Run Deployment Guide

## Overview
This application is configured for Google Cloud Run deployment with proper health checks, startup probes, and production optimizations.

## Pre-Deployment Verification

Run the deployment readiness test:
```bash
./test-deployment.sh
```

This test verifies:
- ✅ Build process completes successfully
- ✅ Production server starts on correct port (8080)
- ✅ Health endpoint responds with HTTP 200
- ✅ Static file serving works for React app
- ✅ API endpoints are accessible

## Deployment Commands

### Option 1: Google Cloud Build (Recommended)
```bash
gcloud builds submit --config=cloudbuild.yaml
```

### Option 2: Manual Docker Deployment
```bash
# Build the Docker image
docker build -t gcr.io/PROJECT_ID/bodydouble-orb:latest .

# Push to Container Registry
docker push gcr.io/PROJECT_ID/bodydouble-orb:latest

# Deploy to Cloud Run
gcloud run deploy bodydouble-orb \
  --image gcr.io/PROJECT_ID/bodydouble-orb:latest \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080 \
  --memory 1Gi \
  --cpu 1 \
  --max-instances 10 \
  --startup-probe httpGet.path=/health,httpGet.port=8080,initialDelaySeconds=30,failureThreshold=5,timeoutSeconds=10,periodSeconds=10 \
  --liveness-probe httpGet.path=/health,httpGet.port=8080,timeoutSeconds=5,periodSeconds=30,failureThreshold=3
```

## Health Check Endpoints

### Primary Health Check: `/health`
- **Purpose**: Cloud Run startup and liveness probes
- **Response**: JSON with service status and environment info
- **Expected**: HTTP 200 with `{"status":"healthy",...}`

### Root Endpoint: `/`
- **Purpose**: Serves the React application
- **Response**: HTML content for the main app
- **Expected**: HTTP 200 with HTML document

## Production Environment Variables

Required for Cloud Run:
- `NODE_ENV=production` (set automatically in Dockerfile)
- `PORT=8080` (set automatically in Dockerfile, Cloud Run may override)

## Troubleshooting

### Health Check Failures
1. Verify `/health` endpoint responds with HTTP 200
2. Check server logs for startup errors
3. Ensure port 8080 is accessible

### Build Failures
1. Run `npm run build` locally to verify
2. Check for TypeScript compilation errors
3. Verify all dependencies are properly installed

### Connection Issues
1. Ensure server binds to `0.0.0.0`, not `localhost`
2. Verify PORT environment variable usage
3. Check Cloud Run logs for connection errors

## Performance Considerations

- **Cold Start**: Startup probe allows 30 seconds for initial startup
- **Memory**: 1Gi allocated (can be adjusted based on usage)
- **CPU**: 1 vCPU allocated (can be scaled based on demand)
- **Instances**: Maximum 10 instances for auto-scaling

## Security Notes

- Service allows unauthenticated access (public web app)
- No sensitive data stored in environment variables
- Uses official Node.js Alpine base image for security
- Dependencies are pruned in production build