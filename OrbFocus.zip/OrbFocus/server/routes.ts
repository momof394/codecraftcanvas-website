import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertProjectSchema, 
  insertTemplateSchema, 
  insertDesignElementSchema, 
  insertDrawingLayerSchema,
  insertAssetSchema,
  insertBrushSchema,
  insertExportSchema,
  insertUserSettingsSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const demoUserId = "demo-user-123"; // For demo purposes, using a fixed user ID
  
  // Projects endpoints
  app.post("/api/projects", async (req, res) => {
    try {
      const data = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(demoUserId, data);
      res.json(project);
    } catch (error) {
      res.status(400).json({ error: "Invalid project data" });
    }
  });
  
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects(demoUserId);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const project = await storage.updateProject(id, updates);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to update project" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteProject(id);
      if (!deleted) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete project" });
    }
  });
  
  // Templates endpoints
  app.get("/api/templates", async (req, res) => {
    try {
      const { category } = req.query;
      const templates = await storage.getTemplates(category as string);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  app.get("/api/templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const template = await storage.getTemplate(id);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch template" });
    }
  });

  // Assets endpoints
  app.get("/api/assets", async (req, res) => {
    try {
      const { type, category } = req.query;
      const assets = await storage.getAssets(type as string, category as string);
      res.json(assets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch assets" });
    }
  });

  // Brushes endpoints
  app.get("/api/brushes", async (req, res) => {
    try {
      const brushes = await storage.getBrushes();
      res.json(brushes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch brushes" });
    }
  });

  // Design Elements endpoints
  app.post("/api/elements", async (req, res) => {
    try {
      const data = insertDesignElementSchema.parse(req.body);
      const element = await storage.createDesignElement(data);
      res.json(element);
    } catch (error) {
      res.status(400).json({ error: "Invalid element data" });
    }
  });

  app.get("/api/elements/:projectId", async (req, res) => {
    try {
      const { projectId } = req.params;
      const elements = await storage.getDesignElements(projectId);
      res.json(elements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch elements" });
    }
  });

  app.put("/api/elements/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const element = await storage.updateDesignElement(id, updates);
      if (!element) {
        return res.status(404).json({ error: "Element not found" });
      }
      res.json(element);
    } catch (error) {
      res.status(500).json({ error: "Failed to update element" });
    }
  });

  app.delete("/api/elements/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteDesignElement(id);
      if (!deleted) {
        return res.status(404).json({ error: "Element not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete element" });
    }
  });

  // Drawing Layers endpoints
  app.post("/api/layers", async (req, res) => {
    try {
      const data = insertDrawingLayerSchema.parse(req.body);
      const layer = await storage.createDrawingLayer(data);
      res.json(layer);
    } catch (error) {
      res.status(400).json({ error: "Invalid layer data" });
    }
  });

  app.get("/api/layers/:projectId", async (req, res) => {
    try {
      const { projectId } = req.params;
      const layers = await storage.getDrawingLayers(projectId);
      res.json(layers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch layers" });
    }
  });

  // Export endpoints
  app.post("/api/export", async (req, res) => {
    try {
      const data = insertExportSchema.parse(req.body);
      const exportData = await storage.createExport(data);
      res.json(exportData);
    } catch (error) {
      res.status(400).json({ error: "Invalid export data" });
    }
  });

  app.get("/api/exports", async (req, res) => {
    try {
      const exports = await storage.getExports(demoUserId);
      res.json(exports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch exports" });
    }
  });

  // User settings endpoints
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getUserSettings(demoUserId);
      if (!settings) {
        const defaultSettings = await storage.updateUserSettings(demoUserId, {
          canvasSettings: {},
          exportPreferences: {},
          uiPreferences: {},
          autoSaveInterval: 30
        });
        return res.json(defaultSettings);
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });
  
  app.put("/api/settings", async (req, res) => {
    try {
      const data = insertUserSettingsSchema.parse(req.body);
      const settings = await storage.updateUserSettings(demoUserId, data);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ error: "Invalid settings data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
