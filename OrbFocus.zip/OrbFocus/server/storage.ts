import { 
  type User, 
  type InsertUser, 
  type Project,
  type InsertProject,
  type Template,
  type InsertTemplate,
  type DesignElement,
  type InsertDesignElement,
  type DrawingLayer,
  type InsertDrawingLayer,
  type Asset,
  type InsertAsset,
  type Brush,
  type InsertBrush,
  type Export,
  type InsertExport,
  type UserSettings,
  type InsertUserSettings,
  users,
  projects,
  templates,
  designElements,
  drawingLayers,
  assets,
  brushes,
  exports,
  userSettings
} from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Projects
  createProject(userId: string, project: InsertProject): Promise<Project>;
  getProjects(userId: string): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;
  
  // Templates
  getTemplates(category?: string): Promise<Template[]>;
  getTemplate(id: string): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  
  // Design Elements
  createDesignElement(element: InsertDesignElement): Promise<DesignElement>;
  getDesignElements(projectId: string): Promise<DesignElement[]>;
  updateDesignElement(id: string, updates: Partial<InsertDesignElement>): Promise<DesignElement | undefined>;
  deleteDesignElement(id: string): Promise<boolean>;
  
  // Drawing Layers
  createDrawingLayer(layer: InsertDrawingLayer): Promise<DrawingLayer>;
  getDrawingLayers(projectId: string): Promise<DrawingLayer[]>;
  updateDrawingLayer(id: string, updates: Partial<InsertDrawingLayer>): Promise<DrawingLayer | undefined>;
  deleteDrawingLayer(id: string): Promise<boolean>;
  
  // Assets
  getAssets(type?: string, category?: string): Promise<Asset[]>;
  getAsset(id: string): Promise<Asset | undefined>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  
  // Brushes
  getBrushes(): Promise<Brush[]>;
  getBrush(id: string): Promise<Brush | undefined>;
  createBrush(brush: InsertBrush): Promise<Brush>;
  
  // Exports
  createExport(exportData: InsertExport): Promise<Export>;
  getExports(userId: string): Promise<Export[]>;
  
  // User settings
  getUserSettings(userId: string): Promise<UserSettings | undefined>;
  updateUserSettings(userId: string, settings: Partial<InsertUserSettings>): Promise<UserSettings>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private projects: Map<string, Project>;
  private templates: Map<string, Template>;
  private designElements: Map<string, DesignElement>;
  private drawingLayers: Map<string, DrawingLayer>;
  private assets: Map<string, Asset>;
  private brushes: Map<string, Brush>;
  private exports: Map<string, Export>;
  private userSettings: Map<string, UserSettings>;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.templates = new Map();
    this.designElements = new Map();
    this.drawingLayers = new Map();
    this.assets = new Map();
    this.brushes = new Map();
    this.exports = new Map();
    this.userSettings = new Map();
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleDataSync(): void {
    // Create sample templates
    const journalTemplate: Template = {
      id: "template-journal-1",
      title: "Mindful Journal",
      description: "A calming journal template with guided prompts",
      category: "journal",
      thumbnail: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjI2MCIgdmlld0JveD0iMCAwIDIwMCAyNjAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIyNjAiIGZpbGw9IiNmZmY3ZWQiLz48L3N2Zz4=",
      canvasData: {
        elements: [
          { type: "text", content: "Daily Reflection", position: { x: 50, y: 50 }, style: { fontSize: 24, fontWeight: "bold" } }
        ]
      },
      dimensions: { width: 600, height: 800 },
      tags: ["journal", "mindful", "reflection"],
      isPremium: false,
      usageCount: 0,
      createdAt: new Date()
    };

    const plannerTemplate: Template = {
      id: "template-planner-1", 
      title: "Weekly Planner",
      description: "Organize your week with this clean planner template",
      category: "planner",
      thumbnail: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjI2MCIgdmlld0JveD0iMCAwIDIwMCAyNjAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjIwMCIgaGVpZ2h0PSIyNjAiIGZpbGw9IiNlZGY0ZmYiLz48L3N2Zz4=",
      canvasData: {
        elements: [
          { type: "text", content: "Weekly Goals", position: { x: 50, y: 30 }, style: { fontSize: 20, fontWeight: "bold" } }
        ]
      },
      dimensions: { width: 800, height: 600 },
      tags: ["planner", "weekly", "productivity"],
      isPremium: false,
      usageCount: 0,
      createdAt: new Date()
    };

    this.templates.set(journalTemplate.id, journalTemplate);
    this.templates.set(plannerTemplate.id, plannerTemplate);

    // Create sample brushes
    const basicBrush: Brush = {
      id: "brush-basic-1",
      name: "Basic Pen",
      type: "pen", 
      settings: { opacity: 1.0, minSize: 2, maxSize: 10, flow: 0.8 },
      icon: "pen",
      isPremium: false,
      createdAt: new Date()
    };

    const pencilBrush: Brush = {
      id: "brush-pencil-1",
      name: "Soft Pencil",
      type: "pencil",
      settings: { opacity: 0.7, minSize: 1, maxSize: 8, flow: 0.6 },
      icon: "pencil",
      isPremium: false,
      createdAt: new Date()
    };

    this.brushes.set(basicBrush.id, basicBrush);
    this.brushes.set(pencilBrush.id, pencilBrush);

    // Create sample assets
    const circleAsset: Asset = {
      id: "asset-circle-1",
      name: "Circle",
      type: "shape",
      category: "basic",
      fileUrl: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgdmlld0JveD0iMCAwIDEwMCAxMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iNTAiIGN5PSI1MCIgcj0iNDAiIGZpbGw9IiM2MzY2ZjEiLz48L3N2Zz4=",
      thumbnail: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgdmlld0JveD0iMCAwIDEwMCAxMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iNTAiIGN5PSI1MCIgcj0iNDAiIGZpbGw9IiM2MzY2ZjEiLz48L3N2Zz4=",
      tags: ["shape", "circle", "basic"],
      isPremium: false,
      license: "royalty_free",
      usageCount: 0,
      createdAt: new Date()
    };

    this.assets.set(circleAsset.id, circleAsset);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      id, 
      username: insertUser.username,
      email: insertUser.email,
      password: insertUser.password,
      plan: insertUser.plan || null,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    
    // Create default settings
    await this.updateUserSettings(id, {
      canvasSettings: {},
      exportPreferences: {},
      uiPreferences: {}
    });
    
    return user;
  }

  // Projects
  async createProject(userId: string, project: InsertProject): Promise<Project> {
    const id = randomUUID();
    const now = new Date();
    const newProject: Project = {
      id,
      userId,
      title: project.title,
      description: project.description || null,
      category: project.category,
      templateId: project.templateId || null,
      canvasData: project.canvasData,
      dimensions: project.dimensions,
      backgroundColor: project.backgroundColor || null,
      isPublic: project.isPublic || null,
      exportSettings: project.exportSettings || null,
      createdAt: now,
      updatedAt: now
    };
    this.projects.set(id, newProject);
    return newProject;
  }

  async getProjects(userId: string): Promise<Project[]> {
    return Array.from(this.projects.values())
      .filter(project => project.userId === userId)
      .sort((a, b) => (b.updatedAt?.getTime() || 0) - (a.updatedAt?.getTime() || 0));
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updated: Project = {
      ...project,
      ...updates,
      updatedAt: new Date()
    };
    this.projects.set(id, updated);
    return updated;
  }

  async deleteProject(id: string): Promise<boolean> {
    return this.projects.delete(id);
  }

  // Templates
  async getTemplates(category?: string): Promise<Template[]> {
    const templates = Array.from(this.templates.values());
    if (category) {
      return templates.filter(template => template.category === category);
    }
    return templates;
  }

  async getTemplate(id: string): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const id = randomUUID();
    const newTemplate: Template = {
      id,
      title: template.title,
      description: template.description || null,
      category: template.category,
      thumbnail: template.thumbnail || null,
      canvasData: template.canvasData,
      dimensions: template.dimensions,
      tags: template.tags || null,
      isPremium: template.isPremium || null,
      usageCount: template.usageCount || null,
      createdAt: new Date()
    };
    this.templates.set(id, newTemplate);
    return newTemplate;
  }

  // Design Elements
  async createDesignElement(element: InsertDesignElement): Promise<DesignElement> {
    const id = randomUUID();
    const newElement: DesignElement = {
      id,
      projectId: element.projectId || null,
      type: element.type,
      content: element.content,
      position: element.position,
      style: element.style || null,
      layerOrder: element.layerOrder || null,
      isLocked: element.isLocked || null,
      createdAt: new Date()
    };
    this.designElements.set(id, newElement);
    return newElement;
  }

  async getDesignElements(projectId: string): Promise<DesignElement[]> {
    return Array.from(this.designElements.values())
      .filter(element => element.projectId === projectId);
  }

  async updateDesignElement(id: string, updates: Partial<InsertDesignElement>): Promise<DesignElement | undefined> {
    const element = this.designElements.get(id);
    if (!element) return undefined;
    
    const updated: DesignElement = {
      ...element,
      ...updates
    };
    this.designElements.set(id, updated);
    return updated;
  }

  async deleteDesignElement(id: string): Promise<boolean> {
    return this.designElements.delete(id);
  }

  // Drawing Layers
  async createDrawingLayer(layer: InsertDrawingLayer): Promise<DrawingLayer> {
    const id = randomUUID();
    const newLayer: DrawingLayer = {
      id,
      projectId: layer.projectId || null,
      name: layer.name,
      data: layer.data,
      opacity: layer.opacity || null,
      blendMode: layer.blendMode || null,
      isVisible: layer.isVisible || null,
      layerOrder: layer.layerOrder || null,
      createdAt: new Date()
    };
    this.drawingLayers.set(id, newLayer);
    return newLayer;
  }

  async getDrawingLayers(projectId: string): Promise<DrawingLayer[]> {
    return Array.from(this.drawingLayers.values())
      .filter(layer => layer.projectId === projectId);
  }

  async updateDrawingLayer(id: string, updates: Partial<InsertDrawingLayer>): Promise<DrawingLayer | undefined> {
    const layer = this.drawingLayers.get(id);
    if (!layer) return undefined;
    
    const updated: DrawingLayer = {
      ...layer,
      ...updates
    };
    this.drawingLayers.set(id, updated);
    return updated;
  }

  async deleteDrawingLayer(id: string): Promise<boolean> {
    return this.drawingLayers.delete(id);
  }

  // Assets
  async getAssets(type?: string, category?: string): Promise<Asset[]> {
    let assets = Array.from(this.assets.values());
    if (type) {
      assets = assets.filter(asset => asset.type === type);
    }
    if (category) {
      assets = assets.filter(asset => asset.category === category);
    }
    return assets;
  }

  async getAsset(id: string): Promise<Asset | undefined> {
    return this.assets.get(id);
  }

  async createAsset(asset: InsertAsset): Promise<Asset> {
    const id = randomUUID();
    const newAsset: Asset = {
      id,
      name: asset.name,
      type: asset.type,
      category: asset.category || null,
      fileUrl: asset.fileUrl,
      thumbnail: asset.thumbnail || null,
      tags: asset.tags || null,
      isPremium: asset.isPremium || null,
      license: asset.license || null,
      usageCount: asset.usageCount || null,
      createdAt: new Date()
    };
    this.assets.set(id, newAsset);
    return newAsset;
  }

  // Brushes
  async getBrushes(): Promise<Brush[]> {
    return Array.from(this.brushes.values());
  }

  async getBrush(id: string): Promise<Brush | undefined> {
    return this.brushes.get(id);
  }

  async createBrush(brush: InsertBrush): Promise<Brush> {
    const id = randomUUID();
    const newBrush: Brush = {
      id,
      name: brush.name,
      type: brush.type,
      settings: brush.settings,
      icon: brush.icon || null,
      isPremium: brush.isPremium || null,
      createdAt: new Date()
    };
    this.brushes.set(id, newBrush);
    return newBrush;
  }

  // Exports
  async createExport(exportData: InsertExport): Promise<Export> {
    const id = randomUUID();
    const newExport: Export = {
      id,
      projectId: exportData.projectId || null,
      userId: exportData.userId || null,
      format: exportData.format,
      quality: exportData.quality || null,
      fileUrl: exportData.fileUrl || null,
      settings: exportData.settings || null,
      createdAt: new Date()
    };
    this.exports.set(id, newExport);
    return newExport;
  }

  async getExports(userId: string): Promise<Export[]> {
    return Array.from(this.exports.values())
      .filter(exportItem => exportItem.userId === userId);
  }



  async getUserSettings(userId: string): Promise<UserSettings | undefined> {
    return Array.from(this.userSettings.values())
      .find(settings => settings.userId === userId);
  }

  async updateUserSettings(userId: string, settings: Partial<InsertUserSettings>): Promise<UserSettings> {
    const existing = await this.getUserSettings(userId);
    const id = existing?.id || randomUUID();
    
    const updated: UserSettings = {
      id,
      userId,
      canvasSettings: null,
      exportPreferences: null,
      uiPreferences: null,
      brushSettings: null,
      autoSaveInterval: 30,
      updatedAt: new Date(),
      ...existing,
      ...settings
    };
    
    this.userSettings.set(id, updated);
    return updated;
  }

  // Initialize sample data
  async initializeSampleData(): Promise<void> {
    // Sample templates
    const sampleTemplates = [
      {
        title: "Daily Journal Template",
        description: "A clean and minimal daily journal template with prompts for reflection",
        category: "journal",
        thumbnail: "/templates/journal-daily.png",
        canvasData: { elements: [], background: "#ffffff" },
        dimensions: { width: 8.5, height: 11, unit: "inches" },
        tags: ["daily", "minimal", "reflection"],
        isPremium: false,
        usageCount: 245
      },
      {
        title: "Weekly Planner Pro",
        description: "Professional weekly planner with time blocks and goal tracking",
        category: "planner",
        thumbnail: "/templates/planner-weekly.png",
        canvasData: { elements: [], background: "#f8f9fa" },
        dimensions: { width: 8.5, height: 11, unit: "inches" },
        tags: ["weekly", "productivity", "goals"],
        isPremium: true,
        usageCount: 189
      },
      {
        title: "Book Cover Template",
        description: "Modern book cover design with customizable typography",
        category: "cover",
        thumbnail: "/templates/book-cover.png",
        canvasData: { elements: [], background: "#1a1a1a" },
        dimensions: { width: 6, height: 9, unit: "inches" },
        tags: ["book", "typography", "modern"],
        isPremium: true,
        usageCount: 76
      },
      {
        title: "Instagram Story Template",
        description: "Trendy Instagram story template with modern design elements",
        category: "social_media",
        thumbnail: "/templates/instagram-story.png",
        canvasData: { elements: [], background: "#ff6b6b" },
        dimensions: { width: 1080, height: 1920, unit: "pixels" },
        tags: ["instagram", "social", "trendy"],
        isPremium: false,
        usageCount: 432
      },
      {
        title: "Gratitude Journal",
        description: "Beautiful gratitude journal with inspirational quotes",
        category: "journal",
        thumbnail: "/templates/gratitude-journal.png",
        canvasData: { elements: [], background: "#fff8e7" },
        dimensions: { width: 8.5, height: 11, unit: "inches" },
        tags: ["gratitude", "mindfulness", "quotes"],
        isPremium: false,
        usageCount: 156
      }
    ];

    for (const template of sampleTemplates) {
      await this.createTemplate(template);
    }

    // Sample assets
    const sampleAssets = [
      {
        name: "Watercolor Flower Set",
        type: "image",
        category: "nature",
        fileUrl: "/assets/watercolor-flowers.png",
        thumbnail: "/assets/thumbs/watercolor-flowers.png",
        tags: ["watercolor", "flowers", "nature"],
        isPremium: false,
        license: "Royalty Free",
        usageCount: 89
      },
      {
        name: "Geometric Shapes Pack",
        type: "shape",
        category: "geometric",
        fileUrl: "/assets/geometric-shapes.svg",
        thumbnail: "/assets/thumbs/geometric-shapes.png",
        tags: ["geometric", "shapes", "modern"],
        isPremium: true,
        license: "Commercial Use",
        usageCount: 156
      },
      {
        name: "Hand-drawn Icons",
        type: "icon",
        category: "lifestyle",
        fileUrl: "/assets/hand-drawn-icons.svg",
        thumbnail: "/assets/thumbs/hand-drawn-icons.png",
        tags: ["hand-drawn", "icons", "lifestyle"],
        isPremium: false,
        license: "Creative Commons",
        usageCount: 234
      },
      {
        name: "Motivational Stickers",
        type: "sticker",
        category: "motivational",
        fileUrl: "/assets/motivational-stickers.png",
        thumbnail: "/assets/thumbs/motivational-stickers.png",
        tags: ["motivational", "quotes", "colorful"],
        isPremium: true,
        license: "Commercial Use",
        usageCount: 67
      }
    ];

    for (const asset of sampleAssets) {
      await this.createAsset(asset);
    }

    // Sample brushes
    const sampleBrushes = [
      {
        name: "Watercolor Brush",
        type: "watercolor",
        settings: { 
          opacity: 0.7, 
          flow: 0.8, 
          size: 20, 
          texture: "watercolor" 
        },
        icon: "/brushes/watercolor.png",
        isPremium: false
      },
      {
        name: "Oil Paint Brush",
        type: "oil",
        settings: { 
          opacity: 0.9, 
          flow: 0.6, 
          size: 15, 
          texture: "oil" 
        },
        icon: "/brushes/oil.png",
        isPremium: true
      },
      {
        name: "Pencil Sketch",
        type: "pencil",
        settings: { 
          opacity: 0.8, 
          flow: 1.0, 
          size: 3, 
          texture: "pencil" 
        },
        icon: "/brushes/pencil.png",
        isPremium: false
      },
      {
        name: "Marker Brush",
        type: "marker",
        settings: { 
          opacity: 0.6, 
          flow: 0.9, 
          size: 10, 
          texture: "marker" 
        },
        icon: "/brushes/marker.png",
        isPremium: true
      },
      {
        name: "Calligraphy Pen",
        type: "calligraphy",
        settings: { 
          opacity: 1.0, 
          flow: 0.8, 
          size: 8, 
          texture: "smooth" 
        },
        icon: "/brushes/calligraphy.png",
        isPremium: false
      }
    ];

    for (const brush of sampleBrushes) {
      await this.createBrush(brush);
    }
  }
}

export const storage = new MemStorage();

// Initialize sample data on startup
// Initialize sample data
try {
  storage.initializeSampleData();
} catch (error) {
  console.error('Failed to initialize sample data:', error);
}
