import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface TherapyMessage {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  emotionalAnalysis?: {
    sentiment: number; // -1 to 1
    emotions: string[];
    intensity: number; // 0 to 1
  };
}

export interface TherapyAnalysis {
  emotionalState: {
    primaryEmotion: string;
    intensity: number;
    triggers: string[];
    copingStrategies: string[];
  };
  insights: {
    patterns: string[];
    progressNotes: string[];
    concernAreas: string[];
  };
  recommendations: {
    immediateActions: string[];
    longTermGoals: string[];
    resources: string[];
  };
}

export class AITherapyService {
  private systemPrompts = {
    empathetic: `You are an AI therapy assistant with a warm, empathetic personality. You provide compassionate support for mental health challenges including anxiety, depression, ADHD, and general wellness. 

Key principles:
- Always validate the user's feelings and experiences
- Use gentle, non-judgmental language
- Ask thoughtful follow-up questions to understand better
- Provide practical coping strategies
- Recognize when professional help may be needed
- Never diagnose or replace professional therapy
- Be supportive but maintain healthy boundaries

You're having a therapy conversation. Listen actively, provide insights, and help the user explore their thoughts and feelings in a safe space.`,
    
    analytical: `You are an AI therapy assistant with an analytical, structured approach to mental health support. You help users understand patterns in their thoughts, behaviors, and emotions.

Key principles:
- Break down complex emotions into understandable components
- Identify behavioral and thought patterns
- Provide evidence-based strategies
- Use structured approaches like CBT techniques
- Help users track progress and set measurable goals
- Maintain professional yet caring communication
- Never diagnose or replace professional therapy

Focus on helping users understand the 'why' behind their feelings and develop systematic approaches to improvement.`,
    
    motivational: `You are an AI therapy assistant with an encouraging, motivational personality. You help users build confidence and take positive action toward their mental health goals.

Key principles:
- Celebrate small wins and progress
- Encourage action and forward movement
- Help users identify their strengths
- Provide energizing and uplifting support
- Focus on possibilities and solutions
- Use positive psychology principles
- Never diagnose or replace professional therapy
- Balance optimism with realistic expectations

Your goal is to inspire hope and empower users to take positive steps in their mental health journey.`
  };

  async startTherapySession(
    sessionType: string,
    userPersonality: string = "empathetic",
    initialMessage?: string
  ): Promise<{ sessionId: string; response: string; analysis: any }> {
    try {
      const systemPrompt = this.systemPrompts[userPersonality as keyof typeof this.systemPrompts] || this.systemPrompts.empathetic;
      
      const contextPrompt = this.getSessionTypeContext(sessionType);
      const fullSystemPrompt = `${systemPrompt}\n\n${contextPrompt}`;

      const messages: any[] = [
        { role: "system", content: fullSystemPrompt }
      ];

      if (initialMessage) {
        messages.push({ role: "user", content: initialMessage });
      } else {
        messages.push({ 
          role: "user", 
          content: `I'd like to start a ${sessionType} therapy session. Can you help me get started?`
        });
      }

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages,
        temperature: 0.7,
        max_tokens: 800
      });

      const aiResponse = response.choices[0].message.content || "";
      
      // Analyze the user's initial message for emotional state
      const analysis = await this.analyzeMessage(initialMessage || "Starting therapy session");

      return {
        sessionId: crypto.randomUUID(),
        response: aiResponse,
        analysis
      };
    } catch (error) {
      console.error("Error starting therapy session:", error);
      throw new Error("Failed to start therapy session");
    }
  }

  async continueTherapySession(
    sessionHistory: TherapyMessage[],
    newMessage: string,
    userPersonality: string = "empathetic"
  ): Promise<{ response: string; analysis: TherapyAnalysis }> {
    try {
      const systemPrompt = this.systemPrompts[userPersonality as keyof typeof this.systemPrompts] || this.systemPrompts.empathetic;
      
      const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
        { role: "system", content: systemPrompt },
        ...sessionHistory.map(msg => ({
          role: msg.role as "user" | "assistant" | "system",
          content: msg.content
        })),
        { role: "user", content: newMessage }
      ];

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages,
        temperature: 0.7,
        max_tokens: 800
      });

      const aiResponse = response.choices[0].message.content || "";
      
      // Analyze the entire conversation for insights
      const analysis = await this.analyzeTherapySession(sessionHistory, newMessage);

      return {
        response: aiResponse,
        analysis
      };
    } catch (error) {
      console.error("Error continuing therapy session:", error);
      throw new Error("Failed to continue therapy session");
    }
  }

  async analyzeJournalEntry(content: string): Promise<{
    sentiment: number;
    emotionalTone: string;
    themes: string[];
    insights: string[];
    recommendations: string[];
  }> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an AI therapist analyzing a journal entry. Provide insights in JSON format with:
            - sentiment: number from -1 (very negative) to 1 (very positive)
            - emotionalTone: primary emotional tone (e.g., "anxious", "hopeful", "frustrated")
            - themes: array of main themes/topics discussed
            - insights: array of psychological insights about patterns or behaviors
            - recommendations: array of helpful suggestions or coping strategies
            
            Be supportive and constructive in your analysis.`
          },
          {
            role: "user",
            content: `Please analyze this journal entry: "${content}"`
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const analysis = JSON.parse(response.choices[0].message.content || "{}");
      return analysis;
    } catch (error) {
      console.error("Error analyzing journal entry:", error);
      return {
        sentiment: 0,
        emotionalTone: "neutral",
        themes: [],
        insights: [],
        recommendations: []
      };
    }
  }

  async generateJournalPrompts(userMood: string, preferences: any): Promise<string[]> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Generate 5 thoughtful journal prompts for someone feeling ${userMood}. 
            Consider their preferences: ${JSON.stringify(preferences)}
            
            Make prompts therapeutic, introspective, and healing-focused. Return as JSON array of strings.`
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.8
      });

      const result = JSON.parse(response.choices[0].message.content || '{"prompts":[]}');
      return result.prompts || [];
    } catch (error) {
      console.error("Error generating journal prompts:", error);
      return [
        "How are you feeling right now, and what might be contributing to these feelings?",
        "What's one thing you're grateful for today?",
        "Describe a challenge you're facing and how you might approach it.",
        "What would you tell a friend who was feeling the way you feel right now?",
        "What's one small step you could take today to care for yourself?"
      ];
    }
  }

  async provideCrisisSupport(crisisLevel: number, triggers: string[]): Promise<{
    immediateSupport: string;
    copingStrategies: string[];
    resources: string[];
    followUpSuggestions: string[];
  }> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are providing crisis support for someone at crisis level ${crisisLevel}/10 with triggers: ${triggers.join(", ")}.
            
            Provide immediate, compassionate support in JSON format:
            - immediateSupport: calming, validating message
            - copingStrategies: array of immediate coping techniques
            - resources: array of crisis resources (hotlines, websites)
            - followUpSuggestions: array of next steps for continued support
            
            Be warm, non-judgmental, and emphasize safety and hope.`
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const support = JSON.parse(response.choices[0].message.content || "{}");
      
      // Add standard crisis resources
      const defaultResources = [
        "National Suicide Prevention Lifeline: 988",
        "Crisis Text Line: Text HOME to 741741",
        "SAMHSA National Helpline: 1-800-662-4357"
      ];

      return {
        immediateSupport: support.immediateSupport || "You're not alone. This feeling will pass.",
        copingStrategies: support.copingStrategies || ["Deep breathing", "Grounding techniques", "Reach out to support"],
        resources: [...(support.resources || []), ...defaultResources],
        followUpSuggestions: support.followUpSuggestions || ["Schedule therapy appointment", "Check in with trusted friend"]
      };
    } catch (error) {
      console.error("Error providing crisis support:", error);
      return {
        immediateSupport: "You're not alone. This feeling will pass. Please reach out for support.",
        copingStrategies: ["Take slow, deep breaths", "Ground yourself by naming 5 things you can see", "Call a trusted friend or family member"],
        resources: [
          "National Suicide Prevention Lifeline: 988",
          "Crisis Text Line: Text HOME to 741741",
          "SAMHSA National Helpline: 1-800-662-4357"
        ],
        followUpSuggestions: ["Consider speaking with a mental health professional", "Reach out to your support network"]
      };
    }
  }

  private async analyzeMessage(message: string): Promise<any> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze this message for emotional content. Return JSON with:
            - sentiment: number from -1 to 1
            - emotions: array of detected emotions
            - intensity: number from 0 to 1`
          },
          { role: "user", content: message }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      return JSON.parse(response.choices[0].message.content || "{}");
    } catch (error) {
      return { sentiment: 0, emotions: [], intensity: 0 };
    }
  }

  private async analyzeTherapySession(history: TherapyMessage[], newMessage: string): Promise<TherapyAnalysis> {
    try {
      const fullConversation = history.map(m => `${m.role}: ${m.content}`).join("\n") + `\nuser: ${newMessage}`;
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Analyze this therapy conversation for patterns and insights. Return JSON with:
            {
              "emotionalState": {
                "primaryEmotion": "string",
                "intensity": number 0-1,
                "triggers": ["array of triggers"],
                "copingStrategies": ["array of strategies mentioned"]
              },
              "insights": {
                "patterns": ["behavioral/thought patterns"],
                "progressNotes": ["signs of progress"],
                "concernAreas": ["areas needing attention"]
              },
              "recommendations": {
                "immediateActions": ["immediate suggestions"],
                "longTermGoals": ["therapy goals"],
                "resources": ["helpful resources"]
              }
            }`
          },
          { role: "user", content: fullConversation }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      return JSON.parse(response.choices[0].message.content || "{}");
    } catch (error) {
      console.error("Error analyzing therapy session:", error);
      return {
        emotionalState: { primaryEmotion: "neutral", intensity: 0.5, triggers: [], copingStrategies: [] },
        insights: { patterns: [], progressNotes: [], concernAreas: [] },
        recommendations: { immediateActions: [], longTermGoals: [], resources: [] }
      };
    }
  }

  private getSessionTypeContext(sessionType: string): string {
    const contexts = {
      anxiety: "Focus on anxiety management, breathing techniques, cognitive restructuring, and grounding exercises. Help identify anxiety triggers and develop coping strategies.",
      depression: "Provide supportive guidance for depression. Focus on mood tracking, behavioral activation, positive coping strategies, and building hope. Watch for concerning symptoms.",
      adhd: "Support ADHD challenges including focus, organization, time management, and emotional regulation. Provide practical strategies and executive function support.",
      general: "Provide general mental health support, active listening, and help the user explore their thoughts and feelings in a safe, non-judgmental space.",
      crisis: "This is a crisis session. Prioritize safety, provide immediate support, validate feelings, and help develop safety plans. Be prepared to suggest emergency resources if needed."
    };
    
    return contexts[sessionType as keyof typeof contexts] || contexts.general;
  }
}

export const aiTherapyService = new AITherapyService();