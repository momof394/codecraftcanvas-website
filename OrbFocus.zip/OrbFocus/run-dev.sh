#!/bin/bash
echo "Starting Orb Focus Studio..."
npm run dev