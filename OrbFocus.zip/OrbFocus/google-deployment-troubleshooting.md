# Google Cloud Deployment Troubleshooting Guide

## Common Issues and Solutions

### Issue 1: Project Creation Problems
**Error**: "Project creation failed" or quota exceeded

**Solution**:
```bash
# Try with different project name
gcloud projects create orb-focus-$(date +%s) --name="Orb Focus Studio"

# Or use existing project
gcloud projects list
gcloud config set project EXISTING_PROJECT_ID
```

### Issue 2: API Enablement Issues
**Error**: "API not enabled" or permission denied

**Solution**:
```bash
# Enable APIs one by one
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com  
gcloud services enable containerregistry.googleapis.com

# Check billing account is linked
gcloud beta billing projects describe PROJECT_ID
```

### Issue 3: Quota/Billing Issues
**Error**: "Quota exceeded" or "Billing required"

**Solutions**:
1. **Use existing project with billing enabled**
2. **Try different region**:
   ```bash
   gcloud config set run/region us-east1
   # or us-west1, europe-west1
   ```
3. **Minimal resource deployment**:
   ```bash
   gcloud run deploy orb-focus-studio \
     --image gcr.io/PROJECT_ID/orb-focus-studio \
     --platform managed \
     --region us-east1 \
     --allow-unauthenticated \
     --memory 512Mi \
     --cpu 0.5 \
     --max-instances 3
   ```

### Issue 4: Docker Build Failures
**Error**: Build timeouts or Docker issues

**Solution - Use Cloud Shell**:
1. Go to https://shell.cloud.google.com/
2. Upload your project files:
   ```bash
   # In Cloud Shell
   git clone https://github.com/YOUR_USERNAME/orb-focus-studio.git
   cd orb-focus-studio
   gcloud builds submit --config=cloudbuild.yaml
   ```

### Issue 5: Permission Errors
**Error**: "Permission denied" or "Access forbidden"

**Solution**:
```bash
# Re-authenticate with proper permissions
gcloud auth login --update-adc
gcloud auth configure-docker

# Set proper IAM roles
gcloud projects add-iam-policy-binding PROJECT_ID \
    --member="user:YOUR_EMAIL" \
    --role="roles/run.developer"
```

## Alternative: Use Google Cloud Console (Web Interface)

### Step 1: Manual Upload
1. Go to https://console.cloud.google.com/
2. Open Cloud Shell (terminal icon)
3. Upload your files using the upload button

### Step 2: Deploy via Console
1. Go to Cloud Run in console
2. Click "Create Service"
3. Select "Deploy one revision from an existing container image"
4. Build image first:
   ```bash
   # In Cloud Shell
   docker build -t gcr.io/PROJECT_ID/orb-focus-studio .
   docker push gcr.io/PROJECT_ID/orb-focus-studio
   ```

## Simplified Single Command Deployment

If you have a working Google Cloud project:

```bash
# One command to rule them all
gcloud run deploy orb-focus-studio \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080
```

This builds and deploys in one step without needing Docker locally.

## Check Current Status

```bash
# Verify project setup
gcloud config list
gcloud services list --enabled
gcloud run services list

# Get deployment URL
gcloud run services describe orb-focus-studio \
  --region=us-central1 \
  --format="value(status.url)"
```

## Last Resort: Use Different Cloud Provider

If Google Cloud continues to have issues:

**Vercel** (Static deployment):
```bash
npm install -g vercel
vercel --prod
```

**Netlify** (Static deployment):
```bash
npm install -g netlify-cli
netlify deploy --prod --dir=dist/public
```

Your app will work perfectly on any of these platforms!