# Firebase App Registration Guide for Orb Focus Studio

## Step 1: Add Your Replit Domain to Firebase

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select your project: `flash-antler-456808-v4`
3. Go to **Project Settings** > **General**
4. Scroll down to **Your Apps** section
5. Click on your web app
6. Add your Replit domain to **Authorized domains**:
   - `your-repl-name.replit.app` (replace with your actual Replit URL)
   - `your-repl-name--3000.repl.co` (if using development mode)

## Step 2: Configure ReCAPTCHA for Your Domain

1. Go to [Google reCAPTCHA Console](https://www.google.com/recaptcha/admin/)
2. Select your reCAPTCHA site
3. Go to **Settings**
4. Add your Replit domains to **Domains**:
   - `your-repl-name.replit.app`
   - `your-repl-name--3000.repl.co`
   - `localhost` (for testing)

## Step 3: Enable App Check in Firebase

1. In Firebase Console, go to **App Check**
2. Click **Get Started**
3. Select your web app
4. Choose **reCAPTCHA v3** as provider
5. Enter your site key: `6LdoqSgrAAAAF2ttawi6gMB9N_F0N7eDLYdZFK`
6. Click **Save**

## Step 4: Configure App Check Enforcement (Optional)

1. In App Check settings, go to **APIs** tab
2. Enable enforcement for services you want to protect:
   - Firestore Database
   - Realtime Database
   - Cloud Storage
   - Cloud Functions

## Current Configuration Status:

✅ Firebase App initialized with config
✅ App Check configured with ReCAPTCHA v3
✅ Site key integrated: `6LdoqSgrAAAAF2ttawi6gMB9N_F0N7eDLYdZFK`
✅ Helper functions created for token management

## Next Steps:

1. Deploy your Replit app to get the production URL
2. Add that URL to Firebase authorized domains
3. Add the URL to your ReCAPTCHA settings
4. Test the App Check integration

## Testing App Check:

Use the AppCheckExample component to verify everything works:
```typescript
import { AppCheckExample } from '@/components/app-check-example';
```