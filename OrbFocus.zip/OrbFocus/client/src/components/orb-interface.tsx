import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Circle,
  Brain,
  Heart,
  Smile,
  Frown,
  Meh,
  Star,
  Zap,
  Sun,
  Moon,
  Cloud,
  Sparkles,
  Target,
  Compass,
  Eye,
  Waves
} from "lucide-react";

interface OrbState {
  mood: number; // 1-5 scale
  energy: number; // 1-5 scale
  focus: number; // 1-5 scale
  creativity: number; // 1-5 scale
  emotion: string;
  color: string;
  pulse: boolean;
}

interface OrbInterfaceProps {
  onStateChange?: (state: OrbState) => void;
  currentMood?: number;
}

export default function OrbInterface({ onStateChange, currentMood = 3 }: OrbInterfaceProps) {
  const [orbState, setOrbState] = useState<OrbState>({
    mood: currentMood,
    energy: 3,
    focus: 3,
    creativity: 3,
    emotion: 'neutral',
    color: '#8B5CF6',
    pulse: false
  });

  const [isInteractive, setIsInteractive] = useState(false);
  const [orbMessage, setOrbMessage] = useState("I'm here to support your creative journey...");

  // Color mappings for different states
  const moodColors = {
    1: '#EF4444', // red - sad/angry
    2: '#F97316', // orange - stressed
    3: '#8B5CF6', // purple - neutral
    4: '#10B981', // green - good
    5: '#F59E0B'  // yellow - excellent
  };

  const energyColors = {
    1: '#6B7280', // gray - low
    2: '#8B5CF6', // purple - mild
    3: '#3B82F6', // blue - moderate
    4: '#10B981', // green - high
    5: '#EF4444'  // red - very high
  };

  // Update orb appearance based on state
  useEffect(() => {
    const newColor = moodColors[orbState.mood as keyof typeof moodColors];
    setOrbState(prev => ({ ...prev, color: newColor }));
    onStateChange?.(orbState);
  }, [orbState.mood, orbState.energy, orbState.focus, orbState.creativity, onStateChange]);

  // Generate contextual message based on state
  useEffect(() => {
    const messages = {
      low: [
        "I sense you might need some gentle support right now. What's weighing on your mind?",
        "Sometimes the most profound creativity comes from our quieter moments. I'm here with you.",
        "Your feelings are valid. Would you like to explore what's behind this mood together?"
      ],
      neutral: [
        "I'm here to support your creative journey. What would you like to explore today?",
        "Ready to dive into something meaningful? I can sense your potential energy building.",
        "There's something wonderful about these balanced moments. What direction calls to you?"
      ],
      high: [
        "I can feel your positive energy radiating! This is perfect timing for creative exploration.",
        "Your vibrant state is inspiring. What amazing ideas are flowing through you right now?",
        "This energy is beautiful - let's channel it into something extraordinary together."
      ]
    };

    let messageType: keyof typeof messages = 'neutral';
    if (orbState.mood <= 2) messageType = 'low';
    else if (orbState.mood >= 4) messageType = 'high';

    const messageArray = messages[messageType];
    const randomMessage = messageArray[Math.floor(Math.random() * messageArray.length)];
    setOrbMessage(randomMessage);
  }, [orbState.mood]);

  const handleOrbClick = () => {
    setIsInteractive(!isInteractive);
    setOrbState(prev => ({ ...prev, pulse: !prev.pulse }));
  };

  const adjustState = (type: keyof Pick<OrbState, 'mood' | 'energy' | 'focus' | 'creativity'>, delta: number) => {
    setOrbState(prev => ({
      ...prev,
      [type]: Math.max(1, Math.min(5, prev[type] + delta))
    }));
  };

  const getOrbSize = () => {
    const baseSize = 120;
    const energyMultiplier = orbState.energy * 0.1;
    return baseSize + (energyMultiplier * 20);
  };

  const getEmotionIcon = () => {
    if (orbState.mood <= 2) return <Frown className="w-6 h-6" />;
    if (orbState.mood >= 4) return <Smile className="w-6 h-6" />;
    return <Meh className="w-6 h-6" />;
  };

  const getStateDescription = () => {
    const descriptions = {
      mood: ['Struggling', 'Low', 'Balanced', 'Good', 'Excellent'],
      energy: ['Drained', 'Low', 'Moderate', 'High', 'Vibrant'],
      focus: ['Scattered', 'Distracted', 'Centered', 'Sharp', 'Laser-focused'],
      creativity: ['Blocked', 'Limited', 'Flowing', 'Inspired', 'Explosive']
    };

    return {
      mood: descriptions.mood[orbState.mood - 1],
      energy: descriptions.energy[orbState.energy - 1],
      focus: descriptions.focus[orbState.focus - 1],
      creativity: descriptions.creativity[orbState.creativity - 1]
    };
  };

  const stateDesc = getStateDescription();

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center space-x-2">
          <Circle className="w-5 h-5 text-purple-600" />
          <span>Your Personal Orb</span>
        </CardTitle>
        <CardDescription>
          A visual representation of your creative and emotional state
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-8">
        {/* Main Orb Display */}
        <div className="flex flex-col items-center space-y-6">
          <div 
            className="relative cursor-pointer transition-all duration-500 hover:scale-105"
            onClick={handleOrbClick}
            style={{
              width: `${getOrbSize()}px`,
              height: `${getOrbSize()}px`,
            }}
          >
            {/* Outer glow ring */}
            <div 
              className={`absolute inset-0 rounded-full ${orbState.pulse ? 'animate-pulse' : ''}`}
              style={{
                background: `radial-gradient(circle, ${orbState.color}20 0%, transparent 70%)`,
                transform: 'scale(1.3)'
              }}
            />
            
            {/* Main orb */}
            <div 
              className={`relative w-full h-full rounded-full flex items-center justify-center ${
                orbState.pulse ? 'animate-pulse' : ''
              }`}
              style={{
                background: `radial-gradient(circle at 30% 30%, ${orbState.color}80, ${orbState.color})`,
                boxShadow: `0 8px 32px ${orbState.color}40`,
              }}
            >
              {/* Inner reflection */}
              <div 
                className="absolute top-4 left-4 w-8 h-8 rounded-full opacity-40"
                style={{
                  background: 'linear-gradient(45deg, rgba(255,255,255,0.8), transparent)'
                }}
              />
              
              {/* Emotion icon */}
              <div className="text-white">
                {getEmotionIcon()}
              </div>
              
              {/* Energy particles */}
              {orbState.energy >= 4 && (
                <div className="absolute inset-0">
                  {[...Array(6)].map((_, i) => (
                    <Sparkles 
                      key={i}
                      className="absolute w-3 h-3 text-white opacity-60 animate-ping"
                      style={{
                        top: `${20 + Math.random() * 60}%`,
                        left: `${20 + Math.random() * 60}%`,
                        animationDelay: `${i * 0.5}s`
                      }}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Orb Message */}
          <div className="text-center max-w-md">
            <p className="text-sm text-muted-foreground italic">
              "{orbMessage}"
            </p>
          </div>
        </div>

        {/* State Controls */}
        {isInteractive && (
          <div className="space-y-6 animate-in slide-in-from-bottom duration-300">
            <div className="grid grid-cols-2 gap-6">
              {/* Mood Control */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Heart className="w-4 h-4 text-pink-500" />
                  <span className="text-sm font-medium">Mood</span>
                  <Badge variant="secondary">{stateDesc.mood}</Badge>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => adjustState('mood', -1)}
                    disabled={orbState.mood <= 1}
                  >
                    -
                  </Button>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map(level => (
                      <div
                        key={level}
                        className={`w-3 h-3 rounded-full ${
                          level <= orbState.mood ? 'bg-pink-500' : 'bg-gray-200'
                        }`}
                      />
                    ))}
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => adjustState('mood', 1)}
                    disabled={orbState.mood >= 5}
                  >
                    +
                  </Button>
                </div>
              </div>

              {/* Energy Control */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Zap className="w-4 h-4 text-yellow-500" />
                  <span className="text-sm font-medium">Energy</span>
                  <Badge variant="secondary">{stateDesc.energy}</Badge>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => adjustState('energy', -1)}
                    disabled={orbState.energy <= 1}
                  >
                    -
                  </Button>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map(level => (
                      <div
                        key={level}
                        className={`w-3 h-3 rounded-full ${
                          level <= orbState.energy ? 'bg-yellow-500' : 'bg-gray-200'
                        }`}
                      />
                    ))}
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => adjustState('energy', 1)}
                    disabled={orbState.energy >= 5}
                  >
                    +
                  </Button>
                </div>
              </div>

              {/* Focus Control */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Target className="w-4 h-4 text-blue-500" />
                  <span className="text-sm font-medium">Focus</span>
                  <Badge variant="secondary">{stateDesc.focus}</Badge>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => adjustState('focus', -1)}
                    disabled={orbState.focus <= 1}
                  >
                    -
                  </Button>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map(level => (
                      <div
                        key={level}
                        className={`w-3 h-3 rounded-full ${
                          level <= orbState.focus ? 'bg-blue-500' : 'bg-gray-200'
                        }`}
                      />
                    ))}
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => adjustState('focus', 1)}
                    disabled={orbState.focus >= 5}
                  >
                    +
                  </Button>
                </div>
              </div>

              {/* Creativity Control */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Brain className="w-4 h-4 text-purple-500" />
                  <span className="text-sm font-medium">Creativity</span>
                  <Badge variant="secondary">{stateDesc.creativity}</Badge>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => adjustState('creativity', -1)}
                    disabled={orbState.creativity <= 1}
                  >
                    -
                  </Button>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map(level => (
                      <div
                        key={level}
                        className={`w-3 h-3 rounded-full ${
                          level <= orbState.creativity ? 'bg-purple-500' : 'bg-gray-200'
                        }`}
                      />
                    ))}
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => adjustState('creativity', 1)}
                    disabled={orbState.creativity >= 5}
                  >
                    +
                  </Button>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap gap-2 justify-center">
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => {
                  setOrbState(prev => ({
                    ...prev,
                    mood: 5,
                    energy: 5,
                    focus: 5,
                    creativity: 5
                  }));
                }}
              >
                <Star className="w-4 h-4 mr-1" />
                Peak State
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => {
                  setOrbState(prev => ({
                    ...prev,
                    mood: 3,
                    energy: 3,
                    focus: 3,
                    creativity: 3
                  }));
                }}
              >
                <Compass className="w-4 h-4 mr-1" />
                Reset Balance
              </Button>
            </div>
          </div>
        )}

        {/* Interactive Hint */}
        {!isInteractive && (
          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              Click the orb to interact and adjust your creative state
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}