import { useFirebase } from "@/hooks/useFirebase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { signInAnonymously, signOut } from "firebase/auth";
import { collection, addDoc, getDocs } from "firebase/firestore";
import { useState } from "react";

export function FirebaseTest() {
  const { user, loading, auth, db } = useFirebase();
  const [testResult, setTestResult] = useState<string>("");

  const handleSignIn = async () => {
    try {
      await signInAnonymously(auth);
      setTestResult("✅ Anonymous sign-in successful!");
    } catch (error) {
      setTestResult(`❌ Sign-in error: ${error}`);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setTestResult("✅ Sign-out successful!");
    } catch (error) {
      setTestResult(`❌ Sign-out error: ${error}`);
    }
  };

  const testFirestore = async () => {
    try {
      // Add a test document
      const docRef = await addDoc(collection(db, "test"), {
        message: "Hello Firebase!",
        timestamp: new Date()
      });
      setTestResult(`✅ Firestore test successful! Doc ID: ${docRef.id}`);
    } catch (error) {
      setTestResult(`❌ Firestore error: ${error}`);
    }
  };

  if (loading) {
    return <div>Loading Firebase...</div>;
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Firebase Integration Test</CardTitle>
        <CardDescription>
          Test Firebase services: Authentication, Firestore, and Analytics
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h4 className="text-sm font-medium mb-2">Authentication Status:</h4>
          <p className="text-sm text-muted-foreground">
            {user ? `Signed in as: ${user.uid}` : "Not signed in"}
          </p>
        </div>

        <div className="flex gap-2">
          {!user ? (
            <Button onClick={handleSignIn} size="sm">
              Sign In Anonymously
            </Button>
          ) : (
            <Button onClick={handleSignOut} variant="outline" size="sm">
              Sign Out
            </Button>
          )}
        </div>

        <Button onClick={testFirestore} className="w-full" size="sm">
          Test Firestore
        </Button>

        {testResult && (
          <div className="p-3 bg-muted rounded-md">
            <p className="text-sm">{testResult}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}