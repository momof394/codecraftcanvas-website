import { useState } from "react";
import { motion } from "framer-motion";
import { Zap, Play, Square, Save } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BreathingSection() {
  const [activeExercise, setActiveExercise] = useState<string | null>(null);
  const [timerCount, setTimerCount] = useState(5);
  const [timerActive, setTimerActive] = useState(false);

  const breathingExercises = [
    {
      id: "4-7-8",
      name: "4-7-8 Breathing",
      description: "For anxiety relief",
      color: "hsl(198, 71%, 73%)",
      instructions: "Inhale for 4, hold for 7, exhale for 8"
    },
    {
      id: "box",
      name: "Box Breathing",
      description: "For focus and calm",
      color: "hsl(142, 28%, 59%)",
      instructions: "Inhale for 4, hold for 4, exhale for 4, hold for 4"
    }
  ];

  const startTimer = () => {
    if (timerActive) return;
    
    setTimerActive(true);
    let count = 5;
    setTimerCount(count);
    
    const interval = setInterval(() => {
      count--;
      setTimerCount(count);
      
      if (count <= 0) {
        clearInterval(interval);
        setTimerCount(0);
        setTimeout(() => {
          setTimerCount(5);
          setTimerActive(false);
        }, 2000);
      }
    }, 1000);
  };

  const startBreathing = (exerciseId: string) => {
    setActiveExercise(exerciseId);
    // Here you would implement the breathing animation logic
  };

  return (
    <div className="bg-white rounded-3xl p-8 shadow-lg border border-[hsl(142,28%,59%)]/10">
      <div className="flex items-center mb-6">
        <div className="w-12 h-12 rounded-full gradient-calm flex items-center justify-center mr-4">
          <Zap className="text-white" size={20} />
        </div>
        <h2 className="text-2xl font-medium text-[hsl(0,0%,36%)]" style={{ fontFamily: 'Poppins' }}>
          Breathe & Ground
        </h2>
      </div>
      
      {/* Breathing Exercise Options */}
      <div className="space-y-4 mb-6">
        {breathingExercises.map((exercise) => (
          <motion.button
            key={exercise.id}
            className={`w-full p-4 rounded-2xl transition-all duration-300 text-left group ${
              activeExercise === exercise.id 
                ? 'bg-[hsl(198,71%,73%)]/20 border-2 border-[hsl(198,71%,73%)]/40'
                : 'bg-[hsl(198,71%,73%)]/10 hover:bg-[hsl(198,71%,73%)]/20'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => startBreathing(exercise.id)}
          >
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-medium text-[hsl(0,0%,36%)] group-hover:text-[hsl(198,71%,73%)] transition-colors">
                  {exercise.name}
                </h3>
                <p className="text-sm text-[hsl(0,0%,36%)]/70">{exercise.description}</p>
                {activeExercise === exercise.id && (
                  <p className="text-xs text-[hsl(198,71%,73%)] mt-1">{exercise.instructions}</p>
                )}
              </div>
              {activeExercise === exercise.id ? (
                <Square className="text-[hsl(198,71%,73%)]" size={20} />
              ) : (
                <Play className="text-[hsl(198,71%,73%)]" size={20} />
              )}
            </div>
          </motion.button>
        ))}
      </div>
      
      {/* 5-Second Rule Timer */}
      <div className="p-4 rounded-2xl bg-[hsl(162,40%,72%)]/10 border border-[hsl(162,40%,72%)]/20">
        <h4 className="font-medium text-[hsl(0,0%,36%)] mb-3">5-Second Rule Timer</h4>
        <div className="flex items-center justify-between">
          <motion.div 
            className="text-3xl font-bold text-[hsl(162,40%,72%)]"
            animate={{ scale: timerActive && timerCount > 0 ? [1, 1.1, 1] : 1 }}
            transition={{ duration: 1, repeat: timerActive ? Infinity : 0 }}
          >
            {timerCount === 0 ? "Go!" : timerCount}
          </motion.div>
          <Button
            onClick={startTimer}
            disabled={timerActive}
            className="px-6 py-2 bg-[hsl(162,40%,72%)] text-white rounded-full hover:bg-[hsl(162,40%,72%)]/90 transition-colors duration-300"
          >
            {timerActive ? "Running..." : "Start"}
          </Button>
        </div>
        <p className="text-xs text-[hsl(0,0%,36%)]/70 mt-2">
          Count down from 5 to overcome decision paralysis
        </p>
      </div>
    </div>
  );
}