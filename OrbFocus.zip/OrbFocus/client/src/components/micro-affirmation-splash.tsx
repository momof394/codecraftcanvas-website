import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  X, 
  Sparkles, 
  Heart, 
  Star, 
  Zap, 
  Lightbulb,
  Palette,
  Target,
  Rocket,
  Sun,
  Coffee,
  CheckCircle
} from "lucide-react";

interface Affirmation {
  id: string;
  text: string;
  category: "creativity" | "productivity" | "confidence" | "inspiration";
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  gradient: string;
}

const affirmations: Affirmation[] = [
  {
    id: "creative-1",
    text: "Your creative vision brings unique value to the world. Today's designs will inspire others.",
    category: "creativity",
    icon: Palette,
    color: "text-purple-600",
    gradient: "from-purple-400 to-pink-400"
  },
  {
    id: "creative-2", 
    text: "Every stroke, every pixel, every decision you make is building something extraordinary.",
    category: "creativity",
    icon: Sparkles,
    color: "text-blue-600",
    gradient: "from-blue-400 to-cyan-400"
  },
  {
    id: "productive-1",
    text: "You have the power to transform ideas into reality. Today is full of possibilities.",
    category: "productivity",
    icon: Rocket,
    color: "text-green-600",
    gradient: "from-green-400 to-emerald-400"
  },
  {
    id: "productive-2",
    text: "Your organized approach and attention to detail will lead to remarkable results today.",
    category: "productivity",
    icon: Target,
    color: "text-orange-600",
    gradient: "from-orange-400 to-red-400"
  },
  {
    id: "confidence-1",
    text: "You are a skilled creator. Trust your instincts and let your talent shine through.",
    category: "confidence",
    icon: Star,
    color: "text-yellow-600",
    gradient: "from-yellow-400 to-orange-400"
  },
  {
    id: "confidence-2",
    text: "Your creative challenges today are opportunities to showcase your problem-solving brilliance.",
    category: "confidence",
    icon: Zap,
    color: "text-indigo-600",
    gradient: "from-indigo-400 to-purple-400"
  },
  {
    id: "inspiration-1",
    text: "Innovation flows through you. Today's work will push creative boundaries forward.",
    category: "inspiration",
    icon: Lightbulb,
    color: "text-amber-600",
    gradient: "from-amber-400 to-yellow-400"
  },
  {
    id: "inspiration-2",
    text: "You're building the future of design, one thoughtful creation at a time.",
    category: "inspiration",
    icon: Heart,
    color: "text-rose-600",
    gradient: "from-rose-400 to-pink-400"
  },
  {
    id: "morning-1",
    text: "Good morning, creator! Today's canvas awaits your unique artistic perspective.",
    category: "inspiration",
    icon: Sun,
    color: "text-yellow-600",
    gradient: "from-yellow-400 to-amber-400"
  },
  {
    id: "focus-1",
    text: "Your focus and dedication today will result in designs that exceed expectations.",
    category: "productivity",
    icon: Coffee,
    color: "text-brown-600",
    gradient: "from-amber-600 to-orange-600"
  }
];

interface MicroAffirmationSplashProps {
  onClose: () => void;
  onDismiss: () => void;
}

export default function MicroAffirmationSplash({ onClose, onDismiss }: MicroAffirmationSplashProps) {
  const [currentAffirmation, setCurrentAffirmation] = useState<Affirmation | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    // Get today's affirmation based on the current date
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
    const affirmationIndex = dayOfYear % affirmations.length;
    
    setCurrentAffirmation(affirmations[affirmationIndex]);
    
    // Animate in
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 300);
  };

  const handleDismissForToday = () => {
    setIsVisible(false);
    setTimeout(onDismiss, 300);
  };

  if (!currentAffirmation) return null;

  const Icon = currentAffirmation.icon;
  const timeOfDay = new Date().getHours() < 12 ? "morning" : new Date().getHours() < 18 ? "afternoon" : "evening";
  const greeting = `Good ${timeOfDay}`;

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm transition-opacity duration-300 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      <Card className={`w-full max-w-md transform transition-all duration-300 ${isVisible ? 'scale-100 translate-y-0' : 'scale-95 translate-y-4'} shadow-2xl border-2`}>
        <CardContent className="p-0">
          {/* Header with gradient */}
          <div className={`relative overflow-hidden bg-gradient-to-br ${currentAffirmation.gradient} p-6 text-white`}>
            <div className="absolute top-0 right-0 p-3">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleClose}
                className="h-8 w-8 p-0 text-white/80 hover:text-white hover:bg-white/20"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <Icon className="w-8 h-8 text-white" />
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium opacity-90">{greeting}!</p>
                <h2 className="text-lg font-bold">Daily Creative Affirmation</h2>
              </div>
            </div>
          </div>

          {/* Affirmation Content */}
          <div className="p-6 space-y-6">
            <div className="text-center space-y-4">
              <blockquote className="text-lg font-medium text-foreground leading-relaxed">
                "{currentAffirmation.text}"
              </blockquote>
              
              <div className="flex justify-center">
                <Badge variant="secondary" className="capitalize">
                  {currentAffirmation.category}
                </Badge>
              </div>
            </div>

            <Separator />

            {/* Action buttons */}
            <div className="space-y-3">
              <Button 
                onClick={handleClose}
                className="w-full"
                size="lg"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Continue to Studio
              </Button>
              
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowDetails(!showDetails)}
                  className="flex-1 text-sm"
                  size="sm"
                >
                  {showDetails ? 'Hide' : 'Show'} Details
                </Button>
                
                <Button 
                  variant="ghost" 
                  onClick={handleDismissForToday}
                  className="flex-1 text-sm"
                  size="sm"
                >
                  Skip Today
                </Button>
              </div>
            </div>

            {/* Details section */}
            {showDetails && (
              <>
                <Separator />
                <div className="space-y-3 text-sm">
                  <div className="bg-muted/30 rounded-lg p-4 space-y-2">
                    <h4 className="font-medium">Why Daily Affirmations?</h4>
                    <p className="text-muted-foreground text-xs leading-relaxed">
                      Research shows that positive self-affirmations can improve creative performance, 
                      reduce stress, and enhance problem-solving abilities. Starting your creative session 
                      with intention helps focus your mind on possibilities rather than limitations.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="text-center p-2 bg-muted/20 rounded">
                      <div className="font-medium">Today's Focus</div>
                      <div className="text-muted-foreground capitalize">{currentAffirmation.category}</div>
                    </div>
                    <div className="text-center p-2 bg-muted/20 rounded">
                      <div className="font-medium">Session Goal</div>
                      <div className="text-muted-foreground">Inspired Creation</div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}