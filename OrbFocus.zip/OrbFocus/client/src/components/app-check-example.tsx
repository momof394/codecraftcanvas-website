import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, CheckCircle, AlertCircle } from 'lucide-react';
import { getAppCheckToken, getLimitedUseAppCheckToken, callApiWithAppCheck } from '@/lib/appCheck';

export function AppCheckExample() {
  const [tokenStatus, setTokenStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [token, setToken] = useState<string>('');
  const [apiStatus, setApiStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleGetToken = async () => {
    setTokenStatus('loading');
    try {
      const appCheckToken = await getAppCheckToken();
      setToken(appCheckToken);
      setTokenStatus('success');
    } catch (error) {
      console.error('Failed to get App Check token:', error);
      setTokenStatus('error');
    }
  };

  const handleGetLimitedToken = async () => {
    setTokenStatus('loading');
    try {
      const appCheckToken = await getLimitedUseAppCheckToken();
      setToken(appCheckToken);
      setTokenStatus('success');
    } catch (error) {
      console.error('Failed to get limited use App Check token:', error);
      setTokenStatus('error');
    }
  };

  const handleApiCall = async () => {
    setApiStatus('loading');
    try {
      // Example API call with App Check
      const response = await callApiWithAppCheck('/api/protected-endpoint', {
        method: 'GET',
      });
      
      if (response.ok) {
        setApiStatus('success');
      } else {
        throw new Error('API call failed');
      }
    } catch (error) {
      console.error('API call failed:', error);
      setApiStatus('error');
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Firebase App Check Integration
        </CardTitle>
        <CardDescription>
          ReCAPTCHA v3 protection is now active for your Orb Focus Studio
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="flex items-center gap-1">
            <CheckCircle className="h-3 w-3" />
            ReCAPTCHA v3 Enabled
          </Badge>
          <Badge variant="outline">
            Site Key: 6Ldo...ZFK
          </Badge>
        </div>

        <div className="space-y-2">
          <h3 className="font-medium">App Check Token Management</h3>
          <div className="flex gap-2">
            <Button 
              onClick={handleGetToken}
              disabled={tokenStatus === 'loading'}
              variant="outline"
            >
              {tokenStatus === 'loading' ? 'Getting Token...' : 'Get App Check Token'}
            </Button>
            <Button 
              onClick={handleGetLimitedToken}
              disabled={tokenStatus === 'loading'}
              variant="outline"
            >
              {tokenStatus === 'loading' ? 'Getting Token...' : 'Get Limited Use Token'}
            </Button>
          </div>
          
          {tokenStatus === 'success' && (
            <div className="p-2 bg-green-50 dark:bg-green-900/20 rounded text-sm">
              <div className="flex items-center gap-1 text-green-700 dark:text-green-300 mb-1">
                <CheckCircle className="h-3 w-3" />
                Token obtained successfully
              </div>
              <code className="text-xs break-all">{token.substring(0, 50)}...</code>
            </div>
          )}

          {tokenStatus === 'error' && (
            <div className="p-2 bg-red-50 dark:bg-red-900/20 rounded text-sm">
              <div className="flex items-center gap-1 text-red-700 dark:text-red-300">
                <AlertCircle className="h-3 w-3" />
                Failed to get App Check token
              </div>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="font-medium">Protected API Call Example</h3>
          <Button 
            onClick={handleApiCall}
            disabled={apiStatus === 'loading'}
          >
            {apiStatus === 'loading' ? 'Making API Call...' : 'Test Protected API'}
          </Button>
          
          {apiStatus === 'success' && (
            <div className="p-2 bg-green-50 dark:bg-green-900/20 rounded text-sm">
              <div className="flex items-center gap-1 text-green-700 dark:text-green-300">
                <CheckCircle className="h-3 w-3" />
                API call succeeded with App Check protection
              </div>
            </div>
          )}

          {apiStatus === 'error' && (
            <div className="p-2 bg-red-50 dark:bg-red-900/20 rounded text-sm">
              <div className="flex items-center gap-1 text-red-700 dark:text-red-300">
                <AlertCircle className="h-3 w-3" />
                API call failed - check console for details
              </div>
            </div>
          )}
        </div>

        <div className="text-xs text-muted-foreground">
          <p>App Check helps protect your app from abuse by verifying that requests come from your authentic app.</p>
        </div>
      </CardContent>
    </Card>
  );
}