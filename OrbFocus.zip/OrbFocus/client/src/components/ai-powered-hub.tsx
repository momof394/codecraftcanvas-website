import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Sparkles, 
  Lightbulb, 
  Zap, 
  Heart, 
  Activity, 
  Target, 
  MessageCircle,
  BookOpen,
  Timer
} from "lucide-react";
import { Link } from "wouter";

interface AIInsight {
  id: string;
  type: 'mood' | 'activity' | 'suggestion' | 'goal' | 'celebration';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high';
  action?: string;
  timestamp: Date;
}

interface AIState {
  currentMood: string;
  energyLevel: number;
  focusScore: number;
  stressLevel: number;
  personalityMode: 'empathetic' | 'motivational' | 'analytical';
}

export default function AIPoweredHub() {
  const [aiState, setAIState] = useState<AIState>({
    currentMood: 'neutral',
    energyLevel: 75,
    focusScore: 60,
    stressLevel: 30,
    personalityMode: 'empathetic'
  });

  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [isThinking, setIsThinking] = useState(false);
  const [activeMode, setActiveMode] = useState<'auto' | 'guided' | 'focus'>('auto');

  // Simulate AI analysis
  const analyzeUserState = useCallback(async () => {
    setIsThinking(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Generate dynamic insights based on current state
    const newInsights: AIInsight[] = [
      {
        id: crypto.randomUUID(),
        type: 'mood',
        title: '🌸 Emotional Garden Check',
        message: 'Your emotional garden is showing beautiful growth patterns. Consider nurturing it with some gentle breathing exercises.',
        priority: 'medium',
        action: 'Start Breathing',
        timestamp: new Date()
      },
      {
        id: crypto.randomUUID(),
        type: 'suggestion',
        title: '🌿 Wellness Recommendation',
        message: 'Based on your recent patterns, a 10-minute nature meditation could help bloom your inner peace.',
        priority: 'low',
        action: 'Begin Meditation',
        timestamp: new Date()
      }
    ];

    setInsights(prev => [...newInsights, ...prev.slice(0, 3)]);
    
    // Update AI state with some randomness
    setAIState(prev => ({
      ...prev,
      energyLevel: Math.max(20, Math.min(100, prev.energyLevel + (Math.random() - 0.5) * 20)),
      focusScore: Math.max(20, Math.min(100, prev.focusScore + (Math.random() - 0.5) * 15)),
      stressLevel: Math.max(0, Math.min(80, prev.stressLevel + (Math.random() - 0.5) * 10))
    }));
    
    setIsThinking(false);
  }, []);

  // Auto-analyze periodically
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isThinking && Math.random() > 0.7) {
        analyzeUserState();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [analyzeUserState, isThinking]);

  const handleAIAction = (action: string) => {
    console.log(`AI Action triggered: ${action}`);
    // Here you would navigate to the appropriate component or trigger the action
  };

  const getPersonalityResponse = (mood: string) => {
    const responses = {
      empathetic: {
        happy: "🌸 I can sense your beautiful energy blooming today! This is wonderful to see.",
        sad: "🌿 I'm here to support you through this gentle time. Your feelings are valid and important.",
        anxious: "🍃 Let's breathe together and find some peaceful ground. You're safe in this moment.",
        neutral: "🌱 I'm sensing calm, steady energy from you today. A perfect foundation for growth."
      },
      motivational: {
        happy: "🌟 Fantastic energy! Let's harness this momentum for something amazing!",
        sad: "💪 Every garden needs rain to grow. You're building resilience right now.",
        anxious: "🎯 You've got this! Let's channel that energy into focused action.",
        neutral: "🚀 Ready to plant some seeds for an incredible day ahead!"
      },
      analytical: {
        happy: "📊 Positive indicators detected. Optimal time for creative tasks and social connection.",
        sad: "🔍 Processing emotional data. Recommend self-care protocols and gentle activities.",
        anxious: "⚡ Elevated stress patterns noted. Implementing calming strategies would be beneficial.",
        neutral: "📈 Baseline emotional state detected. Good foundation for any activity type."
      }
    };

    return responses[aiState.personalityMode as keyof typeof responses]?.[mood as keyof typeof responses.empathetic] || 
           "🌸 I'm here to support you however you need.";
  };

  return (
    <div className="min-h-screen p-4 relative">
      {/* Nature Background Elements */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-gradient-to-br from-pink-300 to-rose-200 blur-xl gentle-sway"></div>
        <div className="absolute top-1/3 right-20 w-24 h-24 rounded-full bg-gradient-to-br from-yellow-200 to-amber-300 blur-lg gentle-sway"></div>
        <div className="absolute bottom-1/4 left-1/4 w-40 h-40 rounded-full bg-gradient-to-br from-green-200 to-emerald-200 blur-2xl gentle-sway"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto">
        {/* AI Status Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 fixed-layout"
        >
          <div className="flex items-center justify-center gap-4 mb-4">
            <motion.div 
              className="relative"
              animate={{ 
                scale: isThinking ? [1, 1.1, 1] : 1,
                rotate: isThinking ? [0, 5, -5, 0] : 0
              }}
              transition={{ 
                duration: 2, 
                repeat: isThinking ? Infinity : 0 
              }}
            >
              <Brain size={48} className="text-purple-600" />
              {isThinking && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse" />
              )}
            </motion.div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-rose-600 via-pink-500 to-amber-500 bg-clip-text text-transparent">
                🌸 AI Wellness Garden 🌿
              </h1>
              <p className="text-gray-600">
                {isThinking ? "Analyzing your wellbeing..." : "Always here to support you"}
              </p>
            </div>
          </div>

          {/* Quick Access Navigation */}
          <div className="flex flex-wrap justify-center gap-4 mb-8 px-4">
            <Link href="/therapy">
              <Button className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 safe-spacing">
                <MessageCircle size={16} className="mr-2" />
                🌿 Healing Chat
              </Button>
            </Link>
            <Link href="/journal">
              <Button className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 safe-spacing">
                <BookOpen size={16} className="mr-2" />
                🌸 Journal
              </Button>
            </Link>
            <Link href="/home">
              <Button className="bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 safe-spacing">
                <Timer size={16} className="mr-2" />
                🍃 Tools
              </Button>
            </Link>
          </div>
        </motion.div>

        <div className="grid-container">
          {/* AI Insights Panel */}
          <div className="space-y-6 fixed-layout">
            {/* Current AI Analysis */}
            <Card className="glass-effect border-rose-200/30 shadow-2xl backdrop-blur-sm bloom-effect">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-rose-800">
                  <div className="relative">
                    <Sparkles className="text-amber-500" />
                    <div className="absolute inset-0 text-pink-400 animate-pulse">🌸</div>
                  </div>
                  Wellness Garden Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="text-center bloom-effect">
                    <div className="text-2xl font-bold text-emerald-600 flex items-center justify-center gap-1">
                      🌱 {aiState.energyLevel}%
                    </div>
                    <div className="text-sm text-rose-700">Energy Bloom</div>
                    <Progress value={aiState.energyLevel} className="mt-1 bg-green-100" />
                  </div>
                  <div className="text-center bloom-effect" style={{ animationDelay: '0.2s' }}>
                    <div className="text-2xl font-bold text-violet-600 flex items-center justify-center gap-1">
                      🌺 {aiState.focusScore}%
                    </div>
                    <div className="text-sm text-rose-700">Focus Flower</div>
                    <Progress value={aiState.focusScore} className="mt-1 bg-purple-100" />
                  </div>
                  <div className="text-center bloom-effect" style={{ animationDelay: '0.4s' }}>
                    <div className="text-2xl font-bold text-amber-600 flex items-center justify-center gap-1">
                      🍃 {100 - aiState.stressLevel}%
                    </div>
                    <div className="text-sm text-rose-700">Peaceful Leaves</div>
                    <Progress value={100 - aiState.stressLevel} className="mt-1 bg-amber-100" />
                  </div>
                </div>
                
                <div className="glass-effect rounded-lg p-4 border border-pink-200/30">
                  <p className="text-rose-800 mb-3 flex items-center gap-2">
                    <span className="text-lg">🌸</span>
                    {getPersonalityResponse(aiState.currentMood)}
                  </p>
                  <Button 
                    onClick={analyzeUserState}
                    disabled={isThinking}
                    className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shimmer bloom-effect"
                  >
                    <Brain size={16} className="mr-2" />
                    {isThinking ? "🌱 Growing insights..." : "🌺 Bloom fresh insights"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* AI Insights Feed */}
            <Card className="glass-effect border-amber-200/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-rose-800">
                  <div className="relative">
                    <Lightbulb className="text-amber-500" />
                    <span className="absolute -top-1 -right-1 text-xs">✨</span>
                  </div>
                  Garden Wisdom & Growth
                </CardTitle>
              </CardHeader>
              <CardContent>
                <AnimatePresence>
                  {insights.length === 0 ? (
                    <div className="text-center py-8 text-rose-600">
                      <div className="text-6xl mb-4 gentle-sway">🌱</div>
                      <p className="flex items-center justify-center gap-2">
                        <span>🌸</span> Your garden is growing... <span>🌿</span>
                      </p>
                      <p className="text-sm text-rose-500">Wisdom blooms as patterns emerge</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {insights.map((insight) => (
                        <motion.div
                          key={insight.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 20 }}
                          className="glass-effect rounded-lg p-4 border-l-4 border-rose-400 bloom-effect"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                {insight.type === 'mood' && <span className="text-lg">💖</span>}
                                {insight.type === 'activity' && <span className="text-lg">🌿</span>}
                                {insight.type === 'suggestion' && <span className="text-lg">💡</span>}
                                {insight.type === 'goal' && <span className="text-lg">🎯</span>}
                                {insight.type === 'celebration' && <span className="text-lg">🌸</span>}
                                <h3 className="font-semibold text-rose-800">{insight.title}</h3>
                                <Badge variant={insight.priority === 'high' ? 'destructive' : insight.priority === 'medium' ? 'default' : 'secondary'}>
                                  {insight.priority}
                                </Badge>
                              </div>
                              <p className="text-rose-700 mb-3">{insight.message}</p>
                              {insight.action && (
                                <Button
                                  size="sm"
                                  onClick={() => handleAIAction(insight.action!)}
                                  className="bg-gradient-to-r from-rose-500 via-pink-500 to-amber-400 hover:from-rose-600 hover:via-pink-600 hover:to-amber-500 shimmer"
                                >
                                  <Zap size={14} className="mr-1" />
                                  {insight.action}
                                </Button>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* AI-Powered Quick Actions */}
          <div className="space-y-6">
            <Card className="glass-effect border-emerald-200/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-rose-800">
                  <span className="text-lg">🌺</span>
                  Garden Tools
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/therapy">
                  <Button className="w-full bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 bloom-effect">
                    <span className="mr-2">🌿</span>
                    Healing Garden Chat
                  </Button>
                </Link>
                <Link href="/journal">
                  <Button className="w-full bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 bloom-effect">
                    <span className="mr-2">🌸</span>
                    Blossom Journal
                  </Button>
                </Link>
                <Link href="/home">
                  <Button className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 bloom-effect">
                    <span className="mr-2">🍃</span>
                    Focus Sanctuary
                  </Button>
                </Link>
                <Button className="w-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 bloom-effect">
                  <span className="mr-2">💖</span>
                  Heart Garden
                </Button>
              </CardContent>
            </Card>

            {/* AI Mode Selection */}
            <Card className="glass-effect border-violet-200/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-rose-800">🧠 AI Garden Mode</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {['auto', 'guided', 'focus'].map((mode) => (
                    <Button
                      key={mode}
                      variant={activeMode === mode ? "default" : "outline"}
                      className="w-full justify-start capitalize bloom-effect"
                      onClick={() => setActiveMode(mode as any)}
                    >
                      {mode === 'auto' && <span className="mr-2">🌱</span>}
                      {mode === 'guided' && <span className="mr-2">🌸</span>}
                      {mode === 'focus' && <span className="mr-2">🍃</span>}
                      {mode} Garden
                    </Button>
                  ))}
                </div>
                <div className="mt-4 p-3 glass-effect rounded-lg border border-pink-200/30">
                  <p className="text-sm text-rose-700">
                    {activeMode === 'auto' && "🌱 Garden grows naturally with your patterns"}
                    {activeMode === 'guided' && "🌸 Gentle guidance through each blossom"}
                    {activeMode === 'focus' && "🍃 Deep focus sanctuary for concentration"}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}