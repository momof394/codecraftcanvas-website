import { useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle, Clock } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const defaultTasks = [
  {
    title: "Make the bed (or just pull the covers up)",
    description: "Any version counts!",
    estimatedTime: 2,
    color: "hsl(162, 40%, 72%)"
  },
  {
    title: "Tidy one small area",
    description: "Even clearing one surface is amazing!",
    estimatedTime: 5,
    color: "hsl(198, 71%, 73%)"
  },
  {
    title: "Take vitamins/meds",
    description: "Taking care of your health matters",
    estimatedTime: 1,
    color: "hsl(162, 40%, 72%)"
  },
  {
    title: "Drink a full glass of water",
    description: "Hydration is self-care!",
    estimatedTime: 1,
    color: "hsl(198, 71%, 73%)"
  }
];

export default function ChoreChart() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tasks = [] } = useQuery({
    queryKey: ["/api/tasks"],
  });

  const createTaskMutation = useMutation({
    mutationFn: async (task: any) => {
      const response = await apiRequest("POST", "/api/tasks", task);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: any }) => {
      const response = await apiRequest("PUT", `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  // Initialize default tasks if none exist
  useState(() => {
    if (Array.isArray(tasks) && tasks.length === 0) {
      defaultTasks.forEach(task => {
        createTaskMutation.mutate(task);
      });
    }
  });

  const toggleTask = (taskId: string, completed: boolean) => {
    updateTaskMutation.mutate({
      id: taskId,
      updates: { completed: !completed }
    });

    if (!completed) {
      toast({
        description: "✨ You did it! Well done! Every step counts! 💚",
      });
    }
  };

  const taskArray = Array.isArray(tasks) ? tasks : [];
  const completedTasks = taskArray.filter((task: any) => task.completed).length;
  const totalTasks = taskArray.length;
  const progressPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  return (
    <section className="mb-16">
      <div className="bg-white rounded-3xl p-8 shadow-lg border border-[hsl(142,28%,59%)]/10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full gradient-sage flex items-center justify-center mr-4">
              <CheckCircle className="text-white" size={20} />
            </div>
            <h2 className="text-2xl font-medium text-[hsl(0,0%,36%)]" style={{ fontFamily: 'Poppins' }}>
              Today's Tasks
            </h2>
          </div>
          <span className="text-sm text-[hsl(142,28%,59%)] font-medium bg-[hsl(142,28%,59%)]/10 px-3 py-1 rounded-full">
            Good enough is perfect! ✨
          </span>
        </div>
        
        <div className="space-y-3">
          {taskArray.map((task: any) => (
            <motion.div
              key={task.id}
              className="flex items-center p-4 rounded-2xl bg-[hsl(49,37%,97%)]/80 hover:bg-[hsl(142,28%,59%)]/5 transition-colors duration-300 group"
              whileHover={{ x: 5 }}
            >
              <motion.button
                className={`w-6 h-6 rounded-full border-2 transition-all duration-300 mr-4 flex items-center justify-center ${
                  task.completed
                    ? 'border-[hsl(142,28%,59%)] bg-[hsl(142,28%,59%)]'
                    : 'border-[hsl(142,28%,59%)]/40 hover:border-[hsl(142,28%,59%)] hover:bg-[hsl(142,28%,59%)]/20'
                }`}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => toggleTask(task.id, task.completed)}
              >
                {task.completed && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <CheckCircle className="text-white" size={14} />
                  </motion.div>
                )}
              </motion.button>
              
              <div className="flex-1">
                <h4 className={`font-medium text-[hsl(0,0%,36%)] ${
                  task.completed ? 'line-through opacity-60' : ''
                }`}>
                  {task.title}
                </h4>
                <p className={`text-xs ${
                  task.completed 
                    ? 'text-[hsl(162,40%,72%)]' 
                    : 'text-[hsl(0,0%,36%)]/60'
                }`}>
                  {task.completed ? '✨ You did it! Well done!' : task.description}
                </p>
              </div>
              
              <span className={`text-xs px-2 py-1 rounded-full flex items-center ${
                task.completed
                  ? 'text-[hsl(162,40%,72%)] bg-[hsl(162,40%,72%)]/10'
                  : 'text-[hsl(198,71%,73%)] bg-[hsl(198,71%,73%)]/10'
              }`}>
                {task.completed ? (
                  'Done!'
                ) : (
                  <>
                    <Clock size={10} className="mr-1" />
                    {task.estimatedTime} min
                  </>
                )}
              </span>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-6 p-4 rounded-2xl bg-[hsl(162,40%,72%)]/10 border border-[hsl(162,40%,72%)]/20">
          <div className="flex items-center justify-between">
            <span className="text-[hsl(0,0%,36%)] font-medium">Today's Progress</span>
            <span className="text-[hsl(162,40%,72%)] font-bold">
              {completedTasks}/{totalTasks} Complete
            </span>
          </div>
          <div className="w-full bg-[hsl(162,40%,72%)]/20 rounded-full h-3 mt-3 overflow-hidden">
            <motion.div
              className="bg-[hsl(162,40%,72%)] h-3 rounded-full transition-all duration-500"
              initial={{ width: 0 }}
              animate={{ width: `${progressPercentage}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
          </div>
          <p className="text-xs text-[hsl(0,0%,36%)]/70 mt-2">
            Remember: Progress, not perfection! 💚
          </p>
        </div>
      </div>
    </section>
  );
}