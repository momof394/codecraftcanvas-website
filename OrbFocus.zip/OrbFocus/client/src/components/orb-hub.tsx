import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, Leaf, Wind, Target, Moon } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const moodConfig = {
  calm: {
    icon: Leaf,
    color: "hsl(142, 28%, 59%)",
    gradient: "linear-gradient(135deg, hsl(142, 28%, 59%) 0%, hsl(162, 40%, 72%) 100%)",
    text: "Feeling calm and centered",
    className: "gradient-sage"
  },
  anxious: {
    icon: Wind,
    color: "hsl(198, 71%, 73%)",
    gradient: "linear-gradient(135deg, hsl(198, 71%, 73%) 0%, hsl(198, 71%, 83%) 100%)",
    text: "Feeling anxious, need gentle support",
    className: "gradient-calm"
  },
  focused: {
    icon: Target,
    color: "hsl(162, 40%, 72%)",
    gradient: "linear-gradient(135deg, hsl(162, 40%, 72%) 0%, hsl(198, 71%, 73%) 100%)",
    text: "Ready to focus and be productive",
    className: ""
  },
  tired: {
    icon: Moon,
    color: "hsl(39, 37%, 69%)",
    gradient: "linear-gradient(135deg, hsl(39, 37%, 69%) 0%, hsl(41, 40%, 75%) 100%)",
    text: "Feeling tired, need rest and care",
    className: ""
  }
};

export default function OrbHub() {
  const queryClient = useQueryClient();

  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (updates: any) => {
      const response = await apiRequest("PUT", "/api/settings", updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
  });

  const currentMood = (settings as any)?.currentMood || "calm";
  const config = moodConfig[currentMood as keyof typeof moodConfig];
  const IconComponent = config.icon;

  const handleMoodChange = (mood: string) => {
    updateSettingsMutation.mutate({ currentMood: mood });
  };

  return (
    <section className="text-center mb-16">
      <div className="relative">
        {/* Central Orb */}
        <motion.div
          className={`mx-auto w-64 h-64 rounded-full ${config.className} orb-glow animate-breathing relative overflow-hidden cursor-pointer transition-all duration-500 hover:scale-105`}
          style={!config.className ? { background: config.gradient } : {}}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handleMoodChange(currentMood)}
        >
          <motion.div 
            className="absolute inset-4 rounded-full bg-white/20"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div 
            className="absolute inset-8 rounded-full bg-white/30"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <IconComponent className="text-white text-4xl opacity-60" size={48} />
          </div>
        </motion.div>
        
        {/* Mood Selector */}
        <div className="flex justify-center space-x-4 mt-8">
          {Object.entries(moodConfig).map(([mood, moodData]) => {
            const MoodIcon = moodData.icon;
            return (
              <motion.button
                key={mood}
                className={`w-12 h-12 rounded-full text-white transition-all duration-300 ${
                  currentMood === mood ? 'scale-110 shadow-lg' : 'hover:scale-110'
                }`}
                style={{ 
                  backgroundColor: moodData.color,
                  opacity: currentMood === mood ? 1 : 0.8
                }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleMoodChange(mood)}
              >
                <MoodIcon size={20} className="mx-auto" />
              </motion.button>
            );
          })}
        </div>
        
        {/* Current Status */}
        <motion.div 
          className="mt-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-[hsl(0,0%,36%)] font-medium text-lg">
            {config.text}
          </p>
          <p className="text-[hsl(142,28%,59%)] text-sm mt-2">
            Your orb is here to support you ✨
          </p>
        </motion.div>
      </div>
    </section>
  );
}