import { Link } from "wouter";
import { Separator } from "@/components/ui/separator";
import { 
  Circle, 
  Palette, 
  Mail, 
  Phone, 
  MapPin, 
  Twitter, 
  Linkedin, 
  Github,
  ExternalLink
} from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Circle className="w-8 h-8 text-purple-400" />
                <Palette className="w-4 h-4 absolute top-1 left-1 text-purple-300" />
              </div>
              <div>
                <span className="text-xl font-bold">Orb Focus Studio</span>
                <span className="block text-sm text-gray-400">Design • Productivity • Create</span>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Professional digital design and productivity platform empowering creators, teams, and businesses 
              to bring their visual ideas to life through innovative tools and streamlined workflows.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                <Github className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Product Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Platform</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/editor" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Design Studio
                </Link>
              </li>
              <li>
                <Link href="/templates" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Templates
                </Link>
              </li>
              <li>
                <Link href="/assets" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Asset Library
                </Link>
              </li>
              <li>
                <Link href="/orb-canvas" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Orb Canvas Studio
                </Link>
              </li>
              <li>
                <Link href="/journal" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Project Hub
                </Link>
              </li>
              <li>
                <Link href="/exports" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Export Tools
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/blog" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Design Blog
                </Link>
              </li>
              <li>
                <Link href="/resources" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Tutorials & Guides
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white transition-colors text-sm">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Pricing Plans
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm flex items-center">
                  API Documentation
                  <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Community Forum
                </a>
              </li>
            </ul>
          </div>

          {/* Support & Legal */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Support</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Contact Support
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Feature Requests
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm">
                  System Status
                </a>
              </li>
            </ul>
            
            <h4 className="text-sm font-semibold text-gray-400 mt-6">Legal</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/privacy" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Terms of Service
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Cookie Policy
                </a>
              </li>
            </ul>
          </div>
        </div>

        <Separator className="my-8 bg-gray-700" />

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-sm text-gray-400">
            © {currentYear} Orb Focus Studio. All rights reserved.
          </div>
          
          <div className="flex items-center space-x-6 text-sm text-gray-400">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4" />
              <span>San Francisco, CA</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="w-4 h-4" />
              <a href="mailto:hello@orbfocus.studio" className="hover:text-white transition-colors">
                hello@orbfocus.studio
              </a>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-8 pt-6 border-t border-gray-700">
          <div className="text-center">
            <p className="text-xs text-gray-500 max-w-4xl mx-auto leading-relaxed">
              Orb Focus Studio is a comprehensive digital design and productivity platform designed for modern creators, 
              businesses, and teams. Our platform combines professional-grade design tools with project management features, 
              enabling users to create, collaborate, and deliver exceptional digital content. From startups to enterprises, 
              our tools help streamline creative workflows and boost productivity across all industries.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}