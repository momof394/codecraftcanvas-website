import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Brain, Save, Trash2 } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequestWithData } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function BrainDump() {
  const [content, setContent] = useState("");
  const [currentEntryId, setCurrentEntryId] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState("Auto-saved");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: journalEntries } = useQuery({
    queryKey: ["/api/journal"],
  });

  const createEntryMutation = useMutation({
    mutationFn: async (data: { content: string }) => {
      return await apiRequestWithData("POST", "/api/journal", data);
    },
    onSuccess: (data) => {
      setCurrentEntryId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      setSaveStatus("Auto-saved");
    },
  });

  const updateEntryMutation = useMutation({
    mutationFn: async ({ id, content }: { id: string; content: string }) => {
      return await apiRequestWithData("PUT", `/api/journal/${id}`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      setSaveStatus("Auto-saved");
    },
  });

  const deleteEntryMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequestWithData("DELETE", `/api/journal/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      setContent("");
      setCurrentEntryId(null);
      setSaveStatus("Cleared");
      toast({
        description: "Brain dump cleared! 🌟",
      });
    },
  });

  // Load the most recent entry
  useEffect(() => {
    if (journalEntries && Array.isArray(journalEntries) && journalEntries.length > 0 && !currentEntryId) {
      const latestEntry = journalEntries[0];
      setContent(latestEntry.content);
      setCurrentEntryId(latestEntry.id);
    }
  }, [journalEntries, currentEntryId]);

  // Auto-save functionality
  useEffect(() => {
    if (!content.trim()) return;

    setSaveStatus("Saving...");
    const timeoutId = setTimeout(() => {
      if (currentEntryId) {
        updateEntryMutation.mutate({ id: currentEntryId, content });
      } else {
        createEntryMutation.mutate({ content });
      }
    }, 2000);

    return () => clearTimeout(timeoutId);
  }, [content]);

  const handleClear = () => {
    if (currentEntryId) {
      deleteEntryMutation.mutate(currentEntryId);
    } else {
      setContent("");
      setSaveStatus("Cleared");
      toast({
        description: "Brain dump cleared! 🌟",
      });
    }
  };

  return (
    <div className="bg-white rounded-3xl p-8 shadow-lg border border-[hsl(142,28%,59%)]/10">
      <div className="flex items-center mb-6">
        <div className="w-12 h-12 rounded-full gradient-warm flex items-center justify-center mr-4">
          <Brain className="text-[hsl(0,0%,36%)]" size={20} />
        </div>
        <h2 className="text-2xl font-medium text-[hsl(0,0%,36%)]" style={{ fontFamily: 'Poppins' }}>
          Brain Dump
        </h2>
      </div>
      
      <div className="relative">
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full h-48 p-4 rounded-2xl border border-[hsl(142,28%,59%)]/20 resize-none focus:outline-none focus:ring-2 focus:ring-[hsl(142,28%,59%)]/50 focus:border-[hsl(142,28%,59%)]/50 transition-all duration-300 bg-[hsl(49,37%,97%)]/50"
          placeholder="Let it all out... your thoughts, worries, or mental clutter. This space is just for you. ✨"
        />
        <motion.div 
          className="absolute bottom-4 right-4 text-xs text-[hsl(142,28%,59%)]/60 flex items-center"
          animate={{ opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Save size={12} className="mr-1" />
          <span>{saveStatus}</span>
        </motion.div>
      </div>
      
      <div className="mt-4 flex justify-between items-center text-sm text-[hsl(0,0%,36%)]/70">
        <span>No judgment here, just release 💚</span>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleClear}
          className="text-[hsl(142,28%,59%)] hover:text-[hsl(142,28%,59%)]/80 transition-colors"
        >
          <Trash2 size={14} className="mr-1" />
          Clear
        </Button>
      </div>
    </div>
  );
}