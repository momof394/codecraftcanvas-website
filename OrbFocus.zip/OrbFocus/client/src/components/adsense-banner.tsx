import { useEffect } from 'react';

declare global {
  interface Window {
    adsbygoogle: any[];
  }
}

// Home page ad component with your actual ad slot
export function HomePageAd() {
  useEffect(() => {
    try {
      if (typeof window !== 'undefined') {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      }
    } catch (err) {
      console.error('AdSense error:', err);
    }
  }, []);

  return (
    <div className="w-full my-8">
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-8064547227653641"
        data-ad-slot="1119222466"
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
}