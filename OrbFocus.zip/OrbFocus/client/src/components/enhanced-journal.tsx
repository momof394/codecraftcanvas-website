import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  BookOpen, 
  Palette, 
  Plus, 
  Save, 
  Sticker, 
  Settings, 
  Sparkles,
  Type,
  Move,
  RotateCw,
  Trash2,
  Download,
  Brain,
  Heart,
  Star
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { 
  getAiJournalEntries, 
  createAiJournalEntry, 
  updateAiJournalEntry,
  deleteAiJournalEntry,
  getCustomStickers,
  createCustomSticker,
  deleteCustomSticker,
  CustomSticker,
  JournalSticker,
  EnhancedJournalEntry,
  getUserSettings,
  updateUserSettings
} from "@/lib/localStorage";

export default function EnhancedJournal() {
  const [entries, setEntries] = useState<EnhancedJournalEntry[]>([]);
  const [currentEntry, setCurrentEntry] = useState<EnhancedJournalEntry | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("");
  const [stickers, setStickers] = useState<CustomSticker[]>([]);
  const [journalStickers, setJournalStickers] = useState<JournalSticker[]>([]);
  const [selectedSticker, setSelectedSticker] = useState<string | null>(null);
  const [stickerMode, setStickerMode] = useState(false);
  const [customization, setCustomization] = useState({
    fontFamily: 'serif',
    fontSize: 'medium',
    backgroundColor: '#ffffff',
    textColor: '#333333',
    backgroundPattern: ''
  });
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const journalRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    setEntries(getAiJournalEntries());
    setStickers(getCustomStickers());
    const settings = getUserSettings();
    if (settings && typeof settings === 'object') {
      const userSettings = settings as any;
      if (userSettings.journalCustomization) {
        setCustomization(prev => ({
          ...prev,
          ...userSettings.journalCustomization,
          backgroundPattern: userSettings.journalCustomization.backgroundPattern || ''
        }));
      }
    }
  }, []);

  const handleCreateNewEntry = () => {
    setCurrentEntry(null);
    setContent("");
    setTitle("");
    setJournalStickers([]);
    setIsEditing(true);
  };

  const handleSaveEntry = async () => {
    if (!content.trim()) {
      toast({ description: "Please write something before saving!" });
      return;
    }

    const entryData = {
      title: title || `Journal Entry - ${new Date().toLocaleDateString()}`,
      content,
      stickers: journalStickers,
      customization,
      tags: extractTags(content),
      entryType: 'free_form',
      isPrivate: true
    };

    try {
      if (currentEntry) {
        const updated = updateAiJournalEntry(currentEntry.id, entryData);
        if (updated) {
          setEntries(prev => prev.map(e => e.id === currentEntry.id ? updated : e));
          setCurrentEntry(updated);
        }
      } else {
        const newEntry = createAiJournalEntry(entryData);
        setEntries(prev => [newEntry, ...prev]);
        setCurrentEntry(newEntry);
      }
      
      setIsEditing(false);
      toast({ description: "Journal entry saved! ✨" });
      
      // Get AI analysis
      if (content.length > 50) {
        setIsAnalyzing(true);
        await analyzeWithAI(content);
      }
    } catch (error) {
      toast({ description: "Failed to save entry. Please try again." });
    }
  };

  const analyzeWithAI = async (content: string) => {
    try {
      // Simulate AI analysis for now - in real implementation this would call the AI service
      setTimeout(() => {
        const mockAnalysis = {
          sentiment: Math.random() * 2 - 1,
          emotionalTone: ['hopeful', 'reflective', 'anxious', 'grateful', 'frustrated'][Math.floor(Math.random() * 5)],
          themes: ['self-reflection', 'personal growth', 'relationships', 'stress management'].slice(0, Math.floor(Math.random() * 3) + 1),
          insights: [
            "You're showing great self-awareness in this entry.",
            "Consider celebrating the small wins you mentioned.",
            "It might help to explore these feelings further."
          ],
          recommendations: [
            "Try a 5-minute breathing exercise",
            "Consider reaching out to a friend",
            "Journal about one thing you're grateful for"
          ]
        };
        setAiAnalysis(mockAnalysis);
        setIsAnalyzing(false);
      }, 2000);
    } catch (error) {
      setIsAnalyzing(false);
    }
  };

  const extractTags = (content: string): string[] => {
    const words = content.toLowerCase().split(/\s+/);
    const emotionWords = ['happy', 'sad', 'anxious', 'grateful', 'frustrated', 'hopeful', 'tired', 'energetic'];
    const foundTags = emotionWords.filter(word => words.some(w => w.includes(word)));
    return Array.from(new Set(foundTags));
  };

  const handleStickerClick = (sticker: CustomSticker) => {
    if (!stickerMode || !journalRef.current) return;
    
    const rect = journalRef.current.getBoundingClientRect();
    const newSticker: JournalSticker = {
      stickerId: sticker.id,
      x: Math.random() * (rect.width - 50),
      y: Math.random() * (rect.height - 50),
      size: 1,
      rotation: 0
    };
    
    setJournalStickers(prev => [...prev, newSticker]);
    setStickerMode(false);
  };

  const handleCreateCustomSticker = (stickerData: { name: string; emoji?: string; color: string; category: string }) => {
    const newSticker = createCustomSticker(stickerData);
    setStickers(prev => [...prev, newSticker]);
    toast({ description: `Created custom sticker "${stickerData.name}"! 🎨` });
  };

  const fontSizeMap = {
    small: '14px',
    medium: '16px',
    large: '18px',
    xlarge: '20px'
  };

  const journalStyle = {
    fontFamily: customization.fontFamily === 'serif' ? 'Georgia, serif' : 
                customization.fontFamily === 'sans' ? 'Arial, sans-serif' : 'monospace',
    fontSize: fontSizeMap[customization.fontSize as keyof typeof fontSizeMap],
    backgroundColor: customization.backgroundColor,
    color: customization.textColor,
    backgroundImage: customization.backgroundPattern ? `url(${customization.backgroundPattern})` : 'none'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-bold text-gray-800 mb-4 flex items-center justify-center gap-3">
            <BookOpen className="text-purple-600" />
            My AI-Powered Journal
            <Sparkles className="text-pink-500" />
          </h1>
          <p className="text-gray-600">Express yourself with customizable entries and stickers</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Journal Editor */}
          <div className="lg:col-span-2">
            <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="border-b bg-gradient-to-r from-purple-100 to-pink-100">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="text-purple-600" size={20} />
                    {isEditing ? 'Create Entry' : 'Journal Entry'}
                  </CardTitle>
                  <div className="flex gap-2">
                    <JournalCustomizationDialog 
                      customization={customization}
                      onUpdate={setCustomization}
                    />
                    <Button
                      onClick={() => setStickerMode(!stickerMode)}
                      variant={stickerMode ? "default" : "outline"}
                      size="sm"
                    >
                      <Sticker size={16} />
                      Stickers
                    </Button>
                    {isEditing ? (
                      <Button onClick={handleSaveEntry} className="bg-purple-600 hover:bg-purple-700">
                        <Save size={16} className="mr-1" />
                        Save
                      </Button>
                    ) : (
                      <Button onClick={() => setIsEditing(true)} variant="outline">
                        Edit
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="p-6">
                {isEditing && (
                  <Input
                    placeholder="Entry title (optional)"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="mb-4"
                  />
                )}
                
                <div
                  ref={journalRef}
                  className="relative min-h-[400px] p-4 rounded-lg border-2 border-dashed border-gray-200"
                  style={{
                    ...journalStyle,
                    backgroundColor: customization.backgroundColor || '#ffffff',
                  }}
                >
                  {isEditing ? (
                    <Textarea
                      placeholder="What's on your mind today? Share your thoughts, feelings, or experiences..."
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      className="w-full h-96 border-none resize-none focus:ring-0"
                      style={{
                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                        color: customization.textColor || '#333333',
                        fontFamily: journalStyle.fontFamily,
                        fontSize: journalStyle.fontSize,
                      }}
                    />
                  ) : (
                    <div 
                      className="whitespace-pre-wrap p-4 min-h-[300px] rounded-lg"
                      style={{
                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                        color: customization.textColor || '#333333',
                        fontFamily: journalStyle.fontFamily,
                        fontSize: journalStyle.fontSize,
                      }}
                    >
                      {currentEntry?.content || "Start writing your first journal entry..."}
                    </div>
                  )}
                  
                  {/* Render stickers */}
                  <AnimatePresence>
                    {journalStickers.map((sticker, index) => {
                      const stickerData = stickers.find(s => s.id === sticker.stickerId);
                      if (!stickerData) return null;
                      
                      return (
                        <motion.div
                          key={index}
                          initial={{ scale: 0 }}
                          animate={{ scale: sticker.size }}
                          exit={{ scale: 0 }}
                          className="absolute cursor-pointer select-none"
                          style={{
                            left: sticker.x,
                            top: sticker.y,
                            transform: `rotate(${sticker.rotation}deg)`,
                            fontSize: `${24 * sticker.size}px`
                          }}
                          onClick={() => {
                            if (isEditing) {
                              setJournalStickers(prev => prev.filter((_, i) => i !== index));
                            }
                          }}
                        >
                          {stickerData.emoji}
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                  
                  {stickerMode && isEditing && (
                    <div className="absolute inset-0 bg-blue-100/20 border-2 border-blue-300 border-dashed rounded-lg flex items-center justify-center">
                      <p className="text-blue-600 font-medium">Click anywhere to place a sticker!</p>
                    </div>
                  )}
                </div>
                
                {/* AI Analysis */}
                {(isAnalyzing || aiAnalysis) && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border"
                  >
                    <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                      <Brain className="text-purple-600" size={18} />
                      AI Insights
                    </h3>
                    
                    {isAnalyzing ? (
                      <div className="flex items-center gap-2 text-gray-600">
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-purple-600 border-t-transparent"></div>
                        Analyzing your entry...
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div>
                          <span className="text-sm font-medium text-gray-700">Emotional Tone: </span>
                          <Badge variant="secondary">{aiAnalysis?.emotionalTone}</Badge>
                        </div>
                        
                        {aiAnalysis?.themes && (
                          <div>
                            <span className="text-sm font-medium text-gray-700">Themes: </span>
                            {aiAnalysis.themes.map((theme: string, i: number) => (
                              <Badge key={i} variant="outline" className="ml-1">
                                {theme}
                              </Badge>
                            ))}
                          </div>
                        )}
                        
                        {aiAnalysis?.recommendations && (
                          <div>
                            <p className="text-sm font-medium text-gray-700 mb-2">Recommendations:</p>
                            <ul className="text-sm text-gray-600 space-y-1">
                              {aiAnalysis.recommendations.map((rec: string, i: number) => (
                                <li key={i} className="flex items-start gap-2">
                                  <Star className="text-yellow-500 mt-0.5" size={12} />
                                  {rec}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Sticker Collection */}
            <StickerCollection
              stickers={stickers}
              onStickerClick={handleStickerClick}
              onCreateSticker={handleCreateCustomSticker}
              onDeleteSticker={(id) => {
                deleteCustomSticker(id);
                setStickers(prev => prev.filter(s => s.id !== id));
              }}
              stickerMode={stickerMode}
            />
            
            {/* Recent Entries */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Entries</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={handleCreateNewEntry}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <Plus size={16} className="mr-2" />
                  New Entry
                </Button>
                
                {entries.slice(0, 5).map((entry) => (
                  <motion.div
                    key={entry.id}
                    whileHover={{ scale: 1.02 }}
                    onClick={() => {
                      setCurrentEntry(entry);
                      setContent(entry.content);
                      setTitle(entry.title || '');
                      setJournalStickers(entry.stickers);
                      setCustomization({
                        ...entry.customization,
                        backgroundPattern: entry.customization.backgroundPattern || ''
                      });
                      setIsEditing(false);
                    }}
                    className="p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
                  >
                    <h4 className="font-medium text-sm text-gray-800 truncate">
                      {entry.title || 'Untitled Entry'}
                    </h4>
                    <p className="text-xs text-gray-600 mt-1">
                      {entry.createdAt.toLocaleDateString()}
                    </p>
                    <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                      {entry.content.substring(0, 60)}...
                    </p>
                    {entry.stickers.length > 0 && (
                      <div className="flex gap-1 mt-2">
                        {entry.stickers.slice(0, 3).map((sticker, i) => {
                          const stickerData = stickers.find(s => s.id === sticker.stickerId);
                          return stickerData ? (
                            <span key={i} className="text-xs">{stickerData.emoji}</span>
                          ) : null;
                        })}
                        {entry.stickers.length > 3 && (
                          <span className="text-xs text-gray-400">+{entry.stickers.length - 3}</span>
                        )}
                      </div>
                    )}
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// Sticker Collection Component
function StickerCollection({ 
  stickers, 
  onStickerClick, 
  onCreateSticker, 
  onDeleteSticker, 
  stickerMode 
}: {
  stickers: CustomSticker[];
  onStickerClick: (sticker: CustomSticker) => void;
  onCreateSticker: (sticker: { name: string; emoji?: string; color: string; category: string }) => void;
  onDeleteSticker: (id: string) => void;
  stickerMode: boolean;
}) {
  const [newSticker, setNewSticker] = useState({ name: '', emoji: '', color: '#FFD700', category: 'emotions' });

  const categories = Array.from(new Set(stickers.map(s => s.category)));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Sticker className="text-pink-500" />
          Sticker Collection
        </CardTitle>
        {stickerMode && (
          <p className="text-sm text-blue-600">Sticker mode active! Click a sticker to add it.</p>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {categories.map(category => (
            <div key={category}>
              <h4 className="text-sm font-medium text-gray-700 mb-2 capitalize">{category}</h4>
              <div className="grid grid-cols-5 gap-2">
                {stickers.filter(s => s.category === category).map(sticker => (
                  <motion.button
                    key={sticker.id}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => onStickerClick(sticker)}
                    className={`p-2 rounded-lg text-2xl hover:bg-gray-100 transition-colors ${
                      stickerMode ? 'ring-2 ring-blue-300 bg-blue-50' : ''
                    }`}
                    title={sticker.name}
                  >
                    {sticker.emoji}
                  </motion.button>
                ))}
              </div>
            </div>
          ))}
          
          {/* Create Sticker Dialog */}
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Plus size={16} className="mr-2" />
                Create Sticker
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Custom Sticker</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Sticker name"
                  value={newSticker.name}
                  onChange={(e) => setNewSticker(prev => ({ ...prev, name: e.target.value }))}
                />
                <Input
                  placeholder="Emoji (e.g., 😊)"
                  value={newSticker.emoji}
                  onChange={(e) => setNewSticker(prev => ({ ...prev, emoji: e.target.value }))}
                />
                <div>
                  <label className="text-sm font-medium">Color</label>
                  <Input
                    type="color"
                    value={newSticker.color}
                    onChange={(e) => setNewSticker(prev => ({ ...prev, color: e.target.value }))}
                  />
                </div>
                <Select
                  value={newSticker.category}
                  onValueChange={(value) => setNewSticker(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="emotions">Emotions</SelectItem>
                    <SelectItem value="wellness">Wellness</SelectItem>
                    <SelectItem value="achievements">Achievements</SelectItem>
                    <SelectItem value="empowerment">Empowerment</SelectItem>
                    <SelectItem value="love">Love</SelectItem>
                    <SelectItem value="hope">Hope</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  onClick={() => {
                    if (newSticker.name && newSticker.emoji) {
                      onCreateSticker(newSticker);
                      setNewSticker({ name: '', emoji: '', color: '#FFD700', category: 'emotions' });
                    }
                  }}
                  className="w-full"
                >
                  Create Sticker
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
}

// Journal Customization Dialog
function JournalCustomizationDialog({ 
  customization, 
  onUpdate 
}: {
  customization: any;
  onUpdate: (customization: any) => void;
}) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Palette size={16} />
          Customize
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Customize Journal</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">Font Family</label>
            <Select
              value={customization.fontFamily}
              onValueChange={(value) => onUpdate({ ...customization, fontFamily: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="serif">Serif</SelectItem>
                <SelectItem value="sans">Sans Serif</SelectItem>
                <SelectItem value="mono">Monospace</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium">Font Size</label>
            <Select
              value={customization.fontSize}
              onValueChange={(value) => onUpdate({ ...customization, fontSize: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Small</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="large">Large</SelectItem>
                <SelectItem value="xlarge">Extra Large</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium">Background Color</label>
            <div className="flex items-center space-x-2">
              <Input
                type="color"
                value={customization.backgroundColor}
                onChange={(e) => onUpdate({ ...customization, backgroundColor: e.target.value })}
                className="w-16 h-8 p-1 rounded"
              />
              <div 
                className="flex-1 h-8 rounded border flex items-center justify-center text-xs"
                style={{ 
                  backgroundColor: customization.backgroundColor,
                  color: customization.textColor 
                }}
              >
                Preview
              </div>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">Text Color</label>
            <div className="flex items-center space-x-2">
              <Input
                type="color"
                value={customization.textColor}
                onChange={(e) => onUpdate({ ...customization, textColor: e.target.value })}
                className="w-16 h-8 p-1 rounded"
              />
              <div 
                className="flex-1 h-8 rounded border flex items-center justify-center text-xs"
                style={{ 
                  backgroundColor: 'rgba(255, 255, 255, 0.9)',
                  color: customization.textColor 
                }}
              >
                Text Preview
              </div>
            </div>
          </div>
          
          <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-xs text-yellow-800">
              💡 The text area will have a semi-transparent white background for better readability, 
              while your chosen background color will show around it.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}