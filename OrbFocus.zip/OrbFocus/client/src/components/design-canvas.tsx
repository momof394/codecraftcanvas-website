import { useState, useRef, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { 
  Palette, 
  Type, 
  Square, 
  Circle, 
  Image as ImageIcon, 
  Download, 
  Save, 
  Undo, 
  Redo,
  Trash2,
  Copy,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Plus,
  Brush,
  Move,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Grid,
  Layers,
  Settings,
  FileDown,
  Upload
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CanvasElement {
  id: string;
  type: 'text' | 'shape' | 'image' | 'drawing';
  content: any;
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
    rotation: number;
  };
  style: {
    fill?: string;
    stroke?: string;
    strokeWidth?: number;
    fontSize?: number;
    fontFamily?: string;
    opacity?: number;
  };
  layerOrder: number;
  isLocked: boolean;
  isVisible: boolean;
}

interface DesignCanvasProps {
  projectId?: string;
  templateData?: any;
  onSave?: (canvasData: any) => void;
  onExport?: (format: 'pdf' | 'png' | 'jpeg') => void;
}

export default function DesignCanvas({ projectId, templateData, onSave, onExport }: DesignCanvasProps) {
  const [elements, setElements] = useState<CanvasElement[]>([]);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [tool, setTool] = useState<'select' | 'text' | 'shape' | 'brush' | 'image'>('select');
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 600 });
  const [zoom, setZoom] = useState(100);
  const [showGrid, setShowGrid] = useState(true);
  const [history, setHistory] = useState<any[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawingPath, setDrawingPath] = useState('');
  
  const canvasRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Initialize canvas with template data
  useEffect(() => {
    if (templateData) {
      setElements(templateData.elements || []);
      setCanvasSize(templateData.dimensions || { width: 800, height: 600 });
    }
  }, [templateData]);

  // Save to history for undo/redo
  const saveToHistory = useCallback(() => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push({ elements: [...elements], canvasSize: { ...canvasSize } });
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [elements, canvasSize, history, historyIndex]);

  // Add text element
  const addTextElement = useCallback((x: number, y: number) => {
    const newElement: CanvasElement = {
      id: crypto.randomUUID(),
      type: 'text',
      content: { text: 'New Text' },
      position: { x, y, width: 200, height: 40, rotation: 0 },
      style: { fontSize: 16, fontFamily: 'Arial', fill: '#000000' },
      layerOrder: elements.length,
      isLocked: false,
      isVisible: true,
    };
    setElements(prev => [...prev, newElement]);
    setSelectedElement(newElement.id);
    saveToHistory();
  }, [elements.length, saveToHistory]);

  // Add shape element
  const addShapeElement = useCallback((type: 'rectangle' | 'circle', x: number, y: number) => {
    const newElement: CanvasElement = {
      id: crypto.randomUUID(),
      type: 'shape',
      content: { shapeType: type },
      position: { x, y, width: 100, height: 100, rotation: 0 },
      style: { fill: '#3b82f6', stroke: '#1e40af', strokeWidth: 2, opacity: 1 },
      layerOrder: elements.length,
      isLocked: false,
      isVisible: true,
    };
    setElements(prev => [...prev, newElement]);
    setSelectedElement(newElement.id);
    saveToHistory();
  }, [elements.length, saveToHistory]);

  // Handle canvas click
  const handleCanvasClick = useCallback((e: React.MouseEvent) => {
    if (!canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (100 / zoom);
    const y = (e.clientY - rect.top) * (100 / zoom);

    switch (tool) {
      case 'text':
        addTextElement(x, y);
        break;
      case 'shape':
        addShapeElement('rectangle', x, y);
        break;
      case 'select':
        setSelectedElement(null);
        break;
    }
  }, [tool, zoom, addTextElement, addShapeElement]);

  // Update element
  const updateElement = useCallback((id: string, updates: Partial<CanvasElement>) => {
    setElements(prev => prev.map(el => el.id === id ? { ...el, ...updates } : el));
  }, []);

  // Delete element
  const deleteElement = useCallback((id: string) => {
    setElements(prev => prev.filter(el => el.id !== id));
    setSelectedElement(null);
    saveToHistory();
  }, [saveToHistory]);

  // Export functionality
  const handleExport = useCallback(async (format: 'pdf' | 'png' | 'jpeg') => {
    try {
      // Here you would implement actual export logic
      // For now, we'll simulate it
      toast({
        title: `Exporting as ${format.toUpperCase()}`,
        description: "Your design is being exported...",
      });
      
      // Simulate export process
      setTimeout(() => {
        toast({
          title: "Export Complete",
          description: `Your design has been exported as ${format.toUpperCase()}`,
        });
        onExport?.(format);
      }, 2000);
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "There was an error exporting your design",
        variant: "destructive",
      });
    }
  }, [toast, onExport]);

  // Get selected element
  const selectedElementData = selectedElement ? elements.find(el => el.id === selectedElement) : null;

  return (
    <div className="flex h-screen bg-background">
      {/* Left Sidebar - Tools */}
      <div className="w-64 border-r bg-card p-4 space-y-4">
        <div>
          <h3 className="font-semibold mb-3">Tools</h3>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant={tool === 'select' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTool('select')}
            >
              <Move className="w-4 h-4" />
            </Button>
            <Button
              variant={tool === 'text' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTool('text')}
            >
              <Type className="w-4 h-4" />
            </Button>
            <Button
              variant={tool === 'shape' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTool('shape')}
            >
              <Square className="w-4 h-4" />
            </Button>
            <Button
              variant={tool === 'brush' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTool('brush')}
            >
              <Brush className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Quick Actions */}
        <div>
          <h3 className="font-semibold mb-3">Quick Add</h3>
          <div className="space-y-2">
            <Button
              variant="outline"
              size="sm"
              className="w-full justify-start"
              onClick={() => addTextElement(100, 100)}
            >
              <Type className="w-4 h-4 mr-2" />
              Add Text
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="w-full justify-start"
              onClick={() => addShapeElement('rectangle', 150, 150)}
            >
              <Square className="w-4 h-4 mr-2" />
              Add Rectangle
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="w-full justify-start"
              onClick={() => addShapeElement('circle', 200, 200)}
            >
              <Circle className="w-4 h-4 mr-2" />
              Add Circle
            </Button>
          </div>
        </div>

        {/* Templates */}
        <div>
          <h3 className="font-semibold mb-3">Templates</h3>
          <div className="space-y-2">
            <Button variant="outline" size="sm" className="w-full justify-start">
              <FileDown className="w-4 h-4 mr-2" />
              Journal Page
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <FileDown className="w-4 h-4 mr-2" />
              Planner Layout
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <FileDown className="w-4 h-4 mr-2" />
              Cover Design
            </Button>
          </div>
        </div>

        {/* Assets */}
        <div>
          <h3 className="font-semibold mb-3">Assets</h3>
          <div className="space-y-2">
            <Button variant="outline" size="sm" className="w-full justify-start">
              <ImageIcon className="w-4 h-4 mr-2" />
              Images
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <Palette className="w-4 h-4 mr-2" />
              Shapes
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <Upload className="w-4 h-4 mr-2" />
              Upload
            </Button>
          </div>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="flex-1 flex flex-col">
        {/* Top Toolbar */}
        <div className="border-b bg-card p-2 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Undo className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm">
              <Redo className="w-4 h-4" />
            </Button>
            <div className="w-px h-6 bg-border" />
            <Button variant="outline" size="sm" onClick={() => setShowGrid(!showGrid)}>
              <Grid className="w-4 h-4" />
            </Button>
            <div className="flex items-center space-x-1">
              <Button variant="outline" size="sm" onClick={() => setZoom(Math.max(25, zoom - 25))}>
                <ZoomOut className="w-4 h-4" />
              </Button>
              <span className="text-sm font-mono w-12 text-center">{zoom}%</span>
              <Button variant="outline" size="sm" onClick={() => setZoom(Math.min(200, zoom + 25))}>
                <ZoomIn className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => onSave?.({ elements, canvasSize })}>
              <Save className="w-4 h-4 mr-1" />
              Save
            </Button>
            <Dialog>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Download className="w-4 h-4 mr-1" />
                  Export
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Export Design</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Format</label>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <Button variant="outline" onClick={() => handleExport('pdf')}>
                        PDF
                      </Button>
                      <Button variant="outline" onClick={() => handleExport('png')}>
                        PNG
                      </Button>
                      <Button variant="outline" onClick={() => handleExport('jpeg')}>
                        JPEG
                      </Button>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Quality</label>
                    <Select defaultValue="high">
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Canvas Container */}
        <div className="flex-1 overflow-auto bg-gray-100 dark:bg-gray-900 p-8">
          <div className="flex justify-center">
            <div
              ref={canvasRef}
              className="relative bg-white dark:bg-gray-800 shadow-lg"
              style={{
                width: `${canvasSize.width * (zoom / 100)}px`,
                height: `${canvasSize.height * (zoom / 100)}px`,
                transform: `scale(${zoom / 100})`,
                transformOrigin: 'top left',
              }}
              onClick={handleCanvasClick}
            >
              {/* Grid */}
              {showGrid && (
                <div
                  className="absolute inset-0 opacity-20"
                  style={{
                    backgroundImage: `
                      linear-gradient(to right, #ccc 1px, transparent 1px),
                      linear-gradient(to bottom, #ccc 1px, transparent 1px)
                    `,
                    backgroundSize: '20px 20px',
                  }}
                />
              )}

              {/* Canvas Elements */}
              {elements
                .filter(el => el.isVisible)
                .sort((a, b) => a.layerOrder - b.layerOrder)
                .map((element) => (
                  <div
                    key={element.id}
                    className={`absolute cursor-pointer border-2 ${
                      selectedElement === element.id ? 'border-blue-500' : 'border-transparent'
                    }`}
                    style={{
                      left: element.position.x,
                      top: element.position.y,
                      width: element.position.width,
                      height: element.position.height,
                      transform: `rotate(${element.position.rotation}deg)`,
                      opacity: element.style.opacity || 1,
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedElement(element.id);
                    }}
                  >
                    {element.type === 'text' && (
                      <div
                        style={{
                          fontSize: element.style.fontSize,
                          fontFamily: element.style.fontFamily,
                          color: element.style.fill,
                          width: '100%',
                          height: '100%',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        {element.content.text}
                      </div>
                    )}
                    {element.type === 'shape' && element.content.shapeType === 'rectangle' && (
                      <div
                        style={{
                          width: '100%',
                          height: '100%',
                          backgroundColor: element.style.fill,
                          border: `${element.style.strokeWidth}px solid ${element.style.stroke}`,
                        }}
                      />
                    )}
                    {element.type === 'shape' && element.content.shapeType === 'circle' && (
                      <div
                        style={{
                          width: '100%',
                          height: '100%',
                          backgroundColor: element.style.fill,
                          border: `${element.style.strokeWidth}px solid ${element.style.stroke}`,
                          borderRadius: '50%',
                        }}
                      />
                    )}
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>

      {/* Right Sidebar - Properties */}
      <div className="w-64 border-l bg-card p-4 space-y-4">
        <div>
          <h3 className="font-semibold mb-3">Layers</h3>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {elements
              .sort((a, b) => b.layerOrder - a.layerOrder)
              .map((element) => (
                <div
                  key={element.id}
                  className={`flex items-center space-x-2 p-2 rounded text-sm cursor-pointer ${
                    selectedElement === element.id ? 'bg-blue-100 dark:bg-blue-900' : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                  }`}
                  onClick={() => setSelectedElement(element.id)}
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-6 h-6 p-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateElement(element.id, { isVisible: !element.isVisible });
                    }}
                  >
                    {element.isVisible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  </Button>
                  <span className="flex-1 truncate">
                    {element.type === 'text' ? element.content.text : `${element.type} ${element.id.slice(-4)}`}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-6 h-6 p-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateElement(element.id, { isLocked: !element.isLocked });
                    }}
                  >
                    {element.isLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                  </Button>
                </div>
              ))}
          </div>
        </div>

        {/* Element Properties */}
        {selectedElementData && (
          <div>
            <h3 className="font-semibold mb-3">Properties</h3>
            <div className="space-y-3">
              {selectedElementData.type === 'text' && (
                <>
                  <div>
                    <label className="text-sm font-medium">Text</label>
                    <Textarea
                      value={selectedElementData.content.text}
                      onChange={(e) =>
                        updateElement(selectedElementData.id, {
                          content: { ...selectedElementData.content, text: e.target.value }
                        })
                      }
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Font Size</label>
                    <Input
                      type="number"
                      value={selectedElementData.style.fontSize}
                      onChange={(e) =>
                        updateElement(selectedElementData.id, {
                          style: { ...selectedElementData.style, fontSize: parseInt(e.target.value) }
                        })
                      }
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Color</label>
                    <Input
                      type="color"
                      value={selectedElementData.style.fill}
                      onChange={(e) =>
                        updateElement(selectedElementData.id, {
                          style: { ...selectedElementData.style, fill: e.target.value }
                        })
                      }
                      className="mt-1"
                    />
                  </div>
                </>
              )}
              {selectedElementData.type === 'shape' && (
                <>
                  <div>
                    <label className="text-sm font-medium">Fill Color</label>
                    <Input
                      type="color"
                      value={selectedElementData.style.fill}
                      onChange={(e) =>
                        updateElement(selectedElementData.id, {
                          style: { ...selectedElementData.style, fill: e.target.value }
                        })
                      }
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Border Color</label>
                    <Input
                      type="color"
                      value={selectedElementData.style.stroke}
                      onChange={(e) =>
                        updateElement(selectedElementData.id, {
                          style: { ...selectedElementData.style, stroke: e.target.value }
                        })
                      }
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Border Width</label>
                    <Input
                      type="number"
                      value={selectedElementData.style.strokeWidth}
                      onChange={(e) =>
                        updateElement(selectedElementData.id, {
                          style: { ...selectedElementData.style, strokeWidth: parseInt(e.target.value) }
                        })
                      }
                      className="mt-1"
                    />
                  </div>
                </>
              )}
              <div>
                <label className="text-sm font-medium">Opacity</label>
                <Slider
                  value={[(selectedElementData.style.opacity || 1) * 100]}
                  onValueChange={([value]) =>
                    updateElement(selectedElementData.id, {
                      style: { ...selectedElementData.style, opacity: value / 100 }
                    })
                  }
                  max={100}
                  step={1}
                  className="mt-2"
                />
              </div>
              <Button
                variant="destructive"
                size="sm"
                className="w-full"
                onClick={() => deleteElement(selectedElementData.id)}
              >
                <Trash2 className="w-4 h-4 mr-1" />
                Delete
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}