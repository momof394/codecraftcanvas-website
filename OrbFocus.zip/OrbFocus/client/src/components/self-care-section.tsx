import { useState } from "react";
import { motion } from "framer-motion";
import { Activity, Anchor, Droplet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function SelfCareSection() {
  const [activeActivity, setActiveActivity] = useState<string | null>(null);
  const [waterCount, setWaterCount] = useState(0);
  const { toast } = useToast();

  const activities = [
    {
      id: "stretching",
      title: "Gentle Stretches",
      description: "5-minute desk stretches to ease tension",
      icon: Activity,
      color: "hsl(142, 28%, 59%)",
      bgColor: "hsl(142, 28%, 59%)/20"
    },
    {
      id: "grounding",
      title: "Grounding Exercise", 
      description: "5-4-3-2-1 sensory grounding technique",
      icon: Anchor,
      color: "hsl(198, 71%, 73%)",
      bgColor: "hsl(198, 71%, 73%)/20"
    },
    {
      id: "hydration",
      title: "Hydration Check",
      description: "Gentle reminder to drink water",
      icon: Droplet,
      color: "hsl(162, 40%, 72%)",
      bgColor: "hsl(162, 40%, 72%)/20"
    }
  ];

  const startActivity = (activityId: string) => {
    setActiveActivity(activityId);
    const activity = activities.find(a => a.id === activityId);
    
    if (activityId === "stretching") {
      toast({
        title: "Gentle Stretching Started! 🧘‍♀️",
        description: "Take your time, listen to your body, and be gentle with yourself.",
      });
    } else if (activityId === "grounding") {
      toast({
        title: "Grounding Exercise Started 🌱",
        description: "5 things you see, 4 you hear, 3 you touch, 2 you smell, 1 you taste.",
      });
    }

    // Auto-stop after some time
    setTimeout(() => {
      setActiveActivity(null);
      if (activityId !== "hydration") {
        toast({
          description: `Great job completing your ${activity?.title.toLowerCase()}! 💚`,
        });
      }
    }, 5000);
  };

  const handleWaterDrank = () => {
    const newCount = waterCount + 1;
    setWaterCount(newCount);
    toast({
      description: `Water logged! You've had ${newCount} glass${newCount > 1 ? 'es' : ''} today! 💧`,
    });
  };

  return (
    <section className="mb-16">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-medium text-[hsl(0,0%,36%)] mb-4" style={{ fontFamily: 'Poppins' }}>
          Self-Care Toolkit
        </h2>
        <p className="text-[hsl(0,0%,36%)]/70 max-w-2xl mx-auto">
          Gentle reminders and activities to nurture your well-being
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activities.map((activity) => {
          const IconComponent = activity.icon;
          const isActive = activeActivity === activity.id;
          
          return (
            <motion.div
              key={activity.id}
              className="bg-white rounded-2xl p-6 shadow-lg border border-[hsl(142,28%,59%)]/10 hover:shadow-xl transition-shadow duration-300"
              whileHover={{ y: -5 }}
              animate={{ scale: isActive ? 1.05 : 1 }}
            >
              <motion.div 
                className="w-12 h-12 rounded-full flex items-center justify-center mb-4"
                style={{ backgroundColor: activity.bgColor }}
                animate={{ rotate: isActive ? 360 : 0 }}
                transition={{ duration: 2, repeat: isActive ? Infinity : 0 }}
              >
                <IconComponent 
                  className="text-current" 
                  size={20}
                  style={{ color: activity.color }}
                />
              </motion.div>
              
              <h3 className="text-lg font-medium text-[hsl(0,0%,36%)] mb-3">
                {activity.title}
              </h3>
              <p className="text-[hsl(0,0%,36%)]/70 text-sm mb-4">
                {activity.description}
              </p>
              
              {activity.id === "hydration" ? (
                <div className="space-y-2">
                  <Button
                    onClick={handleWaterDrank}
                    className="w-full py-2 text-sm rounded-xl transition-colors duration-300"
                    style={{ 
                      backgroundColor: `${activity.color}/10`, 
                      color: activity.color,
                      border: `1px solid ${activity.color}/20`
                    }}
                    variant="ghost"
                  >
                    I drank water! 💧
                  </Button>
                  {waterCount > 0 && (
                    <p className="text-xs text-center" style={{ color: activity.color }}>
                      {waterCount} glass{waterCount > 1 ? 'es' : ''} today!
                    </p>
                  )}
                </div>
              ) : (
                <Button
                  onClick={() => startActivity(activity.id)}
                  disabled={isActive}
                  className="w-full py-2 text-sm rounded-xl transition-colors duration-300"
                  style={{ 
                    backgroundColor: `${activity.color}/10`, 
                    color: activity.color,
                    border: `1px solid ${activity.color}/20`
                  }}
                  variant="ghost"
                >
                  {isActive ? "In Progress..." : `Start ${activity.title.split(' ')[0]}`}
                </Button>
              )}
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}