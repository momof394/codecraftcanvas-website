import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Bot, 
  Send, 
  Mic, 
  MicOff,
  Volume2,
  VolumeX,
  User,
  Brain,
  Heart,
  Lightbulb,
  Smile,
  Coffee,
  Star,
  Zap,
  MessageCircle,
  Loader2,
  RefreshCw
} from "lucide-react";

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  emotion?: string;
  context?: string;
  responseType?: 'supportive' | 'analytical' | 'creative' | 'motivational';
}

interface EmotionalContext {
  currentMood: number;
  recentEmotions: string[];
  userPersonality: string[];
  communicationStyle: 'formal' | 'casual' | 'empathetic' | 'technical';
}

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm your personal AI companion here to support your creative journey and well-being. I notice this is our first conversation - I'm genuinely excited to get to know you better. What's on your mind today? Whether you're feeling creative, need someone to brainstorm with, or just want to chat about life, I'm here with my full attention.",
      timestamp: new Date(),
      responseType: 'supportive'
    }
  ]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [emotionalContext, setEmotionalContext] = useState<EmotionalContext>({
    currentMood: 3,
    recentEmotions: [],
    userPersonality: ['creative', 'thoughtful'],
    communicationStyle: 'empathetic'
  });
  const [conversationMode, setConversationMode] = useState<'casual' | 'professional' | 'therapeutic'>('casual');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      if (recognitionRef.current) {
        recognitionRef.current.continuous = false;
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = 'en-US';
        
        recognitionRef.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setCurrentMessage(transcript);
          setIsListening(false);
        };
        
        recognitionRef.current.onerror = () => {
          setIsListening(false);
        };
        
        recognitionRef.current.onend = () => {
          setIsListening(false);
        };
      }
    }
  }, []);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Enhanced AI response generation
  const generateHumanLikeResponse = (userMessage: string, context: EmotionalContext): string => {
    const responses = {
      supportive: [
        "I can really hear the passion in what you're sharing with me. It sounds like this means a lot to you, and honestly, that kind of dedication is something I find genuinely inspiring.",
        "You know, the way you're approaching this reminds me of how thoughtful people tend to tackle challenges - step by step, with real consideration for the details that matter.",
        "I'm picking up on some complexity in what you're dealing with, and I want you to know that feeling overwhelmed sometimes is completely human. Let's break this down together."
      ],
      analytical: [
        "This is fascinating - I'm seeing several layers to what you're describing. The way you've connected these ideas shows some really sophisticated thinking.",
        "Let me reflect back what I'm hearing and add some perspective. There are a few patterns here that might be worth exploring further.",
        "Your approach to this problem actually aligns with some interesting principles I've observed in how creative minds work. There's definitely method to what might feel like madness."
      ],
      creative: [
        "Oh, this is sparking some interesting connections for me! What if we looked at this from a completely different angle - have you considered approaching it like...",
        "You're onto something here, and I can feel my own creative circuits lighting up. This reminds me of those moments when ideas start cascading and building on each other.",
        "I love how your mind works - you're naturally making connections that aren't obvious. That's the kind of thinking that leads to breakthrough moments."
      ],
      motivational: [
        "Listen, what you're describing takes real courage, and I want to acknowledge that. Not everyone pushes themselves to grow like this.",
        "I'm genuinely excited about where this could lead for you. You've got the insight and the drive - that's a powerful combination.",
        "Sometimes the most meaningful progress happens in these quiet moments of reflection and planning. You're doing important work here."
      ]
    };

    // Analyze user message for emotional context
    const userLower = userMessage.toLowerCase();
    let responseType: keyof typeof responses = 'supportive';
    
    if (userLower.includes('problem') || userLower.includes('challenge') || userLower.includes('difficult')) {
      responseType = 'analytical';
    } else if (userLower.includes('idea') || userLower.includes('create') || userLower.includes('design')) {
      responseType = 'creative';
    } else if (userLower.includes('goal') || userLower.includes('want to') || userLower.includes('trying to')) {
      responseType = 'motivational';
    }

    // Select response based on context
    const responsePool = responses[responseType];
    const baseResponse = responsePool[Math.floor(Math.random() * responsePool.length)];

    // Add contextual elements
    const contextualAdditions = [
      "What's your intuition telling you about this?",
      "I'm curious - how does this connect to what you're working toward overall?",
      "What would it look like if this went exactly as you hoped?",
      "How are you feeling about this right now, honestly?",
      "What's the next small step that feels manageable to you?"
    ];

    const addition = contextualAdditions[Math.floor(Math.random() * contextualAdditions.length)];
    
    return `${baseResponse} ${addition}`;
  };

  const sendMessage = async () => {
    if (!currentMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: currentMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setCurrentMessage('');
    setIsThinking(true);

    // Simulate AI thinking time for more human-like interaction
    await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 2000));

    const aiResponse: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: generateHumanLikeResponse(currentMessage, emotionalContext),
      timestamp: new Date(),
      responseType: 'supportive'
    };

    setMessages(prev => [...prev, aiResponse]);
    setIsThinking(false);
  };

  const startListening = () => {
    if (recognitionRef.current) {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const getMessageIcon = (role: string, responseType?: string) => {
    if (role === 'user') return <User className="w-6 h-6" />;
    
    const icons = {
      supportive: <Heart className="w-6 h-6 text-pink-500" />,
      analytical: <Brain className="w-6 h-6 text-blue-500" />,
      creative: <Lightbulb className="w-6 h-6 text-yellow-500" />,
      motivational: <Zap className="w-6 h-6 text-green-500" />
    };
    
    return icons[responseType as keyof typeof icons] || <Bot className="w-6 h-6 text-purple-500" />;
  };

  return (
    <Card className="w-full max-w-4xl mx-auto h-[600px] flex flex-col">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <Bot className="w-6 h-6 text-purple-600" />
              <span>AI Companion</span>
            </CardTitle>
            <CardDescription>
              Your thoughtful digital companion for creative support and meaningful conversations
            </CardDescription>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" className="flex items-center space-x-1">
              <Heart className="w-3 h-3" />
              <span>Empathetic Mode</span>
            </Badge>
            <Badge variant="outline" className="flex items-center space-x-1">
              <Smile className="w-3 h-3" />
              <span>Mood: {emotionalContext.currentMood}/5</span>
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Messages Area */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex space-x-3 ${
                  message.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                }`}
              >
                <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                  message.role === 'user' 
                    ? 'bg-purple-100 text-purple-600' 
                    : 'bg-gray-100 text-gray-600'
                }`}>
                  {getMessageIcon(message.role, message.responseType)}
                </div>
                
                <div className={`flex-1 max-w-xs md:max-w-md lg:max-w-lg xl:max-w-xl ${
                  message.role === 'user' ? 'text-right' : ''
                }`}>
                  <div className={`p-3 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}>
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  </div>
                  <p className={`text-xs text-muted-foreground mt-1 ${
                    message.role === 'user' ? 'text-right' : ''
                  }`}>
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            
            {isThinking && (
              <div className="flex space-x-3">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 text-gray-600 flex items-center justify-center">
                  <Loader2 className="w-4 h-4 animate-spin" />
                </div>
                <div className="flex-1 max-w-xs md:max-w-md lg:max-w-lg xl:max-w-xl">
                  <div className="p-3 rounded-lg bg-gray-100 text-gray-900">
                    <p className="text-sm italic">I'm thinking about this carefully...</p>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="border-t p-4">
          <div className="flex space-x-2">
            <div className="flex-1 relative">
              <Textarea
                placeholder="Share what's on your mind... I'm here to listen and support you."
                value={currentMessage}
                onChange={(e) => setCurrentMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                className="min-h-[60px] pr-12"
                disabled={isThinking}
              />
            </div>
            
            <div className="flex flex-col space-y-2">
              <Button
                onClick={isListening ? stopListening : startListening}
                variant="outline"
                size="sm"
                disabled={isThinking}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
              
              <Button
                onClick={sendMessage}
                disabled={!currentMessage.trim() || isThinking}
                size="sm"
              >
                {isThinking ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
          
          {isListening && (
            <div className="mt-2 flex items-center space-x-2 text-sm text-blue-600">
              <Volume2 className="w-4 h-4 animate-pulse" />
              <span>Listening... speak naturally</span>
            </div>
          )}
          
          <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center space-x-4">
              <span>AI Personality: Thoughtful & Supportive</span>
              <span>•</span>
              <span>Response Style: Human-like & Descriptive</span>
            </div>
            <Button variant="ghost" size="sm" className="h-6 px-2">
              <RefreshCw className="w-3 h-3 mr-1" />
              New conversation
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}