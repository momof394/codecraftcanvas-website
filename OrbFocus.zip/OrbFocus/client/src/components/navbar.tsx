import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Palette, 
  Home, 
  FileImage, 
  Download, 
  CreditCard, 
  Moon, 
  Sun,
  Menu,
  X,
  Sparkles,
  Brain,
  Users,
  Circle,
  Timer,
  Mic,
  MessageCircle,
  Layers,
  Settings
} from "lucide-react";
import { useTheme } from "next-themes";

export default function Navbar() {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const designItems = [
    { href: "/editor", label: "Design Studio", icon: Palette, description: "Create & Edit" },
    { href: "/templates", label: "Templates", icon: FileImage, description: "Pre-made Designs" },
    { href: "/assets", label: "Assets", icon: Sparkles, description: "Images & Icons" },
    { href: "/exports", label: "Exports", icon: Download, description: "Your Downloads" },
  ];

  const productivityItems = [
    { href: "/journal", label: "Projects", icon: MessageCircle, description: "Project Hub" },
    { href: "/orb-canvas", label: "Orb Hub", icon: Circle, description: "Visual Canvas" },
  ];

  const otherItems = [
    { href: "/about", label: "About", icon: Users, description: "Our Story" },
    { href: "/blog", label: "Blog", icon: FileImage, description: "Articles & Insights" },
    { href: "/resources", label: "Resources", icon: Download, description: "Tools & Guides" },
    { href: "/pricing", label: "Pricing", icon: CreditCard, description: "Plans & Features" },
  ];

  const isActive = (href: string) => location === href;

  return (
    <nav className="bg-card/80 backdrop-blur-md border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <a className="flex items-center space-x-3 text-xl font-bold text-purple-600">
                <div className="relative">
                  <Circle className="w-8 h-8 text-purple-600" />
                  <Palette className="w-4 h-4 absolute top-1 left-1 text-purple-400" />
                </div>
                <div>
                  <span className="block">ProductivityStudio</span>
                  <span className="text-xs font-normal text-muted-foreground">Design • Productivity • Create</span>
                </div>
              </a>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6">
            {/* Design Section */}
            <div className="flex items-center space-x-4">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Design</span>
              {designItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.href} href={item.href}>
                    <a className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors group ${
                      isActive(item.href)
                        ? "bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300"
                        : "text-gray-700 hover:text-purple-600 dark:text-gray-300 dark:hover:text-purple-400"
                    }`}>
                      <Icon className="w-4 h-4" />
                      <span className="hidden xl:block">{item.label}</span>
                    </a>
                  </Link>
                );
              })}
            </div>
            
            <div className="w-px h-6 bg-border"></div>
            
            {/* Productivity Section */}
            <div className="flex items-center space-x-4">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Productivity</span>
              {productivityItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.href} href={item.href}>
                    <a className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive(item.href)
                        ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300"
                        : "text-gray-700 hover:text-green-600 dark:text-gray-300 dark:hover:text-green-400"
                    }`}>
                      <Icon className="w-4 h-4" />
                      <span className="hidden xl:block">{item.label}</span>
                    </a>
                  </Link>
                );
              })}
            </div>
            
            <div className="w-px h-6 bg-border"></div>
            
            {/* Other Items */}
            {otherItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href}>
                  <a className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive(item.href)
                      ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300"
                      : "text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
                  }`}>
                    <Icon className="w-4 h-4" />
                    <span className="hidden xl:block">{item.label}</span>
                  </a>
                </Link>
              );
            })}
          </div>

          {/* Right side buttons */}
          <div className="flex items-center space-x-4">
            {/* Theme toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="w-9 h-9 p-0"
            >
              <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            </Button>

            {/* Create New Button */}
            <Button asChild className="hidden md:inline-flex">
              <Link href="/editor">
                <a>Create New</a>
              </Link>
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
              {/* Design Section */}
              <div className="mb-4">
                <h3 className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">Design Tools</h3>
                {designItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href}>
                      <a 
                        className={`flex items-center space-x-3 px-3 py-2 rounded-md text-base font-medium ${
                          isActive(item.href)
                            ? "bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300"
                            : "text-gray-700 hover:text-purple-600 dark:text-gray-300 dark:hover:text-purple-400"
                        }`}
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <Icon className="w-5 h-5" />
                        <div>
                          <span className="block">{item.label}</span>
                          <span className="text-xs text-muted-foreground">{item.description}</span>
                        </div>
                      </a>
                    </Link>
                  );
                })}
              </div>

              {/* Productivity Section */}
              <div className="mb-4">
                <h3 className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">Productivity</h3>
                {productivityItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href}>
                      <a 
                        className={`flex items-center space-x-3 px-3 py-2 rounded-md text-base font-medium ${
                          isActive(item.href)
                            ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300"
                            : "text-gray-700 hover:text-green-600 dark:text-gray-300 dark:hover:text-green-400"
                        }`}
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <Icon className="w-5 h-5" />
                        <div>
                          <span className="block">{item.label}</span>
                          <span className="text-xs text-muted-foreground">{item.description}</span>
                        </div>
                      </a>
                    </Link>
                  );
                })}
              </div>

              {/* Other Items */}
              <div className="mb-4">
                {otherItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href}>
                      <a 
                        className={`flex items-center space-x-3 px-3 py-2 rounded-md text-base font-medium ${
                          isActive(item.href)
                            ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300"
                            : "text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
                        }`}
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <Icon className="w-5 h-5" />
                        <div>
                          <span className="block">{item.label}</span>
                          <span className="text-xs text-muted-foreground">{item.description}</span>
                        </div>
                      </a>
                    </Link>
                  );
                })}
              </div>

              <Button asChild className="w-full mt-4">
                <Link href="/editor">
                  <a onClick={() => setIsMenuOpen(false)}>Create New</a>
                </Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}