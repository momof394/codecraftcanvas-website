import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Smile, 
  Frown, 
  Meh, 
  Heart, 
  Brain, 
  Zap,
  Cloud,
  Sun,
  CloudRain,
  Sparkles,
  TrendingUp,
  Calendar,
  Eye,
  Target
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface MoodEntry {
  id: string;
  mood: number; // 1-10 scale
  emotions: string[];
  energy: number; // 1-10 scale
  stress: number; // 1-10 scale
  notes?: string;
  timestamp: Date;
  aiInsights?: {
    patterns: string[];
    suggestions: string[];
    triggers: string[];
  };
}

interface MoodPattern {
  timeOfDay: string;
  averageMood: number;
  commonEmotions: string[];
  frequency: number;
}

const MOOD_EMOJIS = {
  1: { emoji: "😢", label: "Very Sad", color: "from-blue-600 to-blue-800" },
  2: { emoji: "😟", label: "Sad", color: "from-blue-500 to-blue-700" },
  3: { emoji: "😐", label: "Low", color: "from-gray-500 to-gray-700" },
  4: { emoji: "🙂", label: "Okay", color: "from-yellow-500 to-yellow-600" },
  5: { emoji: "😊", label: "Good", color: "from-green-400 to-green-600" },
  6: { emoji: "😄", label: "Happy", color: "from-green-500 to-green-700" },
  7: { emoji: "😁", label: "Very Happy", color: "from-emerald-500 to-emerald-700" },
  8: { emoji: "🤩", label: "Excited", color: "from-purple-500 to-purple-700" },
  9: { emoji: "🥳", label: "Joyful", color: "from-pink-500 to-pink-700" },
  10: { emoji: "✨", label: "Euphoric", color: "from-yellow-400 to-orange-500" }
};

const EMOTION_OPTIONS = [
  { name: "Happy", color: "bg-yellow-100 text-yellow-800", icon: "😊" },
  { name: "Excited", color: "bg-orange-100 text-orange-800", icon: "🤩" },
  { name: "Calm", color: "bg-blue-100 text-blue-800", icon: "😌" },
  { name: "Anxious", color: "bg-red-100 text-red-800", icon: "😰" },
  { name: "Sad", color: "bg-blue-200 text-blue-900", icon: "😢" },
  { name: "Angry", color: "bg-red-200 text-red-900", icon: "😠" },
  { name: "Grateful", color: "bg-green-100 text-green-800", icon: "🙏" },
  { name: "Overwhelmed", color: "bg-purple-100 text-purple-800", icon: "😵‍💫" },
  { name: "Focused", color: "bg-indigo-100 text-indigo-800", icon: "🎯" },
  { name: "Creative", color: "bg-pink-100 text-pink-800", icon: "🎨" },
  { name: "Tired", color: "bg-gray-100 text-gray-800", icon: "😴" },
  { name: "Energetic", color: "bg-lime-100 text-lime-800", icon: "⚡" }
];

export default function MoodDetection({ isCompact = false }: { isCompact?: boolean }) {
  const [currentMood, setCurrentMood] = useState<number>(5);
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>([]);
  const [energy, setEnergy] = useState<number>(5);
  const [stress, setStress] = useState<number>(5);
  const [notes, setNotes] = useState("");
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);
  const [showQuickCheck, setShowQuickCheck] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadMoodHistory();
    // Show quick check-in every 2 hours
    const interval = setInterval(() => {
      setShowQuickCheck(true);
    }, 2 * 60 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  const loadMoodHistory = () => {
    const saved = localStorage.getItem('mood_history');
    if (saved) {
      const parsed = JSON.parse(saved).map((entry: any) => ({
        ...entry,
        timestamp: new Date(entry.timestamp)
      }));
      setMoodHistory(parsed);
    }
  };

  const saveMoodEntry = async () => {
    if (selectedEmotions.length === 0) {
      toast({ description: "Please select at least one emotion" });
      return;
    }

    setIsSubmitting(true);
    
    const newEntry: MoodEntry = {
      id: crypto.randomUUID(),
      mood: currentMood,
      emotions: selectedEmotions,
      energy,
      stress,
      notes,
      timestamp: new Date(),
      aiInsights: generateAIInsights(currentMood, selectedEmotions, energy, stress)
    };

    const updatedHistory = [newEntry, ...moodHistory].slice(0, 100); // Keep last 100 entries
    setMoodHistory(updatedHistory);
    localStorage.setItem('mood_history', JSON.stringify(updatedHistory));

    // Reset form
    setSelectedEmotions([]);
    setNotes("");
    setShowQuickCheck(false);
    setIsSubmitting(false);

    toast({ 
      title: "Mood logged!", 
      description: newEntry.aiInsights?.suggestions[0] || "Thanks for checking in with yourself."
    });
  };

  const generateAIInsights = (mood: number, emotions: string[], energy: number, stress: number) => {
    // Simple AI insights based on patterns
    const suggestions = [];
    const patterns = [];
    const triggers = [];

    if (mood <= 3) {
      suggestions.push("Consider taking a short walk or doing breathing exercises");
      if (stress > 7) triggers.push("High stress levels detected");
    }
    
    if (energy <= 3) {
      suggestions.push("Maybe try a quick 5-minute energizing break");
      patterns.push("Low energy period");
    }
    
    if (emotions.includes("Anxious")) {
      suggestions.push("Try the 5-4-3-2-1 grounding technique");
      triggers.push("Anxiety detected");
    }
    
    if (emotions.includes("Grateful")) {
      patterns.push("Positive emotional state");
    }

    if (mood >= 7) {
      suggestions.push("Great energy! Consider tackling that important task");
      patterns.push("High mood period - good for productivity");
    }

    return { suggestions, patterns, triggers };
  };

  const getRecentMoodTrend = (): string => {
    if (moodHistory.length < 3) return "neutral";
    
    const recent = moodHistory.slice(0, 3);
    const avgRecent = recent.reduce((sum, entry) => sum + entry.mood, 0) / recent.length;
    
    if (avgRecent >= 7) return "positive";
    if (avgRecent <= 4) return "concerning";
    return "stable";
  };

  const toggleEmotion = (emotion: string) => {
    setSelectedEmotions(prev => 
      prev.includes(emotion) 
        ? prev.filter(e => e !== emotion)
        : [...prev, emotion]
    );
  };

  if (isCompact) {
    return (
      <Card className="w-full max-w-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="text-2xl">{MOOD_EMOJIS[currentMood as keyof typeof MOOD_EMOJIS].emoji}</div>
              <div>
                <div className="font-medium text-sm">Current Mood</div>
                <div className="text-xs text-gray-600">{MOOD_EMOJIS[currentMood as keyof typeof MOOD_EMOJIS].label}</div>
              </div>
            </div>
            <Button
              onClick={() => setShowQuickCheck(true)}
              size="sm"
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              <Heart size={14} className="mr-1" />
              Check-in
            </Button>
          </div>
          
          {moodHistory.length > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-gray-600">
                <span>Trend</span>
                <Badge 
                  variant="outline" 
                  className={`text-xs ${
                    getRecentMoodTrend() === 'positive' ? 'border-green-500 text-green-700' :
                    getRecentMoodTrend() === 'concerning' ? 'border-red-500 text-red-700' :
                    'border-blue-500 text-blue-700'
                  }`}
                >
                  {getRecentMoodTrend() === 'positive' ? '📈 Improving' :
                   getRecentMoodTrend() === 'concerning' ? '📉 Needs attention' :
                   '➡️ Stable'}
                </Badge>
              </div>
              <div className="flex gap-1">
                {moodHistory.slice(0, 7).map((entry, index) => (
                  <div
                    key={entry.id}
                    className="flex-1 h-2 rounded-full bg-gradient-to-r"
                    style={{
                      background: `linear-gradient(to right, ${MOOD_EMOJIS[entry.mood as keyof typeof MOOD_EMOJIS].color.replace('from-', '').replace('to-', ', ')})`
                    }}
                    title={`${entry.mood}/10 - ${entry.timestamp.toLocaleDateString()}`}
                  />
                ))}
              </div>
            </div>
          )}
        </CardContent>

        {/* Quick Check-in Modal */}
        <AnimatePresence>
          {showQuickCheck && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
              onClick={() => setShowQuickCheck(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-xl p-6 w-full max-w-md shadow-2xl"
              >
                <MoodCheckInForm
                  currentMood={currentMood}
                  setCurrentMood={setCurrentMood}
                  selectedEmotions={selectedEmotions}
                  toggleEmotion={toggleEmotion}
                  energy={energy}
                  setEnergy={setEnergy}
                  stress={stress}
                  setStress={setStress}
                  notes={notes}
                  setNotes={setNotes}
                  onSave={saveMoodEntry}
                  onCancel={() => setShowQuickCheck(false)}
                  isSubmitting={isSubmitting}
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="shadow-xl border-0 bg-gradient-to-br from-purple-50 to-pink-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="text-purple-600" />
            Mood Detection & Tracking
            <Sparkles className="text-pink-500" />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <MoodCheckInForm
            currentMood={currentMood}
            setCurrentMood={setCurrentMood}
            selectedEmotions={selectedEmotions}
            toggleEmotion={toggleEmotion}
            energy={energy}
            setEnergy={setEnergy}
            stress={stress}
            setStress={setStress}
            notes={notes}
            setNotes={setNotes}
            onSave={saveMoodEntry}
            isSubmitting={isSubmitting}
          />
        </CardContent>
      </Card>

      {/* Mood History & Insights */}
      {moodHistory.length > 0 && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="text-blue-600" />
              Your Mood Journey
            </CardTitle>
          </CardHeader>
          <CardContent>
            <MoodHistoryView moodHistory={moodHistory.slice(0, 10)} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function MoodCheckInForm({
  currentMood,
  setCurrentMood,
  selectedEmotions,
  toggleEmotion,
  energy,
  setEnergy,
  stress,
  setStress,
  notes,
  setNotes,
  onSave,
  onCancel,
  isSubmitting
}: {
  currentMood: number;
  setCurrentMood: (mood: number) => void;
  selectedEmotions: string[];
  toggleEmotion: (emotion: string) => void;
  energy: number;
  setEnergy: (energy: number) => void;
  stress: number;
  setStress: (stress: number) => void;
  notes: string;
  setNotes: (notes: string) => void;
  onSave: () => void;
  onCancel?: () => void;
  isSubmitting?: boolean;
}) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">How are you feeling right now?</h3>
        <div className="text-6xl mb-2">
          {MOOD_EMOJIS[currentMood as keyof typeof MOOD_EMOJIS].emoji}
        </div>
        <p className="text-gray-600">{MOOD_EMOJIS[currentMood as keyof typeof MOOD_EMOJIS].label}</p>
      </div>

      {/* Mood Scale */}
      <div>
        <label className="text-sm font-medium mb-3 block">Overall Mood (1-10)</label>
        <div className="grid grid-cols-10 gap-1">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((mood) => (
            <motion.button
              key={mood}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentMood(mood)}
              className={`aspect-square rounded-lg text-lg transition-all ${
                currentMood === mood
                  ? `bg-gradient-to-br ${MOOD_EMOJIS[mood as keyof typeof MOOD_EMOJIS].color} text-white shadow-lg`
                  : 'bg-gray-100 hover:bg-gray-200'
              }`}
            >
              {MOOD_EMOJIS[mood as keyof typeof MOOD_EMOJIS].emoji}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Emotions */}
      <div>
        <label className="text-sm font-medium mb-3 block">What emotions are you experiencing?</label>
        <div className="grid grid-cols-3 gap-2">
          {EMOTION_OPTIONS.map((emotion) => (
            <motion.button
              key={emotion.name}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => toggleEmotion(emotion.name)}
              className={`p-2 rounded-lg text-xs font-medium transition-all ${
                selectedEmotions.includes(emotion.name)
                  ? emotion.color + ' ring-2 ring-offset-1 ring-current'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              <span className="mr-1">{emotion.icon}</span>
              {emotion.name}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Energy & Stress Levels */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-sm font-medium mb-2 block flex items-center gap-1">
            <Zap className="text-yellow-500" size={14} />
            Energy Level
          </label>
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-gray-600">
              <span>Low</span>
              <span>High</span>
            </div>
            <div className="grid grid-cols-10 gap-1">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => (
                <button
                  key={level}
                  onClick={() => setEnergy(level)}
                  className={`h-6 rounded transition-all ${
                    energy >= level
                      ? 'bg-gradient-to-t from-yellow-400 to-yellow-500'
                      : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        <div>
          <label className="text-sm font-medium mb-2 block flex items-center gap-1">
            <Cloud className="text-red-500" size={14} />
            Stress Level
          </label>
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-gray-600">
              <span>Low</span>
              <span>High</span>
            </div>
            <div className="grid grid-cols-10 gap-1">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => (
                <button
                  key={level}
                  onClick={() => setStress(level)}
                  className={`h-6 rounded transition-all ${
                    stress >= level
                      ? 'bg-gradient-to-t from-red-400 to-red-500'
                      : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Notes */}
      <div>
        <label className="text-sm font-medium mb-2 block">Additional thoughts (optional)</label>
        <Textarea
          placeholder="What's contributing to how you feel? Any specific thoughts or events?"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="min-h-[80px]"
        />
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button
          onClick={onSave}
          disabled={selectedEmotions.length === 0 || isSubmitting}
          className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          {isSubmitting ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Saving...
            </div>
          ) : (
            <>
              <Heart size={16} className="mr-2" />
              Log Mood
            </>
          )}
        </Button>
        {onCancel && (
          <Button onClick={onCancel} variant="outline">
            Cancel
          </Button>
        )}
      </div>
    </div>
  );
}

function MoodHistoryView({ moodHistory }: { moodHistory: MoodEntry[] }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-7 gap-2">
        {moodHistory.map((entry) => (
          <motion.div
            key={entry.id}
            whileHover={{ scale: 1.05 }}
            className="text-center p-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer"
            title={`Mood: ${entry.mood}/10 | ${entry.emotions.join(', ')} | ${entry.timestamp.toLocaleDateString()}`}
          >
            <div className="text-lg mb-1">
              {MOOD_EMOJIS[entry.mood as keyof typeof MOOD_EMOJIS].emoji}
            </div>
            <div className="text-xs text-gray-600">
              {entry.timestamp.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </div>
            <div className="flex justify-center gap-1 mt-1">
              <div className="flex gap-0.5">
                {[1, 2, 3, 4, 5].map((level) => (
                  <div
                    key={level}
                    className={`w-1 h-1 rounded-full ${
                      entry.energy >= level * 2 ? 'bg-yellow-400' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {moodHistory.length > 0 && moodHistory[0].aiInsights && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <h4 className="font-medium text-blue-800 mb-2 flex items-center gap-2">
              <Eye className="text-blue-600" size={16} />
              Latest Insights
            </h4>
            <div className="space-y-2">
              {moodHistory[0].aiInsights.suggestions.slice(0, 2).map((suggestion, index) => (
                <div key={index} className="text-sm text-blue-700 flex items-start gap-2">
                  <Target size={12} className="mt-0.5 text-blue-500" />
                  {suggestion}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}