import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Sparkles, Heart, Star, Rainbow, Lightbulb } from "lucide-react";

const neurodivergentFacts = [
  {
    icon: Brain,
    title: "Unique Brain Wiring",
    fact: "Neurodivergent minds process information through different neural pathways, leading to innovative thinking patterns and creative problem-solving approaches.",
    color: "purple"
  },
  {
    icon: Lightbulb,
    title: "Hyperfocus Superpower",
    fact: "Many neurodivergent individuals can achieve states of intense concentration, allowing them to dive deep into subjects they're passionate about.",
    color: "blue"
  },
  {
    icon: Rainbow,
    title: "Diverse Thinking Styles",
    fact: "Neurodiversity includes ADHD, autism, dyslexia, and more - each bringing unique strengths like pattern recognition, detail orientation, and out-of-the-box thinking.",
    color: "pink"
  },
  {
    icon: Star,
    title: "Innovation Leaders",
    fact: "Many breakthrough innovations come from neurodivergent minds who see the world differently and aren't limited by conventional thinking patterns.",
    color: "green"
  },
  {
    icon: Heart,
    title: "Emotional Depth",
    fact: "Neurodivergent individuals often experience emotions with great intensity and empathy, leading to deep connections and understanding of others.",
    color: "rose"
  },
  {
    icon: Sparkles,
    title: "Creative Excellence",
    fact: "Studies show that neurodivergent individuals often excel in creative fields, bringing fresh perspectives and innovative approaches to art, music, and design.",
    color: "amber"
  }
];

const artPatterns = [
  // Flowing organic shapes representing different thinking patterns
  <svg viewBox="0 0 200 200" className="w-full h-full opacity-20">
    <defs>
      <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#a855f7" />
        <stop offset="50%" stopColor="#ec4899" />
        <stop offset="100%" stopColor="#06b6d4" />
      </linearGradient>
    </defs>
    <path d="M20,50 Q50,10 80,50 T140,50 Q170,20 200,50 L200,200 L0,200 Z" fill="url(#gradient1)" />
    <circle cx="60" cy="80" r="15" fill="#fbbf24" opacity="0.7" />
    <circle cx="130" cy="120" r="10" fill="#10b981" opacity="0.8" />
    <path d="M100,130 Q120,110 140,130 T180,130" stroke="#f59e0b" strokeWidth="3" fill="none" opacity="0.6" />
  </svg>,
  
  // Neural network inspired pattern
  <svg viewBox="0 0 200 200" className="w-full h-full opacity-20">
    <defs>
      <radialGradient id="gradient2" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#8b5cf6" />
        <stop offset="100%" stopColor="#06b6d4" />
      </radialGradient>
    </defs>
    <circle cx="50" cy="50" r="8" fill="#a855f7" />
    <circle cx="150" cy="50" r="6" fill="#ec4899" />
    <circle cx="100" cy="100" r="10" fill="#06b6d4" />
    <circle cx="50" cy="150" r="7" fill="#10b981" />
    <circle cx="150" cy="150" r="9" fill="#f59e0b" />
    <line x1="50" y1="50" x2="100" y2="100" stroke="#a855f7" strokeWidth="2" opacity="0.6" />
    <line x1="150" y1="50" x2="100" y2="100" stroke="#ec4899" strokeWidth="2" opacity="0.6" />
    <line x1="100" y1="100" x2="50" y2="150" stroke="#06b6d4" strokeWidth="2" opacity="0.6" />
    <line x1="100" y1="100" x2="150" y2="150" stroke="#10b981" strokeWidth="2" opacity="0.6" />
    <rect x="0" y="180" width="200" height="20" fill="url(#gradient2)" />
  </svg>,
  
  // Flowing creativity pattern
  <svg viewBox="0 0 200 200" className="w-full h-full opacity-20">
    <defs>
      <linearGradient id="gradient3" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#10b981" />
        <stop offset="50%" stopColor="#a855f7" />
        <stop offset="100%" stopColor="#f59e0b" />
      </linearGradient>
    </defs>
    <path d="M0,100 Q50,50 100,100 T200,100" stroke="url(#gradient3)" strokeWidth="4" fill="none" />
    <path d="M0,120 Q30,80 60,120 T120,120 Q150,90 180,120" stroke="#ec4899" strokeWidth="3" fill="none" opacity="0.7" />
    <circle cx="40" cy="60" r="5" fill="#06b6d4" />
    <circle cx="80" cy="140" r="7" fill="#8b5cf6" />
    <circle cx="120" cy="70" r="6" fill="#10b981" />
    <circle cx="160" cy="130" r="8" fill="#f59e0b" />
  </svg>
];

interface NeurodivergentArtProps {
  showFacts?: boolean;
}

export default function NeurodivergentArt({ showFacts = true }: NeurodivergentArtProps) {
  return (
    <div className="space-y-8">
      {/* Artistic Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center gap-3 mb-4">
          <Rainbow className="text-pink-500" size={32} />
          <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 via-pink-500 to-blue-500 bg-clip-text text-transparent">
            Celebrating Neurodiversity
          </h2>
          <Sparkles className="text-blue-500" size={32} />
        </div>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Every mind is unique and valuable. Neurodivergent thinking brings innovation, creativity, and fresh perspectives to our world.
        </p>
      </motion.div>

      {/* Artistic Patterns */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {artPatterns.map((pattern, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.2 }}
            className="h-32 bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl overflow-hidden relative"
          >
            {pattern}
          </motion.div>
        ))}
      </div>

      {/* Neurodivergent Facts */}
      {showFacts && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {neurodivergentFacts.map((item, index) => {
            const Icon = item.icon;
            const colorClasses = {
              purple: "from-purple-100 to-purple-200 border-purple-200",
              blue: "from-blue-100 to-blue-200 border-blue-200",
              pink: "from-pink-100 to-pink-200 border-pink-200",
              green: "from-green-100 to-green-200 border-green-200",
              rose: "from-rose-100 to-rose-200 border-rose-200",
              amber: "from-amber-100 to-amber-200 border-amber-200",
            };
            const iconColors = {
              purple: "text-purple-600",
              blue: "text-blue-600",
              pink: "text-pink-600",
              green: "text-green-600",
              rose: "text-rose-600",
              amber: "text-amber-600",
            };

            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
              >
                <Card className={`bg-gradient-to-br ${colorClasses[item.color as keyof typeof colorClasses]} shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 h-full`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <Icon className={iconColors[item.color as keyof typeof iconColors]} size={24} />
                      <CardTitle className="text-lg">{item.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 text-sm leading-relaxed">{item.fact}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Inspirational Quote */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="text-center"
      >
        <Card className="glass-effect border-purple-200/30 shadow-2xl backdrop-blur-sm max-w-3xl mx-auto">
          <CardContent className="p-8">
            <div className="flex items-center justify-center mb-4">
              <Heart className="text-pink-500 mr-2" size={28} />
              <Sparkles className="text-purple-500 ml-2" size={28} />
            </div>
            <blockquote className="text-xl italic text-gray-700 mb-4">
              "Neurodiversity is not a defect. It's a feature. It's how we're made."
            </blockquote>
            <p className="text-gray-600">— Temple Grandin</p>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                Different is Beautiful
              </Badge>
              <Badge className="bg-gradient-to-r from-blue-500 to-green-500 text-white">
                Unique Perspectives Matter
              </Badge>
              <Badge className="bg-gradient-to-r from-pink-500 to-orange-500 text-white">
                Celebrate Every Mind
              </Badge>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}