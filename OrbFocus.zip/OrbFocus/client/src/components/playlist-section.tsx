import { useState } from "react";
import { motion } from "framer-motion";
import { Music, Play, Pause, Volume2, CloudRain, TreePine, Waves } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const sounds = [
  {
    id: "rain",
    name: "Gentle Rain",
    icon: CloudRain,
    color: "hsl(198, 71%, 73%)",
    url: "https://www.soundjay.com/misc/sounds/rain-01.wav" // Example URL
  },
  {
    id: "forest",
    name: "Forest Ambience",
    icon: TreePine,
    color: "hsl(142, 28%, 59%)",
    url: "https://www.soundjay.com/nature/sounds/forest-1.wav" // Example URL
  },
  {
    id: "waves",
    name: "Ocean Waves",
    icon: Waves,
    color: "hsl(198, 71%, 73%)",
    url: "https://www.soundjay.com/misc/sounds/wave-1.wav" // Example URL
  }
];

export default function PlaylistSection() {
  const [currentSound, setCurrentSound] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const queryClient = useQueryClient();

  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (updates: any) => {
      const response = await apiRequest("PUT", "/api/settings", updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
  });

  const volume = (settings as any)?.soundVolume || 70;

  const playSound = (soundId: string) => {
    if (currentSound === soundId && isPlaying) {
      setIsPlaying(false);
      setCurrentSound(null);
    } else {
      setCurrentSound(soundId);
      setIsPlaying(true);
      // Here you would implement actual audio playback
    }
  };

  const adjustVolume = (newVolume: number[]) => {
    updateSettingsMutation.mutate({ soundVolume: newVolume[0] });
  };

  return (
    <div className="bg-white rounded-3xl p-8 shadow-lg border border-[hsl(142,28%,59%)]/10">
      <div className="flex items-center mb-6">
        <div className="w-12 h-12 rounded-full gradient-calm flex items-center justify-center mr-4">
          <Music className="text-white" size={20} />
        </div>
        <h2 className="text-2xl font-medium text-[hsl(0,0%,36%)]" style={{ fontFamily: 'Poppins' }}>
          Focus Sounds
        </h2>
      </div>
      
      <div className="space-y-3">
        {sounds.map((sound) => {
          const IconComponent = sound.icon;
          const isCurrentlyPlaying = currentSound === sound.id && isPlaying;
          
          return (
            <motion.div
              key={sound.id}
              className="flex items-center p-3 rounded-xl bg-[hsl(49,37%,97%)]/50 hover:bg-[hsl(142,28%,59%)]/5 transition-colors duration-300 cursor-pointer"
              whileHover={{ x: 5 }}
              onClick={() => playSound(sound.id)}
            >
              <motion.div 
                className="w-10 h-10 rounded-full flex items-center justify-center mr-3"
                style={{ backgroundColor: `${sound.color}/20` }}
                animate={{ scale: isCurrentlyPlaying ? [1, 1.1, 1] : 1 }}
                transition={{ duration: 2, repeat: isCurrentlyPlaying ? Infinity : 0 }}
              >
                <IconComponent 
                  className="text-current" 
                  size={16}
                  style={{ color: sound.color }}
                />
              </motion.div>
              <div className="flex-1">
                <span className="font-medium text-[hsl(0,0%,36%)]">{sound.name}</span>
                {isCurrentlyPlaying && (
                  <motion.div
                    className="flex space-x-1 mt-1"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    {[1, 2, 3].map((bar) => (
                      <motion.div
                        key={bar}
                        className="w-1 bg-current rounded-full"
                        style={{ color: sound.color }}
                        animate={{
                          height: [4, 12, 4],
                        }}
                        transition={{
                          duration: 1,
                          repeat: Infinity,
                          delay: bar * 0.2,
                        }}
                      />
                    ))}
                  </motion.div>
                )}
              </div>
              <motion.div
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                {isCurrentlyPlaying ? (
                  <Pause className="text-[hsl(142,28%,59%)]" size={16} />
                ) : (
                  <Play className="text-[hsl(142,28%,59%)]" size={16} />
                )}
              </motion.div>
            </motion.div>
          );
        })}
      </div>
      
      {/* Volume Control */}
      <div className="mt-6 p-4 rounded-xl bg-[hsl(142,28%,59%)]/5 border border-[hsl(142,28%,59%)]/10">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center">
            <Volume2 className="text-[hsl(0,0%,36%)]" size={16} />
            <span className="text-sm text-[hsl(0,0%,36%)] ml-2">Volume</span>
          </div>
          <span className="text-sm text-[hsl(142,28%,59%)]">{volume}%</span>
        </div>
        <Slider
          value={[volume]}
          onValueChange={adjustVolume}
          max={100}
          step={1}
          className="w-full"
        />
      </div>
    </div>
  );
}