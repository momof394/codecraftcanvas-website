import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  MessageCircle, 
  Send, 
  Brain, 
  Heart, 
  Settings, 
  Mic, 
  MicOff,
  Phone,
  Shield,
  Lightbulb,
  Target,
  TrendingUp,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

interface TherapyMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  emotionalAnalysis?: {
    sentiment: number;
    emotions: string[];
    intensity: number;
  };
}

interface TherapySession {
  id: string;
  title: string;
  sessionType: string;
  messages: TherapyMessage[];
  progress: number;
  duration: number;
  mood: number;
  isCompleted: boolean;
  aiInsights?: any;
  recommendations?: string[];
}

export default function AITherapyChat() {
  const [currentSession, setCurrentSession] = useState<TherapySession | null>(null);
  const [messages, setMessages] = useState<TherapyMessage[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [sessionType, setSessionType] = useState("general");
  const [aiPersonality, setAiPersonality] = useState("empathetic");
  const [isListening, setIsListening] = useState(false);
  const [sessionStarted, setSessionStarted] = useState(false);
  const [crisisMode, setCrisisMode] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const sessionTypes = [
    { value: "general", label: "General Support", icon: Heart, color: "bg-blue-500" },
    { value: "anxiety", label: "Anxiety Management", icon: Shield, color: "bg-green-500" },
    { value: "depression", label: "Depression Support", icon: Brain, color: "bg-purple-500" },
    { value: "adhd", label: "ADHD Focus", icon: Target, color: "bg-orange-500" },
    { value: "crisis", label: "Crisis Support", icon: Phone, color: "bg-red-500" }
  ];

  const aiPersonalities = [
    { value: "empathetic", label: "Empathetic & Warm", description: "Compassionate and understanding" },
    { value: "analytical", label: "Analytical & Structured", description: "Logical and systematic approach" },
    { value: "motivational", label: "Motivational & Uplifting", description: "Encouraging and energizing" }
  ];

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const startTherapySession = async () => {
    if (sessionType === "crisis") {
      setCrisisMode(true);
      toast({
        title: "Crisis Support Activated",
        description: "You're not alone. Help is available. If this is an emergency, please call 988."
      });
    }

    try {
      // Start the AI session
      const response = await fetch('/api/therapy/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sessionType,
          personality: aiPersonality
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to start therapy session');
      }

      const result = await response.json();
      
      const welcomeMessage: TherapyMessage = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: result.response,
        timestamp: new Date()
      };
      
      const newSession: TherapySession = {
        id: result.sessionId,
        title: `${sessionTypes.find(s => s.value === sessionType)?.label} Session`,
        sessionType,
        messages: [welcomeMessage],
        progress: 0,
        duration: 0,
        mood: 5,
        isCompleted: false,
        aiInsights: result.analysis
      };

      setCurrentSession(newSession);
      setMessages([welcomeMessage]);
      setSessionStarted(true);
    } catch (error) {
      console.error('Error starting therapy session:', error);
      toast({
        title: "Connection Issue",
        description: "Having trouble starting the AI session. Please check your connection and try again.",
        variant: "destructive"
      });
      
      // Fallback to welcome message
      const welcomeMessage = getWelcomeMessage(sessionType, aiPersonality);
      const newSession: TherapySession = {
        id: crypto.randomUUID(),
        title: `${sessionTypes.find(s => s.value === sessionType)?.label} Session`,
        sessionType,
        messages: [welcomeMessage],
        progress: 0,
        duration: 0,
        mood: 5,
        isCompleted: false
      };

      setCurrentSession(newSession);
      setMessages([welcomeMessage]);
      setSessionStarted(true);
    }
  };

  const getWelcomeMessage = (type: string, personality: string): TherapyMessage => {
    const welcomeMessages = {
      empathetic: {
        general: "Hello, and welcome to our session together. I'm here to listen and support you in whatever you're going through. This is a safe space where you can share openly. What would you like to talk about today?",
        anxiety: "I understand that anxiety can feel overwhelming, and I want you to know that what you're experiencing is valid. You've taken a brave step by being here. Let's work together to explore what's on your mind and find some strategies that might help.",
        depression: "Thank you for being here today. I know it might have taken courage to reach out, and I want to acknowledge that strength. You don't have to face this alone. What's been weighing on your heart lately?",
        adhd: "Welcome! I'm here to help you navigate the unique challenges and strengths that come with ADHD. Your brain works in wonderful ways, and together we can explore strategies to help you thrive. What aspects of daily life would you like to focus on?",
        crisis: "I'm here with you right now, and I want you to know that you're not alone in this moment. Your safety and wellbeing are the most important things. Can you tell me what's happening for you right now?"
      },
      analytical: {
        general: "Welcome to our therapy session. I'm here to help you understand patterns in your thoughts and behaviors. We'll work systematically to identify areas for growth. What specific challenges would you like to address?",
        anxiety: "Anxiety often follows predictable patterns. By understanding these patterns, we can develop effective coping strategies. Let's explore what triggers your anxiety and examine the thoughts that contribute to these feelings.",
        depression: "Depression involves complex interactions between thoughts, feelings, and behaviors. We'll work together to identify these patterns and develop structured approaches to improve your mood and functioning.",
        adhd: "ADHD presents unique cognitive patterns that we can learn to work with effectively. Let's identify your specific challenges and strengths, then develop systematic strategies for improvement.",
        crisis: "I understand you're in crisis. Let's focus on immediate safety and practical steps. Can you help me understand your current situation so we can work through this systematically?"
      },
      motivational: {
        general: "I'm so glad you're here today! Taking this step shows incredible strength and commitment to your wellbeing. You have the power to create positive change in your life. What goals are you excited to work toward?",
        anxiety: "You've already shown courage by seeking support for your anxiety. That's a powerful first step! We're going to work together to build your confidence and resilience. You have more strength than you realize.",
        depression: "I see your strength in being here today, even when things feel difficult. You have the capacity for healing and growth. Together, we'll focus on building hope and momentum toward feeling better.",
        adhd: "Your ADHD brain has unique gifts and abilities! We're going to harness those strengths while developing tools to manage challenges. You have so much potential, and I'm excited to help you unlock it.",
        crisis: "You reached out for help, and that shows incredible courage and wisdom. You're taking the right steps to get through this difficult time. Let's focus on getting you the support you need right now."
      }
    };

    const content = welcomeMessages[personality as keyof typeof welcomeMessages]?.[type as keyof typeof welcomeMessages.empathetic] || 
                   welcomeMessages.empathetic.general;

    return {
      id: crypto.randomUUID(),
      role: "assistant",
      content,
      timestamp: new Date()
    };
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !currentSession) return;

    const userMessage: TherapyMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    try {
      // Call the real AI API
      const response = await fetch('/api/therapy/continue', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sessionHistory: messages,
          newMessage: inputMessage,
          personality: aiPersonality
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get AI response');
      }

      const result = await response.json();
      
      const aiResponse: TherapyMessage = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: result.response,
        timestamp: new Date(),
        emotionalAnalysis: {
          sentiment: 0.7,
          emotions: ["supportive", "understanding"],
          intensity: 0.8
        }
      };

      setMessages(prev => [...prev, aiResponse]);
      
      // Update session progress
      setCurrentSession(prev => prev ? {
        ...prev,
        progress: Math.min(100, prev.progress + 10),
        duration: prev.duration + 1,
        aiInsights: result.analysis
      } : null);
    } catch (error) {
      console.error('Error getting AI response:', error);
      toast({
        title: "Connection Issue",
        description: "Having trouble connecting to the AI assistant. Please try again.",
        variant: "destructive"
      });
      
      // Fallback to a supportive message
      const fallbackResponse: TherapyMessage = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: "I'm here to listen and support you. Sometimes I might have connection issues, but I'm always ready to help when you need me.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, fallbackResponse]);
    } finally {
      setIsTyping(false);
    }
  };

  const generateAIResponse = (userInput: string, type: string, personality: string, messageCount: number): TherapyMessage => {
    // This would connect to the AI service in a real implementation
    const responses = {
      empathetic: [
        "I hear you, and what you're sharing sounds really difficult. It takes courage to open up about these feelings.",
        "Thank you for trusting me with this. Your feelings are completely valid, and it's okay to feel this way.",
        "That sounds really challenging. How has this been affecting you day to day?",
        "I can sense the weight of what you're carrying. You don't have to go through this alone.",
        "What you've shared resonates with me. How long have you been feeling this way?"
      ],
      analytical: [
        "Let's explore this pattern. When did you first notice these thoughts or feelings emerging?",
        "I'm noticing some themes in what you've shared. Can you help me understand what typically triggers these experiences?",
        "That's a helpful insight. Let's break this down into smaller components we can work with.",
        "Based on what you've described, it seems like there might be some cognitive patterns we can examine together.",
        "How do you think this situation connects to other experiences you've had?"
      ],
      motivational: [
        "I love that you're being so open and honest! That self-awareness is a real strength.",
        "You're doing great by talking through this. Every step you take toward understanding yourself better is progress!",
        "I can see your resilience shining through, even in this difficult situation. That's something to build on!",
        "What you've shared shows real insight and growth. How can we use this awareness to move forward?",
        "You have so much wisdom already within you. What do you think might be a good next step?"
      ]
    };

    const responseArray = responses[personality as keyof typeof responses] || responses.empathetic;
    const content = responseArray[messageCount % responseArray.length];

    return {
      id: crypto.randomUUID(),
      role: "assistant",
      content,
      timestamp: new Date(),
      emotionalAnalysis: {
        sentiment: Math.random() * 0.4 + 0.3, // Positive sentiment for therapy
        emotions: ["supportive", "understanding", "caring"],
        intensity: 0.7
      }
    };
  };

  const endSession = () => {
    if (currentSession) {
      const completedSession = {
        ...currentSession,
        isCompleted: true,
        messages
      };
      
      // In a real app, this would save to the database
      toast({
        title: "Session Completed",
        description: "Your progress has been saved. Take care of yourself!"
      });
    }
    
    setSessionStarted(false);
    setCurrentSession(null);
    setMessages([]);
    setCrisisMode(false);
  };

  if (!sessionStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl font-bold text-gray-800 mb-4 flex items-center justify-center gap-3">
              <Brain className="text-blue-600" />
              AI Therapy Assistant
              <Heart className="text-red-500" />
            </h1>
            <p className="text-gray-600">Your personal AI therapist for compassionate mental health support</p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Session Configuration */}
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="text-blue-600" />
                  Session Setup
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="text-sm font-medium mb-3 block">What would you like support with today?</label>
                  <div className="grid grid-cols-1 gap-3">
                    {sessionTypes.map((type) => {
                      const Icon = type.icon;
                      return (
                        <motion.button
                          key={type.value}
                          whileHover={{ scale: 1.02 }}
                          onClick={() => setSessionType(type.value)}
                          className={`p-4 rounded-lg border-2 text-left transition-all ${
                            sessionType === type.value
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-blue-300'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-full ${type.color} text-white`}>
                              <Icon size={20} />
                            </div>
                            <div>
                              <h3 className="font-medium">{type.label}</h3>
                            </div>
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-3 block">AI Personality</label>
                  <Select value={aiPersonality} onValueChange={setAiPersonality}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {aiPersonalities.map((personality) => (
                        <SelectItem key={personality.value} value={personality.value}>
                          <div>
                            <div className="font-medium">{personality.label}</div>
                            <div className="text-xs text-gray-500">{personality.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={startTherapySession}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  size="lg"
                >
                  Start Therapy Session
                </Button>
              </CardContent>
            </Card>

            {/* Crisis Resources */}
            <Card className="shadow-xl border-red-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <Phone />
                  Crisis Resources
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                  <h3 className="font-semibold text-red-800 mb-2">Need immediate help?</h3>
                  <div className="space-y-2 text-sm">
                    <div>
                      <strong>National Suicide Prevention Lifeline:</strong>
                      <div className="text-2xl font-bold text-red-600">988</div>
                    </div>
                    <div>
                      <strong>Crisis Text Line:</strong>
                      <div>Text HOME to <span className="font-bold">741741</span></div>
                    </div>
                    <div>
                      <strong>SAMHSA National Helpline:</strong>
                      <div className="font-bold">1-800-662-4357</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Remember:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• You are not alone in this</li>
                    <li>• Your feelings are valid</li>
                    <li>• This feeling will pass</li>
                    <li>• Help is always available</li>
                    <li>• You matter and your life has value</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-6xl mx-auto p-6">
        {/* Session Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Card className={`shadow-lg ${crisisMode ? 'border-red-500 bg-red-50' : 'border-blue-200 bg-blue-50'}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Brain className={crisisMode ? "text-red-600" : "text-blue-600"} />
                  <div>
                    <h1 className="text-xl font-bold">{currentSession?.title}</h1>
                    <p className="text-sm text-gray-600">
                      AI Personality: {aiPersonalities.find(p => p.value === aiPersonality)?.label}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <div className="text-sm text-gray-600">Progress</div>
                    <div className="font-bold">{currentSession?.progress}%</div>
                  </div>
                  <Button onClick={endSession} variant="outline">
                    End Session
                  </Button>
                </div>
              </div>
              {currentSession && (
                <Progress value={currentSession.progress} className="mt-4" />
              )}
            </CardHeader>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Chat Area */}
          <div className="lg:col-span-3">
            <Card className="shadow-xl h-[600px] flex flex-col">
              <CardContent className="flex-1 p-6 overflow-y-auto">
                <AnimatePresence>
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
                    >
                      <div
                        className={`max-w-[80%] p-4 rounded-lg ${
                          message.role === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        <div className="whitespace-pre-wrap">{message.content}</div>
                        <div className={`text-xs mt-2 ${
                          message.role === 'user' ? 'text-blue-200' : 'text-gray-500'
                        }`}>
                          {message.timestamp.toLocaleTimeString()}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
                
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex justify-start mb-4"
                  >
                    <div className="bg-gray-100 text-gray-800 p-4 rounded-lg">
                      <div className="flex items-center gap-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                        <span className="text-sm text-gray-600">AI is thinking...</span>
                      </div>
                    </div>
                  </motion.div>
                )}
                
                <div ref={messagesEndRef} />
              </CardContent>
              
              {/* Message Input */}
              <div className="border-t p-4">
                <div className="flex gap-3">
                  <Textarea
                    placeholder="Share what's on your mind..."
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        sendMessage();
                      }
                    }}
                    className="flex-1 min-h-[60px] max-h-[120px]"
                  />
                  <div className="flex flex-col gap-2">
                    <Button
                      onClick={() => setIsListening(!isListening)}
                      variant="outline"
                      size="sm"
                      className={isListening ? "bg-red-100 text-red-600" : ""}
                    >
                      {isListening ? <MicOff size={16} /> : <Mic size={16} />}
                    </Button>
                    <Button
                      onClick={sendMessage}
                      disabled={!inputMessage.trim() || isTyping}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Send size={16} />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Session Info Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="text-green-600" />
                  Session Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Duration</span>
                    <span>{currentSession?.duration || 0} min</span>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Messages</span>
                    <span>{messages.length}</span>
                  </div>
                </div>
                <div>
                  <div className="text-sm mb-2">Current Mood</div>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((num) => (
                      <Heart
                        key={num}
                        size={16}
                        className={num <= (currentSession?.mood || 5) ? "text-red-500 fill-current" : "text-gray-300"}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {crisisMode && (
              <Card className="border-red-500 bg-red-50">
                <CardHeader>
                  <CardTitle className="text-red-600 flex items-center gap-2">
                    <Phone />
                    Crisis Support
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <Button
                      className="w-full bg-red-600 hover:bg-red-700"
                      onClick={() => window.open('tel:988')}
                    >
                      Call 988 Now
                    </Button>
                    <p className="text-xs text-red-700">
                      National Suicide Prevention Lifeline - Available 24/7
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Lightbulb className="text-yellow-600" />
                  Quick Tools
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Calendar size={16} className="mr-2" />
                  Schedule Follow-up
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Brain size={16} className="mr-2" />
                  Breathing Exercise
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Heart size={16} className="mr-2" />
                  Mood Check-in
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}