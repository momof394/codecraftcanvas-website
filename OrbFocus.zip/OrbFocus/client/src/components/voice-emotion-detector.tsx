import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Mic, 
  MicOff, 
  Play, 
  Pause, 
  Square,
  Brain,
  Heart,
  Smile,
  Frown,
  Meh,
  AlertCircle,
  TrendingUp,
  Volume2
} from "lucide-react";

interface EmotionAnalysis {
  emotion: string;
  confidence: number;
  timestamp: number;
  audioFeatures: {
    pitch: number;
    energy: number;
    speechRate: number;
    volume: number;
  };
}

interface VoiceEmotionDetectorProps {
  onEmotionDetected?: (analysis: EmotionAnalysis) => void;
  onTranscriptUpdate?: (transcript: string) => void;
  isJournalMode?: boolean;
}

// Extend window interface for speech recognition
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

export default function VoiceEmotionDetector({ 
  onEmotionDetected, 
  onTranscriptUpdate,
  isJournalMode = false 
}: VoiceEmotionDetectorProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentEmotion, setCurrentEmotion] = useState<EmotionAnalysis | null>(null);
  const [emotionHistory, setEmotionHistory] = useState<EmotionAnalysis[]>([]);
  const [transcript, setTranscript] = useState("");
  const [audioLevel, setAudioLevel] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const animationFrameRef = useRef<number>();

  // Emotion icons mapping
  const emotionIcons = {
    happy: Smile,
    sad: Frown,
    neutral: Meh,
    angry: AlertCircle,
    excited: TrendingUp,
    calm: Heart,
    stressed: AlertCircle,
    confident: Brain
  };

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      if (recognitionRef.current) {
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.lang = 'en-US';
        
        recognitionRef.current.onresult = (event: any) => {
          let finalTranscript = '';
          let interimTranscript = '';
          
          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += transcript;
            } else {
              interimTranscript += transcript;
            }
          }
          
          const fullTranscript = finalTranscript || interimTranscript;
          setTranscript(fullTranscript);
          onTranscriptUpdate?.(fullTranscript);
        };
      }
    }
  }, [onTranscriptUpdate]);

  // Audio analysis for emotion detection
  const analyzeAudioFeatures = () => {
    if (!analyserRef.current) return null;
    
    const bufferLength = analyserRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyserRef.current.getByteFrequencyData(dataArray);
    
    // Calculate audio features
    const average = dataArray.reduce((sum, value) => sum + value, 0) / bufferLength;
    const energy = Math.sqrt(dataArray.reduce((sum, value) => sum + value * value, 0) / bufferLength);
    
    // Estimate pitch (simplified - find peak frequency)
    let maxIndex = 0;
    let maxValue = 0;
    for (let i = 0; i < bufferLength; i++) {
      if (dataArray[i] > maxValue) {
        maxValue = dataArray[i];
        maxIndex = i;
      }
    }
    const pitch = (maxIndex / bufferLength) * (audioContextRef.current?.sampleRate || 44100) / 2;
    
    setAudioLevel(average / 255 * 100);
    
    return {
      pitch: Math.min(pitch, 1000), // Cap at 1000Hz for display
      energy: energy / 255 * 100,
      speechRate: 1.0, // Would need more complex analysis
      volume: average / 255 * 100
    };
  };

  // Simplified emotion detection based on audio features
  const detectEmotion = (features: any): EmotionAnalysis => {
    const { pitch, energy, volume } = features;
    
    let emotion = 'neutral';
    let confidence = 0.5;
    
    // Simple heuristic-based emotion detection
    if (energy > 70 && pitch > 200) {
      emotion = 'excited';
      confidence = 0.8;
    } else if (energy > 60 && pitch > 150) {
      emotion = 'happy';
      confidence = 0.75;
    } else if (energy < 30 && pitch < 100) {
      emotion = 'sad';
      confidence = 0.7;
    } else if (energy > 80 && pitch < 150) {
      emotion = 'angry';
      confidence = 0.65;
    } else if (energy < 40 && pitch > 120 && pitch < 180) {
      emotion = 'calm';
      confidence = 0.6;
    } else if (energy > 50 && pitch > 180) {
      emotion = 'stressed';
      confidence = 0.55;
    }
    
    return {
      emotion,
      confidence,
      timestamp: Date.now(),
      audioFeatures: features
    };
  };

  // Animation loop for real-time analysis
  const analyzeLoop = () => {
    if (!isRecording) return;
    
    const features = analyzeAudioFeatures();
    if (features) {
      const analysis = detectEmotion(features);
      setCurrentEmotion(analysis);
      onEmotionDetected?.(analysis);
      
      // Store in history every 2 seconds
      if (emotionHistory.length === 0 || Date.now() - emotionHistory[emotionHistory.length - 1].timestamp > 2000) {
        setEmotionHistory(prev => [...prev.slice(-19), analysis]); // Keep last 20 entries
      }
    }
    
    animationFrameRef.current = requestAnimationFrame(analyzeLoop);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Setup audio context for analysis
      audioContextRef.current = new AudioContext();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;
      source.connect(analyserRef.current);
      
      // Setup media recorder
      mediaRecorderRef.current = new MediaRecorder(stream);
      mediaRecorderRef.current.start();
      
      // Start speech recognition
      if (recognitionRef.current) {
        recognitionRef.current.start();
      }
      
      setIsRecording(true);
      setIsAnalyzing(true);
      analyzeLoop();
      
    } catch (error) {
      console.error('Error accessing microphone:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    
    setIsRecording(false);
    setIsAnalyzing(false);
    setAudioLevel(0);
  };

  const getEmotionColor = (emotion: string) => {
    const colors: Record<string, string> = {
      happy: 'text-yellow-600 bg-yellow-100',
      sad: 'text-blue-600 bg-blue-100',
      angry: 'text-red-600 bg-red-100',
      excited: 'text-orange-600 bg-orange-100',
      calm: 'text-green-600 bg-green-100',
      stressed: 'text-purple-600 bg-purple-100',
      confident: 'text-indigo-600 bg-indigo-100',
      neutral: 'text-gray-600 bg-gray-100'
    };
    return colors[emotion] || colors.neutral;
  };

  const EmotionIcon = currentEmotion ? emotionIcons[currentEmotion.emotion as keyof typeof emotionIcons] || Meh : Meh;

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Brain className="w-5 h-5 text-purple-600" />
          <span>Voice Emotion Analysis</span>
        </CardTitle>
        <CardDescription>
          Real-time emotion detection from voice patterns and speech analysis
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Recording Controls */}
        <div className="flex items-center justify-center space-x-4">
          <Button
            onClick={isRecording ? stopRecording : startRecording}
            variant={isRecording ? "destructive" : "default"}
            size="lg"
            className="w-32"
          >
            {isRecording ? (
              <>
                <Square className="w-4 h-4 mr-2" />
                Stop
              </>
            ) : (
              <>
                <Mic className="w-4 h-4 mr-2" />
                Start
              </>
            )}
          </Button>
        </div>

        {/* Audio Level Indicator */}
        {isRecording && (
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Volume2 className="w-4 h-4" />
              <span className="text-sm font-medium">Audio Level</span>
            </div>
            <Progress value={audioLevel} className="w-full" />
          </div>
        )}

        {/* Current Emotion Display */}
        {currentEmotion && (
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-3">
              <EmotionIcon className="w-12 h-12 text-purple-600" />
              <div>
                <Badge className={`text-lg px-4 py-2 ${getEmotionColor(currentEmotion.emotion)}`}>
                  {currentEmotion.emotion.charAt(0).toUpperCase() + currentEmotion.emotion.slice(1)}
                </Badge>
                <p className="text-sm text-muted-foreground mt-1">
                  Confidence: {Math.round(currentEmotion.confidence * 100)}%
                </p>
              </div>
            </div>

            {/* Audio Features */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Pitch</p>
                <p className="font-medium">{Math.round(currentEmotion.audioFeatures.pitch)}Hz</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Energy</p>
                <p className="font-medium">{Math.round(currentEmotion.audioFeatures.energy)}%</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Volume</p>
                <p className="font-medium">{Math.round(currentEmotion.audioFeatures.volume)}%</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Rate</p>
                <p className="font-medium">{currentEmotion.audioFeatures.speechRate.toFixed(1)}x</p>
              </div>
            </div>
          </div>
        )}

        {/* Speech Transcript */}
        {transcript && (
          <div className="space-y-2">
            <h4 className="font-medium flex items-center space-x-2">
              <Mic className="w-4 h-4" />
              <span>Live Transcript</span>
            </h4>
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm">{transcript}</p>
            </div>
          </div>
        )}

        {/* Emotion History */}
        {emotionHistory.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium">Emotion Timeline</h4>
            <div className="flex flex-wrap gap-2">
              {emotionHistory.slice(-10).map((analysis, index) => {
                const Icon = emotionIcons[analysis.emotion as keyof typeof emotionIcons] || Meh;
                return (
                  <div key={index} className="flex items-center space-x-1">
                    <Icon className="w-4 h-4" />
                    <Badge 
                      variant="secondary" 
                      className={`text-xs ${getEmotionColor(analysis.emotion)}`}
                    >
                      {analysis.emotion}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Analysis Status */}
        {isAnalyzing && (
          <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
            <div className="animate-pulse w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Analyzing voice emotions in real-time...</span>
          </div>
        )}

        {/* Journal Integration Notice */}
        {isJournalMode && (
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-700 dark:text-blue-300">
              <Heart className="w-4 h-4 inline mr-1" />
              Voice emotions will be automatically logged with your journal entry to track emotional patterns over time.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}