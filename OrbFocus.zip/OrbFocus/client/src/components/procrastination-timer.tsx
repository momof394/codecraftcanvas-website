import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Timer, 
  Coffee, 
  Target,
  TrendingUp,
  Brain,
  Zap,
  Clock,
  CheckCircle2,
  AlertCircle,
  Settings,
  BarChart3
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface TimerSession {
  id: string;
  technique: string;
  workDuration: number;
  breakDuration: number;
  longBreakDuration: number;
  sessionsUntilLongBreak: number;
  currentSession: number;
  totalSessions: number;
  isRunning: boolean;
  isBreak: boolean;
  timeRemaining: number;
  completedSessions: number;
  task: string;
  category: string;
  startTime: Date;
  endTime?: Date;
}

interface TimerStats {
  totalFocusTime: number;
  sessionsCompleted: number;
  tasksCompleted: number;
  longestStreak: number;
  currentStreak: number;
  productivityScore: number;
}

const TIMER_TECHNIQUES = {
  pomodoro: {
    name: "Pomodoro",
    description: "25 min work, 5 min break",
    workDuration: 25,
    breakDuration: 5,
    longBreakDuration: 15,
    sessionsUntilLongBreak: 4,
    icon: Timer,
    color: "bg-red-500"
  },
  flowtime: {
    name: "Flowtime",
    description: "90 min work, 20 min break",
    workDuration: 90,
    breakDuration: 20,
    longBreakDuration: 30,
    sessionsUntilLongBreak: 2,
    icon: Zap,
    color: "bg-blue-500"
  },
  timeblocking: {
    name: "Time Blocking",
    description: "Custom focused blocks",
    workDuration: 60,
    breakDuration: 10,
    longBreakDuration: 30,
    sessionsUntilLongBreak: 3,
    icon: Target,
    color: "bg-green-500"
  },
  ultradian: {
    name: "Ultradian",
    description: "120 min natural rhythm",
    workDuration: 120,
    breakDuration: 20,
    longBreakDuration: 30,
    sessionsUntilLongBreak: 2,
    icon: Brain,
    color: "bg-purple-500"
  }
};

const TASK_CATEGORIES = [
  { value: "work", label: "Work/Professional", color: "bg-blue-100 text-blue-800" },
  { value: "study", label: "Study/Learning", color: "bg-green-100 text-green-800" },
  { value: "creative", label: "Creative Projects", color: "bg-purple-100 text-purple-800" },
  { value: "personal", label: "Personal Tasks", color: "bg-orange-100 text-orange-800" },
  { value: "health", label: "Health/Wellness", color: "bg-pink-100 text-pink-800" },
  { value: "household", label: "Household", color: "bg-gray-100 text-gray-800" }
];

export default function ProcrastinationTimer({ isFloating = false }: { isFloating?: boolean }) {
  const [currentSession, setCurrentSession] = useState<TimerSession | null>(null);
  const [technique, setTechnique] = useState("pomodoro");
  const [taskInput, setTaskInput] = useState("");
  const [taskCategory, setTaskCategory] = useState("work");
  const [stats, setStats] = useState<TimerStats>({
    totalFocusTime: 0,
    sessionsCompleted: 0,
    tasksCompleted: 0,
    longestStreak: 0,
    currentStreak: 0,
    productivityScore: 85
  });
  const [isMinimized, setIsMinimized] = useState(isFloating);
  const [showStats, setShowStats] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Load stats from localStorage
    const savedStats = localStorage.getItem('procrastination_timer_stats');
    if (savedStats) {
      setStats(JSON.parse(savedStats));
    }
  }, []);

  useEffect(() => {
    if (currentSession?.isRunning) {
      intervalRef.current = setInterval(() => {
        setCurrentSession(prev => {
          if (!prev) return null;
          
          const newTimeRemaining = prev.timeRemaining - 1;
          
          if (newTimeRemaining <= 0) {
            handleTimerComplete(prev);
            return {
              ...prev,
              timeRemaining: 0,
              isRunning: false
            };
          }
          
          return {
            ...prev,
            timeRemaining: newTimeRemaining
          };
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [currentSession?.isRunning]);

  const startTimer = () => {
    if (!taskInput.trim()) {
      toast({ description: "Please enter a task before starting the timer" });
      return;
    }

    const techniqueConfig = TIMER_TECHNIQUES[technique as keyof typeof TIMER_TECHNIQUES];
    
    const newSession: TimerSession = {
      id: crypto.randomUUID(),
      technique,
      workDuration: techniqueConfig.workDuration,
      breakDuration: techniqueConfig.breakDuration,
      longBreakDuration: techniqueConfig.longBreakDuration,
      sessionsUntilLongBreak: techniqueConfig.sessionsUntilLongBreak,
      currentSession: 1,
      totalSessions: 1,
      isRunning: true,
      isBreak: false,
      timeRemaining: techniqueConfig.workDuration * 60,
      completedSessions: 0,
      task: taskInput,
      category: taskCategory,
      startTime: new Date()
    };

    setCurrentSession(newSession);
    toast({ 
      title: "Timer Started", 
      description: `Working on: ${taskInput}` 
    });
  };

  const pauseTimer = () => {
    setCurrentSession(prev => prev ? { ...prev, isRunning: false } : null);
  };

  const resumeTimer = () => {
    setCurrentSession(prev => prev ? { ...prev, isRunning: true } : null);
  };

  const resetTimer = () => {
    setCurrentSession(null);
    setTaskInput("");
    toast({ description: "Timer reset" });
  };

  const handleTimerComplete = (session: TimerSession) => {
    if (soundEnabled) {
      // Play notification sound
      const audio = new Audio('/api/placeholder/notification.mp3');
      audio.play().catch(() => {});
    }

    if (session.isBreak) {
      // Break completed, start next work session
      const techniqueConfig = TIMER_TECHNIQUES[session.technique as keyof typeof TIMER_TECHNIQUES];
      
      toast({
        title: "Break Complete!",
        description: "Ready to get back to work?",
        duration: 5000
      });

      setCurrentSession({
        ...session,
        isBreak: false,
        timeRemaining: techniqueConfig.workDuration * 60,
        currentSession: session.currentSession + 1,
        isRunning: false
      });
    } else {
      // Work session completed
      const completedSessions = session.completedSessions + 1;
      const isLongBreak = completedSessions % session.sessionsUntilLongBreak === 0;
      const breakDuration = isLongBreak ? session.longBreakDuration : session.breakDuration;

      updateStats(session);
      
      toast({
        title: "Work Session Complete!",
        description: `Great job! Time for a ${isLongBreak ? 'long' : 'short'} break.`,
        duration: 5000
      });

      setCurrentSession({
        ...session,
        isBreak: true,
        timeRemaining: breakDuration * 60,
        completedSessions,
        isRunning: false
      });
    }
  };

  const updateStats = (session: TimerSession) => {
    const newStats = {
      ...stats,
      totalFocusTime: stats.totalFocusTime + session.workDuration,
      sessionsCompleted: stats.sessionsCompleted + 1,
      currentStreak: stats.currentStreak + 1,
      longestStreak: Math.max(stats.longestStreak, stats.currentStreak + 1),
      productivityScore: Math.min(100, stats.productivityScore + 2)
    };

    setStats(newStats);
    localStorage.setItem('procrastination_timer_stats', JSON.stringify(newStats));
  };

  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgress = (): number => {
    if (!currentSession) return 0;
    const totalTime = currentSession.isBreak 
      ? (currentSession.completedSessions % currentSession.sessionsUntilLongBreak === 0 
          ? currentSession.longBreakDuration * 60 
          : currentSession.breakDuration * 60)
      : currentSession.workDuration * 60;
    return ((totalTime - currentSession.timeRemaining) / totalTime) * 100;
  };

  if (isFloating && isMinimized) {
    return (
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <Card 
          className="w-64 cursor-pointer shadow-2xl border-2"
          onClick={() => setIsMinimized(false)}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${currentSession?.isRunning ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
                <span className="font-medium text-sm">
                  {currentSession ? formatTime(currentSession.timeRemaining) : 'Timer'}
                </span>
              </div>
              {currentSession && (
                <Badge variant={currentSession.isBreak ? "destructive" : "default"} className="text-xs">
                  {currentSession.isBreak ? 'Break' : 'Focus'}
                </Badge>
              )}
            </div>
            {currentSession && (
              <Progress value={getProgress()} className="mt-2 h-1" />
            )}
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <div className={isFloating ? "fixed bottom-6 right-6 z-50 w-96" : "w-full"}>
      <Card className="shadow-2xl border-2">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Timer className="text-blue-600" />
              Procrastination Timer
            </CardTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowStats(true)}
              >
                <BarChart3 size={16} />
              </Button>
              {isFloating && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsMinimized(true)}
                >
                  <Clock size={16} />
                </Button>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-6">
          {currentSession ? (
            <TimerActiveView
              session={currentSession}
              onPause={pauseTimer}
              onResume={resumeTimer}
              onReset={resetTimer}
              formatTime={formatTime}
              getProgress={getProgress}
            />
          ) : (
            <TimerSetupView
              technique={technique}
              setTechnique={setTechnique}
              taskInput={taskInput}
              setTaskInput={setTaskInput}
              taskCategory={taskCategory}
              setTaskCategory={setTaskCategory}
              onStart={startTimer}
            />
          )}

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4 pt-4 border-t">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.sessionsCompleted}</div>
              <div className="text-xs text-gray-600">Sessions Today</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{Math.floor(stats.totalFocusTime / 60)}h</div>
              <div className="text-xs text-gray-600">Focus Time</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Dialog */}
      <Dialog open={showStats} onOpenChange={setShowStats}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <TrendingUp className="text-blue-600" />
              Productivity Statistics
            </DialogTitle>
          </DialogHeader>
          <TimerStatsView stats={stats} />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function TimerActiveView({
  session,
  onPause,
  onResume,
  onReset,
  formatTime,
  getProgress
}: {
  session: TimerSession;
  onPause: () => void;
  onResume: () => void;
  onReset: () => void;
  formatTime: (seconds: number) => string;
  getProgress: () => number;
}) {
  return (
    <div className="space-y-6">
      {/* Current Task */}
      <div className="text-center">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">
          {session.isBreak ? 'Break Time' : 'Working On'}
        </h3>
        {!session.isBreak && (
          <p className="text-gray-600 text-sm bg-gray-50 p-3 rounded-lg">
            {session.task}
          </p>
        )}
        <Badge 
          className={`mt-2 ${TASK_CATEGORIES.find(c => c.value === session.category)?.color || 'bg-gray-100'}`}
        >
          {TASK_CATEGORIES.find(c => c.value === session.category)?.label}
        </Badge>
      </div>

      {/* Timer Display */}
      <div className="text-center">
        <motion.div 
          className={`text-6xl font-bold mb-4 ${
            session.isBreak ? 'text-green-600' : 'text-blue-600'
          }`}
          animate={{ scale: session.isRunning ? [1, 1.05, 1] : 1 }}
          transition={{ duration: 1, repeat: session.isRunning ? Infinity : 0 }}
        >
          {formatTime(session.timeRemaining)}
        </motion.div>
        <Progress 
          value={getProgress()} 
          className={`h-3 ${session.isBreak ? '[&>div]:bg-green-500' : '[&>div]:bg-blue-500'}`}
        />
        <div className="mt-2 flex items-center justify-center gap-4 text-sm text-gray-600">
          <span>Session {session.currentSession}</span>
          <span>•</span>
          <span>{session.completedSessions} completed</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex justify-center gap-3">
        {session.isRunning ? (
          <Button onClick={onPause} className="bg-orange-500 hover:bg-orange-600">
            <Pause size={16} className="mr-2" />
            Pause
          </Button>
        ) : (
          <Button onClick={onResume} className="bg-green-500 hover:bg-green-600">
            <Play size={16} className="mr-2" />
            Resume
          </Button>
        )}
        <Button onClick={onReset} variant="outline">
          <RotateCcw size={16} className="mr-2" />
          Reset
        </Button>
      </div>

      {/* Session Info */}
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          {React.createElement(TIMER_TECHNIQUES[session.technique as keyof typeof TIMER_TECHNIQUES].icon, {
            size: 16,
            className: "text-gray-600"
          })}
          <span className="font-medium text-sm">{TIMER_TECHNIQUES[session.technique as keyof typeof TIMER_TECHNIQUES].name}</span>
        </div>
        <div className="text-xs text-gray-600">
          {session.isBreak 
            ? `Break time! Next work session starts after this.`
            : `Focus time. Break coming up after ${formatTime((session.workDuration * 60) - session.timeRemaining)} more.`
          }
        </div>
      </div>
    </div>
  );
}

function TimerSetupView({
  technique,
  setTechnique,
  taskInput,
  setTaskInput,
  taskCategory,
  setTaskCategory,
  onStart
}: {
  technique: string;
  setTechnique: (technique: string) => void;
  taskInput: string;
  setTaskInput: (task: string) => void;
  taskCategory: string;
  setTaskCategory: (category: string) => void;
  onStart: () => void;
}) {
  return (
    <div className="space-y-6">
      {/* Technique Selection */}
      <div>
        <label className="text-sm font-medium mb-3 block">Choose Your Technique</label>
        <div className="grid grid-cols-2 gap-3">
          {Object.entries(TIMER_TECHNIQUES).map(([key, config]) => {
            const Icon = config.icon;
            return (
              <motion.button
                key={key}
                whileHover={{ scale: 1.02 }}
                onClick={() => setTechnique(key)}
                className={`p-4 rounded-lg border-2 text-left transition-all ${
                  technique === key
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${config.color} text-white`}>
                    <Icon size={16} />
                  </div>
                  <div>
                    <h3 className="font-medium text-sm">{config.name}</h3>
                    <p className="text-xs text-gray-600">{config.description}</p>
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Task Input */}
      <div>
        <label className="text-sm font-medium mb-2 block">What are you working on?</label>
        <Textarea
          placeholder="Describe your task or goal..."
          value={taskInput}
          onChange={(e) => setTaskInput(e.target.value)}
          className="mb-3"
        />
        <Select value={taskCategory} onValueChange={setTaskCategory}>
          <SelectTrigger>
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            {TASK_CATEGORIES.map((category) => (
              <SelectItem key={category.value} value={category.value}>
                {category.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Start Button */}
      <Button
        onClick={onStart}
        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        size="lg"
        disabled={!taskInput.trim()}
      >
        <Play size={20} className="mr-2" />
        Start Focus Session
      </Button>
    </div>
  );
}

function TimerStatsView({ stats }: { stats: TimerStats }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{stats.sessionsCompleted}</div>
            <div className="text-sm text-gray-600">Sessions Completed</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{Math.floor(stats.totalFocusTime / 60)}h</div>
            <div className="text-sm text-gray-600">Total Focus Time</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold">{stats.longestStreak}</div>
            <div className="text-sm text-gray-600">Longest Streak</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Productivity Score</span>
            <span className="text-lg font-bold text-green-600">{stats.productivityScore}%</span>
          </div>
          <Progress value={stats.productivityScore} className="h-2" />
          <p className="text-xs text-gray-600 mt-2">
            Based on consistency, session completion, and focus time
          </p>
        </CardContent>
      </Card>
    </div>
  );
}