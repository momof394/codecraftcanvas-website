import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, RefreshCw, PartyPopper, Headphones } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { getRandomAffirmation } from "@/lib/affirmations";
import { useToast } from "@/hooks/use-toast";

const moodEmojis = [
  { value: 1, emoji: "😫", label: "Struggling" },
  { value: 2, emoji: "😔", label: "Low" },
  { value: 3, emoji: "😐", label: "Neutral" },
  { value: 4, emoji: "🙂", label: "Good" },
  { value: 5, emoji: "😊", label: "Great" }
];

export default function CheckInSection() {
  const [selectedMood, setSelectedMood] = useState<number>(3);
  const [currentAffirmation, setCurrentAffirmation] = useState(getRandomAffirmation());
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: moodEntries } = useQuery({
    queryKey: ["/api/mood"],
  });

  const createMoodEntryMutation = useMutation({
    mutationFn: async (data: { mood: number; notes?: string }) => {
      const response = await apiRequest("POST", "/api/mood", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood"] });
      toast({
        description: "Mood logged! Thank you for checking in with yourself 💚",
      });
    },
  });

  const handleMoodSelect = (mood: number) => {
    setSelectedMood(mood);
    createMoodEntryMutation.mutate({ mood });
  };

  const getNewAffirmation = () => {
    setCurrentAffirmation(getRandomAffirmation());
  };

  const celebrate = () => {
    toast({
      title: "🎉 Celebrating Your Wins!",
      description: "Every accomplishment, big or small, deserves recognition. You're doing amazing!",
    });
  };

  const needSupport = () => {
    toast({
      title: "💙 You're Not Alone",
      description: "It's okay to need support. Consider reaching out to a friend, counselor, or crisis hotline.",
    });
  };

  return (
    <div className="bg-white rounded-3xl p-8 shadow-lg border border-[hsl(142,28%,59%)]/10">
      <div className="flex items-center mb-6">
        <div className="w-12 h-12 rounded-full gradient-warm flex items-center justify-center mr-4">
          <Heart className="text-[hsl(0,0%,36%)]" size={20} />
        </div>
        <h2 className="text-2xl font-medium text-[hsl(0,0%,36%)]" style={{ fontFamily: 'Poppins' }}>
          Daily Check-in
        </h2>
      </div>
      
      {/* Mood Check */}
      <div className="mb-6">
        <h3 className="text-lg font-medium text-[hsl(0,0%,36%)] mb-3">How are you feeling today?</h3>
        <div className="grid grid-cols-5 gap-2">
          {moodEmojis.map((mood) => (
            <motion.button
              key={mood.value}
              className={`p-3 rounded-xl text-2xl transition-colors duration-300 ${
                selectedMood === mood.value 
                  ? 'bg-[hsl(142,28%,59%)]/10 ring-2 ring-[hsl(142,28%,59%)]/30' 
                  : 'hover:bg-[hsl(142,28%,59%)]/10'
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => handleMoodSelect(mood.value)}
              title={mood.label}
            >
              {mood.emoji}
            </motion.button>
          ))}
        </div>
      </div>
      
      {/* Today's Affirmation */}
      <motion.div 
        className="p-6 rounded-2xl gradient-warm border border-[hsl(39,37%,69%)]/20 mb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h4 className="font-medium text-[hsl(0,0%,36%)] mb-3 text-center">Today's Gentle Reminder</h4>
        <motion.blockquote 
          className="text-center text-[hsl(0,0%,36%)] italic"
          key={currentAffirmation}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          "{currentAffirmation}"
        </motion.blockquote>
        <div className="text-center mt-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={getNewAffirmation}
            className="text-[hsl(142,28%,59%)] hover:text-[hsl(142,28%,59%)]/80 transition-colors text-sm"
          >
            <RefreshCw size={14} className="mr-1" />
            New reminder
          </Button>
        </div>
      </motion.div>
      
      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button
          onClick={celebrate}
          className="p-3 bg-[hsl(162,40%,72%)]/10 text-[hsl(162,40%,72%)] rounded-xl hover:bg-[hsl(162,40%,72%)]/20 transition-colors duration-300 text-sm"
          variant="ghost"
        >
          <PartyPopper size={16} className="mr-2" />
          Celebrate wins
        </Button>
        <Button
          onClick={needSupport}
          className="p-3 bg-[hsl(198,71%,73%)]/10 text-[hsl(198,71%,73%)] rounded-xl hover:bg-[hsl(198,71%,73%)]/20 transition-colors duration-300 text-sm"
          variant="ghost"
        >
          <Headphones size={16} className="mr-2" />
          Need support
        </Button>
      </div>
    </div>
  );
}