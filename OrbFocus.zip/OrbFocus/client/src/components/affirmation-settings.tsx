import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { 
  Heart, 
  RotateCcw, 
  Calendar, 
  Sparkles,
  Info,
  Zap
} from "lucide-react";
import { useDailyAffirmation } from "@/hooks/use-daily-affirmation";

export default function AffirmationSettings() {
  const { 
    isEnabled, 
    enable, 
    disable, 
    reset, 
    getStreak 
  } = useDailyAffirmation();

  const currentStreak = getStreak();

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-400 rounded-lg flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">Daily Affirmations</CardTitle>
              <CardDescription>
                Start your creative sessions with positive intention
              </CardDescription>
            </div>
          </div>
          <Badge variant={isEnabled ? "default" : "secondary"}>
            {isEnabled ? "Active" : "Disabled"}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Main Toggle */}
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <Label className="text-sm font-medium">Enable Daily Affirmations</Label>
            <p className="text-xs text-muted-foreground">
              Show positive affirmations when starting your creative sessions
            </p>
          </div>
          <Switch
            checked={isEnabled}
            onCheckedChange={(checked) => checked ? enable() : disable()}
          />
        </div>

        {isEnabled && (
          <>
            <Separator />

            {/* Streak Counter */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium flex items-center">
                <Zap className="w-4 h-4 mr-2" />
                Inspiration Streak
              </h4>
              
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-bold text-purple-700 dark:text-purple-300">
                      {currentStreak}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {currentStreak === 1 ? 'day' : 'days'} in a row
                    </div>
                  </div>
                  <Sparkles className="w-8 h-8 text-purple-400" />
                </div>
                
                {currentStreak > 0 && (
                  <p className="text-xs text-purple-600 dark:text-purple-400 mt-2">
                    {currentStreak >= 7 
                      ? "Amazing! You're building a strong creative habit!" 
                      : currentStreak >= 3 
                      ? "Great job! Keep the momentum going!" 
                      : "Nice start! Building positive habits takes time."}
                  </p>
                )}
              </div>
            </div>

            <Separator />

            {/* Information */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium flex items-center">
                <Info className="w-4 h-4 mr-2" />
                How it Works
              </h4>
              
              <div className="text-xs text-muted-foreground space-y-2">
                <p>
                  • A new affirmation appears each day when you first visit the platform
                </p>
                <p>
                  • Affirmations are designed to inspire creativity and boost confidence
                </p>
                <p>
                  • You can dismiss for the day or continue to your workspace
                </p>
                <p>
                  • Building a daily practice helps establish positive creative habits
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={reset}
                className="flex-1"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset Settings
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}