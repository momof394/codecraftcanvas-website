import AITherapyChat from "@/components/ai-therapy-chat";

export default function TherapySession() {
  return <AITherapyChat />;
}