import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Brain, 
  BookOpen, 
  Lightbulb, 
  Target, 
  Heart,
  Calendar,
  Plus,
  Edit,
  Trash2,
  Search,
  Filter,
  Save,
  Download,
  Settings,
  Mic,
  Volume2
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import VoiceEmotionDetector from "@/components/voice-emotion-detector";
import AIAssistant from "@/components/ai-assistant";

// Cognitive journaling types
interface JournalEntry {
  id: string;
  title: string;
  content: string;
  type: 'reflection' | 'gratitude' | 'goals' | 'insights' | 'emotions' | 'habits';
  mood: number; // 1-5 scale
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

interface JournalTemplate {
  id: string;
  name: string;
  type: string;
  prompts: string[];
  description: string;
  category: string;
}

export default function CognitiveJournalPage() {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [newEntry, setNewEntry] = useState({
    title: '',
    content: '',
    type: 'reflection' as const,
    mood: 3,
    tags: [] as string[]
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showVoiceAnalysis, setShowVoiceAnalysis] = useState(false);
  const [voiceEmotions, setVoiceEmotions] = useState<any[]>([]);

  // Fetch journal entries
  const { data: entries = [] } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal-entries"],
  });

  // Fetch cognitive journal templates
  const { data: templates = [] } = useQuery<JournalTemplate[]>({
    queryKey: ["/api/journal-templates"],
  });

  // Create new journal entry
  const createEntryMutation = useMutation({
    mutationFn: async (entry: Partial<JournalEntry>) => {
      const response = await fetch('/api/journal-entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(entry)
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
      setNewEntry({ title: '', content: '', type: 'reflection', mood: 3, tags: [] });
      setIsEditing(false);
    }
  });

  // Cognitive journaling prompts
  const cognitivePrompts = {
    reflection: [
      "What did I learn about myself today?",
      "What thoughts or beliefs did I challenge?",
      "How did I respond to difficult situations?",
      "What patterns am I noticing in my thinking?"
    ],
    gratitude: [
      "What am I most grateful for right now?",
      "Who made a positive impact on my day?",
      "What small moments brought me joy?",
      "What opportunities am I appreciating?"
    ],
    goals: [
      "What progress did I make toward my goals?",
      "What obstacles did I overcome?",
      "What do I want to focus on tomorrow?",
      "How can I better align my actions with my values?"
    ],
    insights: [
      "What new perspective did I gain today?",
      "What assumption was challenged?",
      "What connection did I make between ideas?",
      "What would I do differently next time?"
    ],
    emotions: [
      "What emotions did I experience most today?",
      "How did I process difficult feelings?",
      "What triggered strong emotional responses?",
      "What helped me regulate my emotions?"
    ],
    habits: [
      "What positive habits did I maintain today?",
      "What habits would I like to develop?",
      "What environmental changes would support my goals?",
      "How can I make positive choices easier tomorrow?"
    ]
  };

  const handleSaveEntry = () => {
    if (newEntry.title && newEntry.content) {
      createEntryMutation.mutate(newEntry);
    }
  };

  const handleTemplateSelect = (template: JournalTemplate) => {
    setNewEntry({
      ...newEntry,
      title: template.name,
      content: template.prompts.join('\n\n'),
      type: template.type as any
    });
    setIsEditing(true);
  };

  const filteredEntries = entries.filter(entry => {
    const matchesType = selectedType === 'all' || entry.type === selectedType;
    const matchesSearch = entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-purple-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-purple-900">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <Brain className="w-8 h-8 text-purple-600" />
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Cognitive Journaling
            </h1>
          </div>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl">
            Enhance self-awareness and cognitive growth through structured reflection, 
            gratitude practice, and insights documentation.
          </p>
        </div>

        <Tabs defaultValue="write" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="write" className="flex items-center space-x-2">
              <Edit className="w-4 h-4" />
              <span>Write</span>
            </TabsTrigger>
            <TabsTrigger value="voice" className="flex items-center space-x-2">
              <Mic className="w-4 h-4" />
              <span>Voice</span>
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center space-x-2">
              <Brain className="w-4 h-4" />
              <span>AI Chat</span>
            </TabsTrigger>
            <TabsTrigger value="entries" className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span>Entries</span>
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center space-x-2">
              <Lightbulb className="w-4 h-4" />
              <span>Templates</span>
            </TabsTrigger>
            <TabsTrigger value="insights" className="flex items-center space-x-2">
              <Target className="w-4 h-4" />
              <span>Insights</span>
            </TabsTrigger>
          </TabsList>

          {/* Write Tab */}
          <TabsContent value="write" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Edit className="w-5 h-5" />
                  <span>New Journal Entry</span>
                </CardTitle>
                <CardDescription>
                  Reflect on your thoughts, experiences, and insights
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Entry Title</label>
                    <Input 
                      placeholder="Give your entry a meaningful title..."
                      value={newEntry.title}
                      onChange={(e) => setNewEntry({...newEntry, title: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Entry Type</label>
                    <Select value={newEntry.type} onValueChange={(value: any) => setNewEntry({...newEntry, type: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="reflection">Daily Reflection</SelectItem>
                        <SelectItem value="gratitude">Gratitude Practice</SelectItem>
                        <SelectItem value="goals">Goals & Progress</SelectItem>
                        <SelectItem value="insights">Insights & Learning</SelectItem>
                        <SelectItem value="emotions">Emotional Processing</SelectItem>
                        <SelectItem value="habits">Habit Tracking</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Current Mood (1-5)</label>
                  <div className="flex space-x-2">
                    {[1, 2, 3, 4, 5].map(mood => (
                      <Button
                        key={mood}
                        variant={newEntry.mood === mood ? "default" : "outline"}
                        size="sm"
                        onClick={() => setNewEntry({...newEntry, mood})}
                        className="w-12 h-12 rounded-full"
                      >
                        {mood}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Cognitive prompts */}
                <div>
                  <label className="block text-sm font-medium mb-2">Guided Prompts</label>
                  <div className="grid md:grid-cols-2 gap-2">
                    {cognitivePrompts[newEntry.type]?.map((prompt, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        size="sm"
                        className="text-left h-auto p-3 justify-start"
                        onClick={() => setNewEntry({
                          ...newEntry, 
                          content: newEntry.content + (newEntry.content ? '\n\n' : '') + prompt + '\n'
                        })}
                      >
                        <Lightbulb className="w-4 h-4 mr-2 flex-shrink-0" />
                        <span className="text-sm">{prompt}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Journal Content</label>
                  <Textarea 
                    placeholder="Begin writing your thoughts, reflections, or responses to prompts..."
                    value={newEntry.content}
                    onChange={(e) => setNewEntry({...newEntry, content: e.target.value})}
                    rows={10}
                    className="min-h-[200px]"
                  />
                </div>

                <div className="flex space-x-3">
                  <Button onClick={handleSaveEntry} disabled={createEntryMutation.isPending}>
                    <Save className="w-4 h-4 mr-2" />
                    {createEntryMutation.isPending ? 'Saving...' : 'Save Entry'}
                  </Button>
                  <Button variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Export as PDF
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Voice Analysis Tab */}
          <TabsContent value="voice" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Volume2 className="w-5 h-5 text-purple-600" />
                  <span>Voice Emotion Journaling</span>
                </CardTitle>
                <CardDescription>
                  Speak your thoughts while the system analyzes your emotional state from voice patterns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <VoiceEmotionDetector 
                  isJournalMode={true}
                  onEmotionDetected={(analysis) => {
                    setVoiceEmotions(prev => [...prev, analysis]);
                    // Auto-update mood based on voice analysis
                    const emotionToMood: Record<string, number> = {
                      'happy': 5,
                      'excited': 5,
                      'calm': 4,
                      'neutral': 3,
                      'stressed': 2,
                      'sad': 1,
                      'angry': 1
                    };
                    const detectedMood = emotionToMood[analysis.emotion] || 3;
                    setNewEntry(prev => ({...prev, mood: detectedMood}));
                  }}
                  onTranscriptUpdate={(transcript) => {
                    setNewEntry(prev => ({
                      ...prev, 
                      content: transcript,
                      title: prev.title || `Voice Journal - ${new Date().toLocaleDateString()}`
                    }));
                  }}
                />
                
                {voiceEmotions.length > 0 && (
                  <div className="mt-6 space-y-4">
                    <h3 className="font-semibold">Detected Emotional Journey</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {voiceEmotions.slice(-8).map((emotion, index) => (
                        <div key={index} className="text-center p-3 bg-muted rounded-lg">
                          <div className="font-medium text-sm text-purple-600">
                            {emotion.emotion}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {Math.round(emotion.confidence * 100)}% confidence
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(emotion.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <Button 
                      onClick={() => {
                        // Create journal entry with voice analysis data
                        const emotionSummary = voiceEmotions.reduce((acc, curr) => {
                          acc[curr.emotion] = (acc[curr.emotion] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>);
                        
                        const dominantEmotion = Object.entries(emotionSummary)
                          .sort(([,a], [,b]) => (b as number) - (a as number))[0];
                        
                        setNewEntry(prev => ({
                          ...prev,
                          type: 'emotions' as const,
                          content: prev.content + `\n\n--- Voice Analysis Summary ---\nDominant Emotion: ${dominantEmotion?.[0] || 'neutral'}\nEmotional Journey: ${voiceEmotions.map(e => e.emotion).join(' → ')}\nTotal Analysis Points: ${voiceEmotions.length}`
                        }));
                      }}
                      className="w-full"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Voice Journal with Emotion Analysis
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI Assistant Tab */}
          <TabsContent value="ai" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="w-5 h-5 text-purple-600" />
                  <span>AI Creative Companion</span>
                </CardTitle>
                <CardDescription>
                  Chat with your AI companion for creative support, emotional guidance, and thoughtful conversations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AIAssistant />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Entries Tab */}
          <TabsContent value="entries" className="space-y-6">
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input 
                    placeholder="Search your journal entries..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-48">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="reflection">Reflections</SelectItem>
                  <SelectItem value="gratitude">Gratitude</SelectItem>
                  <SelectItem value="goals">Goals</SelectItem>
                  <SelectItem value="insights">Insights</SelectItem>
                  <SelectItem value="emotions">Emotions</SelectItem>
                  <SelectItem value="habits">Habits</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-4">
              {filteredEntries.map((entry) => (
                <Card key={entry.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-2">{entry.title}</h3>
                        <div className="flex items-center space-x-4 mb-3">
                          <Badge variant="secondary">{entry.type}</Badge>
                          <div className="flex items-center space-x-1">
                            <Heart className="w-4 h-4 text-red-500" />
                            <span className="text-sm">Mood: {entry.mood}/5</span>
                          </div>
                          <span className="text-sm text-gray-500">
                            {new Date(entry.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 line-clamp-3">
                      {entry.content}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.entries(cognitivePrompts).map(([type, prompts]) => (
                <Card key={type} className="cursor-pointer hover:shadow-lg transition-shadow"
                      onClick={() => handleTemplateSelect({
                        id: type,
                        name: `${type.charAt(0).toUpperCase() + type.slice(1)} Journal`,
                        type,
                        prompts,
                        description: `Guided prompts for ${type} practice`,
                        category: 'cognitive'
                      })}>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Brain className="w-5 h-5 text-purple-600" />
                      <span>{type.charAt(0).toUpperCase() + type.slice(1)} Journal</span>
                    </CardTitle>
                    <CardDescription>
                      {prompts.length} guided prompts for {type} practice
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {prompts.slice(0, 2).map((prompt, index) => (
                        <p key={index} className="text-sm text-gray-600 dark:text-gray-300">
                          • {prompt}
                        </p>
                      ))}
                      {prompts.length > 2 && (
                        <p className="text-sm text-gray-500">
                          +{prompts.length - 2} more prompts...
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <span>Journal Streak</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600 mb-2">7 days</div>
                  <p className="text-sm text-gray-600">Keep up the great work!</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Heart className="w-5 h-5 text-red-600" />
                    <span>Average Mood</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-red-600 mb-2">3.8/5</div>
                  <p className="text-sm text-gray-600">Trending upward this week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="w-5 h-5 text-green-600" />
                    <span>Growth Areas</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Emotional awareness</span>
                      <span className="text-sm font-medium">85%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Goal clarity</span>
                      <span className="text-sm font-medium">72%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}