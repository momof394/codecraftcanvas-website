import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Image as ImageIcon, 
  Star, 
  Filter,
  Shapes,
  Palette,
  Type,
  Upload,
  Download,
  Heart,
  Plus,
  Grid3X3,
  List
} from "lucide-react";

export default function AssetsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [viewMode, setViewMode] = useState("grid");

  const { data: assets = [], isLoading } = useQuery({
    queryKey: ["/api/assets"],
  });

  const assetTypes = [
    { id: "all", label: "All Assets", icon: ImageIcon },
    { id: "image", label: "Images", icon: ImageIcon },
    { id: "shape", label: "Shapes", icon: Shapes },
    { id: "icon", label: "Icons", icon: Palette },
    { id: "sticker", label: "Stickers", icon: Star },
  ];

  const filteredAssets = assets.filter((asset: any) => {
    const matchesSearch = asset.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === "all" || asset.type === selectedType;
    return matchesSearch && matchesType;
  });

  const handleDownloadAsset = (assetId: string) => {
    // This would download or add the asset to the user's project
    console.log("Download asset:", assetId);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Palette className="w-12 h-12 text-purple-600 mx-auto mb-4 animate-spin" />
          <p className="text-gray-600 dark:text-gray-300">Loading assets...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Design Assets
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Royalty-free images, shapes, icons, and stickers for your creative projects.
            All assets are cleared for commercial use.
          </p>
        </div>

        {/* Search and Controls */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search assets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              
              <div className="flex border rounded-md">
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                  className="rounded-r-none"
                >
                  <Grid3X3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                  className="rounded-l-none"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
              
              <Button>
                <Upload className="w-4 h-4 mr-2" />
                Upload Asset
              </Button>
            </div>
          </div>
        </div>

        {/* Asset Type Tabs */}
        <Tabs value={selectedType} onValueChange={setSelectedType} className="mb-8">
          <TabsList className="grid w-full grid-cols-5">
            {assetTypes.map((type) => {
              const Icon = type.icon;
              return (
                <TabsTrigger key={type.id} value={type.id} className="flex items-center">
                  <Icon className="w-4 h-4 mr-2" />
                  <span className="hidden sm:inline">{type.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>
        </Tabs>

        {/* Assets Grid/List */}
        {viewMode === "grid" ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {filteredAssets.map((asset: any) => (
              <Card key={asset.id} className="group hover:shadow-lg transition-all duration-200">
                <CardContent className="p-0">
                  {/* Asset Preview */}
                  <div className="aspect-square bg-gray-100 dark:bg-gray-800 relative overflow-hidden rounded-t-lg">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <ImageIcon className="w-8 h-8 text-gray-400" />
                    </div>
                    
                    {/* Action Overlay */}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                      <div className="flex space-x-1">
                        <Button variant="secondary" size="sm" className="w-8 h-8 p-0">
                          <Download className="w-3 h-3" />
                        </Button>
                        <Button variant="secondary" size="sm" className="w-8 h-8 p-0">
                          <Heart className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>

                    {/* Premium Badge */}
                    {asset.isPremium && (
                      <div className="absolute top-1 right-1">
                        <Badge className="bg-yellow-500 text-white text-xs">
                          Pro
                        </Badge>
                      </div>
                    )}
                  </div>

                  {/* Asset Info */}
                  <div className="p-2">
                    <p className="text-xs font-medium text-gray-900 dark:text-white truncate">
                      {asset.name}
                    </p>
                    <div className="flex items-center justify-between mt-1">
                      <Badge variant="secondary" className="text-xs">
                        {asset.type}
                      </Badge>
                      <Button size="sm" className="h-6 text-xs px-2">
                        Use
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredAssets.map((asset: any) => (
              <Card key={asset.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center flex-shrink-0">
                      <ImageIcon className="w-8 h-8 text-gray-400" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 dark:text-white truncate">
                        {asset.name}
                      </h3>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {asset.type}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {asset.category}
                        </Badge>
                        {asset.isPremium && (
                          <Badge className="text-xs">
                            <Star className="w-3 h-3 mr-1" />
                            Pro
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                        License: {asset.license}
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <Heart className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button size="sm">
                        Use Asset
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {filteredAssets.length === 0 && (
          <div className="text-center py-12">
            <ImageIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              No assets found
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Try adjusting your search or type filter, or upload your own assets.
            </p>
            <Button>
              <Upload className="w-4 h-4 mr-2" />
              Upload Asset
            </Button>
          </div>
        )}

        {/* Asset Statistics */}
        <div className="mt-16 bg-gray-50 dark:bg-gray-800/50 rounded-lg p-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                {assets.length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Total Assets
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                {assets.filter((a: any) => a.type === 'image').length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Images
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
                {assets.filter((a: any) => a.type === 'shape').length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Shapes
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-orange-600 dark:text-orange-400 mb-2">
                {assets.filter((a: any) => !a.isPremium).length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Free Assets
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}