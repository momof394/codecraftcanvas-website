import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Home, ArrowLeft, Palette } from "lucide-react";

export default function NotFoundPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader>
          <div className="mx-auto mb-4">
            <Palette className="w-16 h-16 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
            <div className="text-6xl font-bold text-purple-600 dark:text-purple-400">
              404
            </div>
          </div>
          <CardTitle className="text-2xl">Page Not Found</CardTitle>
          <CardDescription>
            The page you're looking for doesn't exist or has been moved. Let's get you back to creating!
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Button asChild className="w-full">
              <Link href="/">
                <Home className="w-4 h-4 mr-2" />
                Go Home
              </Link>
            </Button>
            <Button variant="outline" asChild className="w-full">
              <Link href="/editor">
                <Palette className="w-4 h-4 mr-2" />
                Start Creating
              </Link>
            </Button>
            <Button variant="ghost" asChild className="w-full">
              <a href="javascript:history.back()">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Go Back
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}