import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Download, 
  FileImage, 
  File, 
  Search,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  Loader,
  Trash2,
  Share,
  Copy,
  Eye
} from "lucide-react";

export default function ExportsPage() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: exports = [], isLoading } = useQuery({
    queryKey: ["/api/exports"],
  });

  const filteredExports = exports.filter((exportItem: any) => 
    exportItem.projectTitle?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getFormatIcon = (format: string) => {
    switch (format.toLowerCase()) {
      case 'pdf':
        return File;
      case 'png':
      case 'jpeg':
      case 'jpg':
        return FileImage;
      default:
        return File;
    }
  };

  const getFormatColor = (format: string) => {
    switch (format.toLowerCase()) {
      case 'pdf':
        return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
      case 'png':
        return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
      case 'jpeg':
      case 'jpg':
        return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
      default:
        return 'bg-gray-100 text-gray-700 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return CheckCircle;
      case 'processing':
        return Loader;
      case 'failed':
        return AlertCircle;
      default:
        return Clock;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-600 dark:text-green-400';
      case 'processing':
        return 'text-blue-600 dark:text-blue-400';
      case 'failed':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Download className="w-12 h-12 text-purple-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600 dark:text-gray-300">Loading exports...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Export History
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Download and manage your exported projects. All exports are available 
            for 30 days after creation.
          </p>
        </div>

        {/* Search and Actions */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search exports..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                Clear All
              </Button>
            </div>
          </div>
        </div>

        {/* Export Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                {exports.length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Total Exports
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-green-600 dark:text-green-400 mb-2">
                {exports.filter((e: any) => e.status === 'completed').length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Completed
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                {exports.filter((e: any) => e.status === 'processing').length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Processing
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-red-600 dark:text-red-400 mb-2">
                {exports.filter((e: any) => e.status === 'failed').length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Failed
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Exports List */}
        <Tabs defaultValue="all" className="mb-8">
          <TabsList>
            <TabsTrigger value="all">All Exports</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="processing">Processing</TabsTrigger>
            <TabsTrigger value="failed">Failed</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {filteredExports.length > 0 ? (
              filteredExports.map((exportItem: any) => {
                const FormatIcon = getFormatIcon(exportItem.format);
                const StatusIcon = getStatusIcon(exportItem.status || 'completed');
                
                return (
                  <Card key={exportItem.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4">
                        {/* Format Icon */}
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getFormatColor(exportItem.format)}`}>
                          <FormatIcon className="w-6 h-6" />
                        </div>
                        
                        {/* Export Details */}
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-gray-900 dark:text-white truncate">
                            {exportItem.projectTitle || `Project Export`}
                          </h3>
                          <div className="flex items-center space-x-4 mt-1">
                            <div className="flex items-center space-x-1">
                              <StatusIcon className={`w-4 h-4 ${getStatusColor(exportItem.status || 'completed')}`} />
                              <span className={`text-sm capitalize ${getStatusColor(exportItem.status || 'completed')}`}>
                                {exportItem.status || 'completed'}
                              </span>
                            </div>
                            <div className="flex items-center space-x-1 text-sm text-gray-500">
                              <Calendar className="w-4 h-4" />
                              <span>{new Date(exportItem.createdAt).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center space-x-1 text-sm text-gray-500">
                              <Clock className="w-4 h-4" />
                              <span>{new Date(exportItem.createdAt).toLocaleTimeString()}</span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge variant="secondary" className="text-xs">
                              {exportItem.format.toUpperCase()}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {exportItem.quality || 'High'} Quality
                            </Badge>
                          </div>
                        </div>
                        
                        {/* Actions */}
                        <div className="flex items-center space-x-2">
                          {(exportItem.status || 'completed') === 'completed' && (
                            <>
                              <Button variant="outline" size="sm">
                                <Eye className="w-4 h-4 mr-1" />
                                Preview
                              </Button>
                              <Button variant="outline" size="sm">
                                <Share className="w-4 h-4 mr-1" />
                                Share
                              </Button>
                              <Button size="sm">
                                <Download className="w-4 h-4 mr-1" />
                                Download
                              </Button>
                            </>
                          )}
                          
                          {(exportItem.status || 'completed') === 'processing' && (
                            <Button variant="outline" size="sm" disabled>
                              <Loader className="w-4 h-4 mr-1 animate-spin" />
                              Processing...
                            </Button>
                          )}
                          
                          {(exportItem.status || 'completed') === 'failed' && (
                            <Button variant="outline" size="sm">
                              Retry Export
                            </Button>
                          )}
                          
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <Card className="border-dashed border-2">
                <CardContent className="p-12 text-center">
                  <Download className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    No exports yet
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    Export your first project to see it here. Choose from PDF, PNG, or JPEG formats.
                  </p>
                  <Button asChild>
                    <a href="/editor">Start Creating</a>
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Export Guidelines */}
        <div className="mt-16">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Download className="w-5 h-5 mr-2" />
                Export Guidelines
              </CardTitle>
              <CardDescription>
                Important information about your exports and file management
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-3">
                    File Formats
                  </h4>
                  <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                    <li className="flex items-center">
                      <File className="w-4 h-4 mr-2 text-red-600" />
                      <strong>PDF:</strong> Best for print and professional documents
                    </li>
                    <li className="flex items-center">
                      <FileImage className="w-4 h-4 mr-2 text-blue-600" />
                      <strong>PNG:</strong> High quality with transparency support
                    </li>
                    <li className="flex items-center">
                      <FileImage className="w-4 h-4 mr-2 text-green-600" />
                      <strong>JPEG:</strong> Smaller file size, perfect for web
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-3">
                    Storage Policy
                  </h4>
                  <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                    <li>• Files are stored securely for 30 days</li>
                    <li>• Download multiple times during this period</li>
                    <li>• High-quality exports available immediately</li>
                    <li>• Share links expire after 7 days</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}