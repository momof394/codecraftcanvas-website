import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  Palette, 
  FileImage, 
  Download, 
  Zap,
  Brush,
  Layout,
  Image as ImageIcon,
  Plus,
  Clock,
  Star,
  Circle,
  Code,
  Brain,
  Mic,
  MessageCircle,
  Lightbulb,
  Target
} from "lucide-react";
import type { Template, Project } from "../../../shared/schema";
import { HomePageAd } from "@/components/adsense-banner";

export default function HomePage() {
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: templates = [] } = useQuery<Template[]>({
    queryKey: ["/api/templates"],
  });

  const recentTemplates = templates.slice(0, 3);
  const recentProjects = projects.slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-12 md:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold text-foreground mb-6">
              Create. Design. Succeed.
              <span className="block text-purple-600">
                Your Complete Digital Studio
              </span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              The ultimate digital creation platform combining professional design tools, productivity features, 
              and creative expression. Design digital products, create stunning visuals, manage projects, and export everything seamlessly.
            </p>
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Badge variant="secondary" className="text-sm">
                <Palette className="w-4 h-4 mr-1" />
                Design Studio
              </Badge>
              <Badge variant="secondary" className="text-sm">
                <Target className="w-4 h-4 mr-1" />
                Productivity Tools
              </Badge>
              <Badge variant="secondary" className="text-sm">
                <Download className="w-4 h-4 mr-1" />
                Export Tools
              </Badge>
              <Badge variant="secondary" className="text-sm">
                <Lightbulb className="w-4 h-4 mr-1" />
                AI-Powered
              </Badge>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button size="lg" asChild className="text-lg px-8 py-6 bg-purple-600 hover:bg-purple-700 text-white border-purple-600">
              <Link href="/editor">
                <Palette className="w-5 h-5 mr-2" />
                Design Studio
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild className="text-lg px-8 py-6 border-purple-600 text-purple-600 hover:bg-purple-50 dark:hover:bg-purple-900/20">
              <Link href="/journal">
                <FileImage className="w-5 h-5 mr-2" />
                Project Hub
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild className="text-lg px-8 py-6 border-green-600 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20">
              <Link href="/templates">
                <FileImage className="w-5 h-5 mr-2" />
                Templates
              </Link>
            </Button>
          </div>

          {/* Orb Canvas Preview */}
          <div className="mb-16">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">
                Orb Canvas Studio
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Create dynamic visual experiences with our innovative orb-focused design environment. 
                Blend creativity, code, and visual design in one powerful platform for modern digital creation.
              </p>
            </div>
            
            <div className="max-w-4xl mx-auto">
              <div className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 rounded-xl p-8">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div className="space-y-6">
                    <div className="relative w-64 h-64 mx-auto">
                      {/* Interactive Orb Preview */}
                      <div className="absolute inset-0 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full animate-pulse opacity-80"></div>
                      <div className="absolute inset-4 bg-gradient-to-br from-purple-300 to-purple-500 rounded-full flex items-center justify-center">
                        <div className="text-white text-center">
                          <Circle className="w-8 h-8 mx-auto mb-2" />
                          <span className="text-sm font-medium">Design Core</span>
                        </div>
                      </div>
                      {/* Code Elements floating around */}
                      <div className="absolute top-0 left-12 w-16 h-8 bg-blue-200 rounded text-xs flex items-center justify-center animate-bounce" style={{animationDelay: '0.5s'}}>
                        Function
                      </div>
                      <div className="absolute bottom-8 right-0 w-16 h-8 bg-green-200 rounded text-xs flex items-center justify-center animate-bounce" style={{animationDelay: '1s'}}>
                        Variable
                      </div>
                      <div className="absolute top-20 right-12 w-16 h-8 bg-yellow-200 rounded text-xs flex items-center justify-center animate-bounce" style={{animationDelay: '1.5s'}}>
                        Class
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Orb Canvas Features</h3>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <Circle className="w-5 h-5 text-purple-500" />
                        <span className="text-sm">Visual design programming</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Code className="w-5 h-5 text-blue-500" />
                        <span className="text-sm">Interactive code canvas</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Brain className="w-5 h-5 text-green-500" />
                        <span className="text-sm">AI-powered collaboration</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Mic className="w-5 h-5 text-pink-500" />
                        <span className="text-sm">Voice-controlled development</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Zap className="w-5 h-5 text-yellow-500" />
                        <span className="text-sm">Real-time design feedback</span>
                      </div>
                    </div>
                    
                    <div className="flex space-x-3 mt-6">
                      <Button asChild className="flex-1">
                        <Link href="/orb-canvas">
                          <Circle className="w-4 h-4 mr-2" />
                          Try Orb Canvas
                        </Link>
                      </Button>
                      <Button asChild variant="outline" className="flex-1">
                        <Link href="/journal">
                          <Lightbulb className="w-4 h-4 mr-2" />
                          AI Assistant
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* AdSense Home Page Ad */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
            <HomePageAd />
          </div>

          {/* Unified Platform Features */}
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Everything You Need in One Platform
            </h2>
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Seamlessly switch between creative design work and productivity management. 
              Track your projects, organize your ideas, and create stunning digital products - all in one unified workspace.
            </p>
          </div>

          {/* Feature Categories */}
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            {/* Design Studio Features */}
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Palette className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">Design Studio</h3>
                <p className="text-muted-foreground">Professional-grade creative tools for digital product creation</p>
              </div>
              
              <div className="grid gap-4">
                <Card className="border-2 hover:border-purple-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                        <Brush className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Drawing Tools</h4>
                        <p className="text-sm text-muted-foreground">Procreate-style brushes and layers</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 hover:border-purple-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                        <Layout className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Drag & Drop Editor</h4>
                        <p className="text-sm text-muted-foreground">Intuitive canvas-based design interface</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 hover:border-purple-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                        <Download className="w-5 h-5 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Export Tools</h4>
                        <p className="text-sm text-muted-foreground">PDF, PNG, JPEG export options</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 hover:border-purple-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-yellow-100 dark:bg-yellow-900 rounded-lg flex items-center justify-center">
                        <FileImage className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Professional Templates</h4>
                        <p className="text-sm text-muted-foreground">Journals, planners, covers, and more</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Productivity Hub Features */}
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">Productivity Hub</h3>
                <p className="text-muted-foreground">Project management and productivity tools for optimal workflow</p>
              </div>
              
              <div className="grid gap-4">
                <Card className="border-2 hover:border-green-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-pink-100 dark:bg-pink-900 rounded-lg flex items-center justify-center">
                        <Target className="w-5 h-5 text-pink-600 dark:text-pink-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Project Tracking</h4>
                        <p className="text-sm text-muted-foreground">Visual project tracking with progress indicators</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 hover:border-green-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900 rounded-lg flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Smart Notes</h4>
                        <p className="text-sm text-muted-foreground">Voice-to-text with intelligent organization</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 hover:border-green-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-cyan-100 dark:bg-cyan-900 rounded-lg flex items-center justify-center">
                        <Mic className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Voice Commands</h4>
                        <p className="text-sm text-muted-foreground">Hands-free control for design workflows</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 hover:border-green-300 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900 rounded-lg flex items-center justify-center">
                        <Lightbulb className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold">AI Assistant</h4>
                        <p className="text-sm text-muted-foreground">Contextual support and guidance</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          {/* Integration Benefits */}
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/10 dark:to-blue-900/10 rounded-2xl p-8 mb-16">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-foreground mb-4">Seamless Integration</h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Your creative work and personal wellness journey work together. Design therapeutic journals, 
                track your mood while creating, and export your mental health resources as professional products.
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <ArrowRight className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold mb-2">Create → Track → Improve</h4>
                <p className="text-sm text-muted-foreground">Design while monitoring your emotional state for optimal creativity</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Star className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold mb-2">Personalized Templates</h4>
                <p className="text-sm text-muted-foreground">Templates adapt to your emotional patterns and creative preferences</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Download className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold mb-2">Export Everything</h4>
                <p className="text-sm text-muted-foreground">Turn your wellness journey into shareable resources and products</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Start Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-800/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Quick Start
            </h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Jump right in with our popular templates or start from scratch
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Templates */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Popular Templates
                </h3>
                <Button variant="ghost" asChild>
                  <Link href="/templates">
                    View All <ArrowRight className="w-4 h-4 ml-1" />
                  </Link>
                </Button>
              </div>
              
              <div className="space-y-4">
                {recentTemplates.map((template) => (
                  <Card key={template.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-4">
                        <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-blue-500 rounded-lg flex items-center justify-center">
                          <FileImage className="w-8 h-8 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-gray-900 dark:text-white truncate">
                            {template.title}
                          </h4>
                          <p className="text-sm text-gray-600 dark:text-gray-300">
                            {template.description}
                          </p>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge variant="secondary" className="text-xs">
                              {template.category}
                            </Badge>
                            {template.isPremium && (
                              <Badge className="text-xs">
                                <Star className="w-3 h-3 mr-1" />
                                Pro
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Recent Projects */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Recent Projects
                </h3>
                <Button variant="ghost" asChild>
                  <Link href="/editor">
                    <Plus className="w-4 h-4 mr-1" />
                    New Project
                  </Link>
                </Button>
              </div>

              {recentProjects.length > 0 ? (
                <div className="space-y-4">
                  {recentProjects.map((project) => (
                    <Card key={project.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-4">
                          <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center">
                            <Palette className="w-8 h-8 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-gray-900 dark:text-white truncate">
                              {project.title}
                            </h4>
                            <p className="text-sm text-gray-600 dark:text-gray-300">
                              {project.description || 'No description'}
                            </p>
                            <div className="flex items-center space-x-2 mt-2">
                              <Badge variant="secondary" className="text-xs">
                                {project.category}
                              </Badge>
                              <span className="text-xs text-gray-500 flex items-center">
                                <Clock className="w-3 h-3 mr-1" />
                                {project.updatedAt ? new Date(project.updatedAt).toLocaleDateString() : 'Recent'}
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="border-dashed border-2">
                  <CardContent className="p-8 text-center">
                    <ImageIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                      No projects yet
                    </h4>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      Start creating your first design project
                    </p>
                    <Button asChild>
                      <Link href="/editor">
                        <Plus className="w-4 h-4 mr-2" />
                        Create Project
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-8 text-white">
            <h2 className="text-3xl font-bold mb-4">
              Ready to bring your ideas to life?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Start with a template or create from scratch. Export your designs as professional PDFs, PNGs, or JPEGs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/editor">
                  <Zap className="w-5 h-5 mr-2" />
                  Start Creating Now
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-purple-600" asChild>
                <Link href="/pricing">
                  View Pricing
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}