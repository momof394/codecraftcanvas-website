import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Users, 
  MessageCircle, 
  Phone, 
  Mail, 
  Calendar,
  FileText,
  DollarSign,
  Star,
  Plus,
  Edit,
  Trash2,
  Search,
  Filter,
  Send,
  Clock,
  CheckCircle,
  AlertCircle,
  Video,
  Paperclip,
  Download
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";

// Client management types
interface Client {
  id: string;
  name: string;
  email: string;
  phone?: string;
  company?: string;
  status: 'active' | 'inactive' | 'potential';
  tier: 'basic' | 'pro' | 'enterprise';
  totalProjects: number;
  totalRevenue: number;
  lastContact: string;
  notes: string;
  createdAt: string;
}

interface Project {
  id: string;
  clientId: string;
  title: string;
  description: string;
  status: 'draft' | 'in_progress' | 'review' | 'completed' | 'cancelled';
  dueDate: string;
  value: number;
  createdAt: string;
}

interface Communication {
  id: string;
  clientId: string;
  type: 'email' | 'phone' | 'meeting' | 'message';
  subject: string;
  content: string;
  direction: 'inbound' | 'outbound';
  status: 'sent' | 'delivered' | 'read' | 'replied';
  timestamp: string;
}

export default function ClientManagementPage() {
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [newMessage, setNewMessage] = useState({
    type: 'email' as const,
    subject: '',
    content: ''
  });
  const [showNewClientDialog, setShowNewClientDialog] = useState(false);
  const [newClient, setNewClient] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    tier: 'basic' as const,
    notes: ''
  });

  // Fetch clients
  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  // Fetch projects for selected client
  const { data: clientProjects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects", selectedClient?.id],
    enabled: !!selectedClient?.id,
  });

  // Fetch communications for selected client
  const { data: communications = [] } = useQuery<Communication[]>({
    queryKey: ["/api/communications", selectedClient?.id],
    enabled: !!selectedClient?.id,
  });

  // Create new client
  const createClientMutation = useMutation({
    mutationFn: async (client: Partial<Client>) => {
      const response = await fetch('/api/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(client)
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      setShowNewClientDialog(false);
      setNewClient({ name: '', email: '', phone: '', company: '', tier: 'basic', notes: '' });
    }
  });

  // Send communication
  const sendCommunicationMutation = useMutation({
    mutationFn: async (communication: Partial<Communication>) => {
      const response = await fetch('/api/communications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(communication)
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/communications", selectedClient?.id] });
      setNewMessage({ type: 'email', subject: '', content: '' });
    }
  });

  const filteredClients = clients.filter(client => {
    const matchesSearch = client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client.company?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || client.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleSendMessage = () => {
    if (selectedClient && newMessage.subject && newMessage.content) {
      sendCommunicationMutation.mutate({
        clientId: selectedClient.id,
        type: newMessage.type,
        subject: newMessage.subject,
        content: newMessage.content,
        direction: 'outbound',
        status: 'sent'
      });
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-gray-100 text-gray-800',
      potential: 'bg-blue-100 text-blue-800',
      draft: 'bg-gray-100 text-gray-800',
      in_progress: 'bg-blue-100 text-blue-800',
      review: 'bg-yellow-100 text-yellow-800',
      completed: 'bg-green-100 text-green-800',
      cancelled: 'bg-red-100 text-red-800'
    };
    return colors[status] || colors.active;
  };

  const getTierIcon = (tier: string) => {
    const icons: Record<string, React.ReactNode> = {
      basic: <Star className="w-4 h-4" />,
      pro: <Star className="w-4 h-4 fill-current" />,
      enterprise: <Star className="w-4 h-4 fill-current text-yellow-500" />
    };
    return icons[tier] || icons.basic;
  };

  return (
    <div className="min-h-screen p-6 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <Users className="w-8 h-8 text-purple-600" />
                <h1 className="text-3xl font-bold text-foreground">
                  Client Management
                </h1>
              </div>
              <p className="text-muted-foreground max-w-2xl">
                Manage client relationships, track communications, and monitor project progress.
              </p>
            </div>
            
            <Dialog open={showNewClientDialog} onOpenChange={setShowNewClientDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Client
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Client</DialogTitle>
                  <DialogDescription>
                    Create a new client profile to start managing their projects and communications.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Client Name</label>
                      <Input 
                        placeholder="John Doe"
                        value={newClient.name}
                        onChange={(e) => setNewClient({...newClient, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Email</label>
                      <Input 
                        type="email"
                        placeholder="john@example.com"
                        value={newClient.email}
                        onChange={(e) => setNewClient({...newClient, email: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Phone</label>
                      <Input 
                        placeholder="+1 (555) 123-4567"
                        value={newClient.phone}
                        onChange={(e) => setNewClient({...newClient, phone: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Company</label>
                      <Input 
                        placeholder="Acme Corp"
                        value={newClient.company}
                        onChange={(e) => setNewClient({...newClient, company: e.target.value})}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Tier</label>
                    <Select value={newClient.tier} onValueChange={(value: any) => setNewClient({...newClient, tier: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic</SelectItem>
                        <SelectItem value="pro">Pro</SelectItem>
                        <SelectItem value="enterprise">Enterprise</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Notes</label>
                    <Textarea 
                      placeholder="Additional notes about the client..."
                      value={newClient.notes}
                      onChange={(e) => setNewClient({...newClient, notes: e.target.value})}
                      rows={3}
                    />
                  </div>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={() => createClientMutation.mutate(newClient)}
                      disabled={createClientMutation.isPending}
                      className="flex-1"
                    >
                      {createClientMutation.isPending ? 'Creating...' : 'Create Client'}
                    </Button>
                    <Button variant="outline" onClick={() => setShowNewClientDialog(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Client List */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Clients</CardTitle>
                <div className="flex space-x-2">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input 
                        placeholder="Search clients..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-32">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="potential">Potential</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="max-h-96 overflow-y-auto">
                  {filteredClients.map((client) => (
                    <div
                      key={client.id}
                      className={`p-4 border-b cursor-pointer hover:bg-accent transition-colors ${
                        selectedClient?.id === client.id ? 'bg-accent' : ''
                      }`}
                      onClick={() => setSelectedClient(client)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium truncate">{client.name}</h4>
                          <p className="text-sm text-muted-foreground truncate">{client.email}</p>
                          {client.company && (
                            <p className="text-xs text-muted-foreground">{client.company}</p>
                          )}
                        </div>
                        <div className="flex flex-col items-end space-y-1">
                          <Badge className={`text-xs ${getStatusColor(client.status)}`}>
                            {client.status}
                          </Badge>
                          <div className="flex items-center text-muted-foreground">
                            {getTierIcon(client.tier)}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                        <span>{client.totalProjects} projects</span>
                        <span>${client.totalRevenue.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Client Details */}
          <div className="lg:col-span-2">
            {selectedClient ? (
              <Tabs defaultValue="overview" className="space-y-6">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="projects">Projects</TabsTrigger>
                  <TabsTrigger value="communications">Communications</TabsTrigger>
                  <TabsTrigger value="billing">Billing</TabsTrigger>
                </TabsList>

                {/* Overview Tab */}
                <TabsContent value="overview" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="flex items-center space-x-2">
                            <span>{selectedClient.name}</span>
                            {getTierIcon(selectedClient.tier)}
                          </CardTitle>
                          <CardDescription>{selectedClient.email}</CardDescription>
                        </div>
                        <Badge className={getStatusColor(selectedClient.status)}>
                          {selectedClient.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Contact Information</label>
                            <div className="mt-2 space-y-2">
                              <div className="flex items-center space-x-2">
                                <Mail className="w-4 h-4 text-muted-foreground" />
                                <span className="text-sm">{selectedClient.email}</span>
                              </div>
                              {selectedClient.phone && (
                                <div className="flex items-center space-x-2">
                                  <Phone className="w-4 h-4 text-muted-foreground" />
                                  <span className="text-sm">{selectedClient.phone}</span>
                                </div>
                              )}
                              {selectedClient.company && (
                                <div className="flex items-center space-x-2">
                                  <Users className="w-4 h-4 text-muted-foreground" />
                                  <span className="text-sm">{selectedClient.company}</span>
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Quick Actions</label>
                            <div className="mt-2 flex flex-wrap gap-2">
                              <Button size="sm" variant="outline">
                                <Mail className="w-4 h-4 mr-2" />
                                Email
                              </Button>
                              <Button size="sm" variant="outline">
                                <Phone className="w-4 h-4 mr-2" />
                                Call
                              </Button>
                              <Button size="sm" variant="outline">
                                <Video className="w-4 h-4 mr-2" />
                                Meeting
                              </Button>
                              <Button size="sm" variant="outline">
                                <Calendar className="w-4 h-4 mr-2" />
                                Schedule
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <Card>
                              <CardContent className="p-4 text-center">
                                <div className="text-2xl font-bold text-purple-600">
                                  {selectedClient.totalProjects}
                                </div>
                                <p className="text-sm text-muted-foreground">Total Projects</p>
                              </CardContent>
                            </Card>
                            <Card>
                              <CardContent className="p-4 text-center">
                                <div className="text-2xl font-bold text-green-600">
                                  ${selectedClient.totalRevenue.toLocaleString()}
                                </div>
                                <p className="text-sm text-muted-foreground">Total Revenue</p>
                              </CardContent>
                            </Card>
                          </div>
                          
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Last Contact</label>
                            <p className="text-sm mt-1">{new Date(selectedClient.lastContact).toLocaleDateString()}</p>
                          </div>
                        </div>
                      </div>

                      {selectedClient.notes && (
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Notes</label>
                          <div className="mt-2 p-3 bg-muted rounded-lg">
                            <p className="text-sm">{selectedClient.notes}</p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Projects Tab */}
                <TabsContent value="projects" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Client Projects</CardTitle>
                        <Button asChild>
                          <Link href="/editor">
                            <Plus className="w-4 h-4 mr-2" />
                            New Project
                          </Link>
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {clientProjects.map((project) => (
                          <div key={project.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex-1">
                              <h4 className="font-medium">{project.title}</h4>
                              <p className="text-sm text-muted-foreground">{project.description}</p>
                              <div className="flex items-center space-x-4 mt-2">
                                <Badge className={getStatusColor(project.status)}>
                                  {project.status.replace('_', ' ')}
                                </Badge>
                                <span className="text-xs text-muted-foreground">
                                  Due: {new Date(project.dueDate).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">${project.value.toLocaleString()}</div>
                              <Button size="sm" variant="outline" className="mt-2">
                                <Edit className="w-4 h-4 mr-2" />
                                Edit
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Communications Tab */}
                <TabsContent value="communications" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Send Message</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex space-x-4">
                        <Select value={newMessage.type} onValueChange={(value: any) => setNewMessage({...newMessage, type: value})}>
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="email">Email</SelectItem>
                            <SelectItem value="message">Message</SelectItem>
                            <SelectItem value="phone">Phone Note</SelectItem>
                            <SelectItem value="meeting">Meeting Note</SelectItem>
                          </SelectContent>
                        </Select>
                        <Input 
                          placeholder="Subject"
                          value={newMessage.subject}
                          onChange={(e) => setNewMessage({...newMessage, subject: e.target.value})}
                          className="flex-1"
                        />
                      </div>
                      <Textarea 
                        placeholder="Type your message..."
                        value={newMessage.content}
                        onChange={(e) => setNewMessage({...newMessage, content: e.target.value})}
                        rows={4}
                      />
                      <div className="flex space-x-2">
                        <Button onClick={handleSendMessage} disabled={sendCommunicationMutation.isPending}>
                          <Send className="w-4 h-4 mr-2" />
                          {sendCommunicationMutation.isPending ? 'Sending...' : 'Send'}
                        </Button>
                        <Button variant="outline">
                          <Paperclip className="w-4 h-4 mr-2" />
                          Attach
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Communication History</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {communications.map((comm) => (
                          <div key={comm.id} className="flex space-x-4 p-4 border rounded-lg">
                            <div className="flex-shrink-0">
                              {comm.type === 'email' && <Mail className="w-5 h-5 text-blue-500" />}
                              {comm.type === 'phone' && <Phone className="w-5 h-5 text-green-500" />}
                              {comm.type === 'meeting' && <Calendar className="w-5 h-5 text-purple-500" />}
                              {comm.type === 'message' && <MessageCircle className="w-5 h-5 text-orange-500" />}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <h4 className="font-medium">{comm.subject}</h4>
                                <div className="flex items-center space-x-2">
                                  <Badge variant={comm.direction === 'inbound' ? 'secondary' : 'default'}>
                                    {comm.direction}
                                  </Badge>
                                  <span className="text-xs text-muted-foreground">
                                    {new Date(comm.timestamp).toLocaleString()}
                                  </span>
                                </div>
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">{comm.content}</p>
                              <div className="flex items-center space-x-2 mt-2">
                                {comm.status === 'read' && <CheckCircle className="w-4 h-4 text-green-500" />}
                                {comm.status === 'sent' && <Clock className="w-4 h-4 text-blue-500" />}
                                <span className="text-xs text-muted-foreground">{comm.status}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Billing Tab */}
                <TabsContent value="billing" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <DollarSign className="w-5 h-5" />
                        <span>Billing Overview</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-3 gap-6">
                        <Card>
                          <CardContent className="p-4 text-center">
                            <div className="text-2xl font-bold text-green-600">
                              ${selectedClient.totalRevenue.toLocaleString()}
                            </div>
                            <p className="text-sm text-muted-foreground">Total Revenue</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4 text-center">
                            <div className="text-2xl font-bold text-blue-600">
                              $0
                            </div>
                            <p className="text-sm text-muted-foreground">Outstanding</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4 text-center">
                            <div className="text-2xl font-bold text-purple-600">
                              {selectedClient.tier}
                            </div>
                            <p className="text-sm text-muted-foreground">Current Tier</p>
                          </CardContent>
                        </Card>
                      </div>
                      
                      <div className="mt-6 flex space-x-4">
                        <Button>
                          <Plus className="w-4 h-4 mr-2" />
                          Create Invoice
                        </Button>
                        <Button variant="outline">
                          <Download className="w-4 h-4 mr-2" />
                          Export Reports
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Select a Client</h3>
                  <p className="text-muted-foreground">
                    Choose a client from the list to view their details, projects, and communications.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}