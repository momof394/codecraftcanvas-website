import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  FileImage, 
  Star, 
  Filter,
  BookOpen,
  Calendar,
  FileText,
  Sparkles,
  Palette,
  Eye,
  Plus
} from "lucide-react";

export default function TemplatesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ["/api/templates"],
  });

  const categories = [
    { id: "all", label: "All Templates", icon: FileImage },
    { id: "journal", label: "Journals", icon: BookOpen },
    { id: "planner", label: "Planners", icon: Calendar },
    { id: "cover", label: "Covers", icon: FileText },
    { id: "social_media", label: "Social Media", icon: Sparkles },
  ];

  const filteredTemplates = templates.filter((template: any) => {
    const matchesSearch = template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleUseTemplate = (templateId: string) => {
    // This would create a new project from the template
    window.location.href = `/editor?template=${templateId}`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Palette className="w-12 h-12 text-purple-600 mx-auto mb-4 animate-spin" />
          <p className="text-gray-600 dark:text-gray-300">Loading templates...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Design Templates
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Professional templates to jumpstart your creative projects. Choose from journals, 
            planners, covers, and more.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search templates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              <Button asChild>
                <Link href="/editor">
                  <Plus className="w-4 h-4 mr-2" />
                  Create from Scratch
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Category Tabs */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-8">
          <TabsList className="grid w-full grid-cols-5">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <TabsTrigger key={category.id} value={category.id} className="flex items-center">
                  <Icon className="w-4 h-4 mr-2" />
                  <span className="hidden sm:inline">{category.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>
        </Tabs>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTemplates.map((template: any) => (
            <Card key={template.id} className="group hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
              <CardContent className="p-0">
                {/* Template Preview */}
                <div className="aspect-[3/4] bg-gradient-to-br from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 rounded-t-lg relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <FileImage className="w-12 h-12 text-purple-600 dark:text-purple-400" />
                  </div>
                  
                  {/* Preview Overlay */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                    <div className="flex space-x-2">
                      <Button variant="secondary" size="sm">
                        <Eye className="w-4 h-4 mr-1" />
                        Preview
                      </Button>
                      <Button size="sm" onClick={() => handleUseTemplate(template.id)}>
                        Use Template
                      </Button>
                    </div>
                  </div>

                  {/* Premium Badge */}
                  {template.isPremium && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-yellow-500 text-white">
                        <Star className="w-3 h-3 mr-1" />
                        Pro
                      </Badge>
                    </div>
                  )}
                </div>

                {/* Template Info */}
                <div className="p-4">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2 line-clamp-1">
                    {template.title}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-3 line-clamp-2">
                    {template.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary" className="text-xs">
                      {template.category}
                    </Badge>
                    <div className="flex items-center text-xs text-gray-500">
                      <Star className="w-3 h-3 mr-1" />
                      {template.usageCount || 0} uses
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full mt-3" 
                    size="sm"
                    onClick={() => handleUseTemplate(template.id)}
                  >
                    Use Template
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredTemplates.length === 0 && (
          <div className="text-center py-12">
            <FileImage className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              No templates found
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Try adjusting your search or category filter, or create a new design from scratch.
            </p>
            <Button asChild>
              <Link href="/editor">
                <Plus className="w-4 h-4 mr-2" />
                Create from Scratch
              </Link>
            </Button>
          </div>
        )}

        {/* Template Stats */}
        <div className="mt-16 bg-gray-50 dark:bg-gray-800/50 rounded-lg p-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                {templates.length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Total Templates
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                {templates.filter((t: any) => t.category === 'journal').length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Journal Templates
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
                {templates.filter((t: any) => t.category === 'planner').length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Planner Templates
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-orange-600 dark:text-orange-400 mb-2">
                {templates.filter((t: any) => !t.isPremium).length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Free Templates
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}