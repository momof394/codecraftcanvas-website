import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";
import { ArrowLeft, Shield, FileText, Users, Clock } from "lucide-react";

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Button variant="ghost" asChild>
            <Link href="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Link>
          </Button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Terms of Service
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-6">
            Our commitment to providing you with transparent, fair, and comprehensive terms for using Mindful Focus.
          </p>
          <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Last updated: January 28, 2025
            </div>
            <div className="flex items-center">
              <FileText className="w-4 h-4 mr-2" />
              Version 2.1
            </div>
          </div>
        </div>

        {/* Quick Navigation */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Quick Navigation
            </CardTitle>
            <CardDescription>
              Jump to any section of our terms of service
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-2">
              <a href="#acceptance" className="text-purple-600 hover:text-purple-800 text-sm">1. Acceptance of Terms</a>
              <a href="#services" className="text-purple-600 hover:text-purple-800 text-sm">2. Description of Services</a>
              <a href="#eligibility" className="text-purple-600 hover:text-purple-800 text-sm">3. Eligibility and Registration</a>
              <a href="#conduct" className="text-purple-600 hover:text-purple-800 text-sm">4. User Conduct</a>
              <a href="#privacy" className="text-purple-600 hover:text-purple-800 text-sm">5. Privacy and Data Protection</a>
              <a href="#intellectual" className="text-purple-600 hover:text-purple-800 text-sm">6. Intellectual Property</a>
              <a href="#limitation" className="text-purple-600 hover:text-purple-800 text-sm">7. Limitation of Liability</a>
              <a href="#termination" className="text-purple-600 hover:text-purple-800 text-sm">8. Termination</a>
              <a href="#changes" className="text-purple-600 hover:text-purple-800 text-sm">9. Changes to Terms</a>
              <a href="#contact" className="text-purple-600 hover:text-purple-800 text-sm">10. Contact Information</a>
            </div>
          </CardContent>
        </Card>

        {/* Terms Content */}
        <div className="space-y-8">
          <section id="acceptance">
            <h2 className="text-2xl font-bold mb-4">1. Acceptance of Terms</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                By accessing or using Mindful Focus ("Service"), you agree to be bound by these Terms of Service ("Terms"). 
                If you disagree with any part of these terms, then you may not access the Service.
              </p>
              <p>
                These Terms apply to all visitors, users, and others who access or use the Service. By using our Service, 
                you represent that you have read, understood, and agree to be bound by these Terms.
              </p>
            </div>
          </section>

          <Separator />

          <section id="services">
            <h2 className="text-2xl font-bold mb-4">2. Description of Services</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                Mindful Focus is a comprehensive cognitive wellness platform that provides:
              </p>
              <ul>
                <li><strong>Cognitive Assessment Tools:</strong> Evidence-based evaluations of attention, memory, and executive function</li>
                <li><strong>Personalized Training Programs:</strong> Adaptive exercises designed to improve cognitive performance</li>
                <li><strong>Wellness Tracking:</strong> Mood monitoring, journaling, and progress analytics</li>
                <li><strong>Educational Resources:</strong> Research-backed articles and guidance on cognitive wellness</li>
                <li><strong>Community Features:</strong> Optional social features for support and motivation</li>
              </ul>
              <p>
                Our services are designed to support cognitive wellness and are not intended to diagnose, treat, cure, 
                or prevent any medical condition. Always consult with qualified healthcare professionals for medical advice.
              </p>
            </div>
          </section>

          <Separator />

          <section id="eligibility">
            <h2 className="text-2xl font-bold mb-4">3. Eligibility and Registration</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                You must be at least 13 years old to use this Service. Users under 18 must have parental or guardian 
                consent. By using the Service, you represent and warrant that:
              </p>
              <ul>
                <li>You have the legal capacity to enter into these Terms</li>
                <li>All information you provide is accurate and current</li>
                <li>You will maintain the accuracy of your information</li>
                <li>You are not prohibited from using the Service under applicable law</li>
              </ul>
              <p>
                We reserve the right to refuse service, terminate accounts, or cancel orders at our sole discretion.
              </p>
            </div>
          </section>

          <Separator />

          <section id="conduct">
            <h2 className="text-2xl font-bold mb-4">4. User Conduct</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>You agree not to use the Service to:</p>
              <ul>
                <li>Violate any applicable laws or regulations</li>
                <li>Infringe on the rights of others</li>
                <li>Upload malicious content or code</li>
                <li>Attempt to gain unauthorized access to our systems</li>
                <li>Interfere with the proper functioning of the Service</li>
                <li>Collect user information without consent</li>
                <li>Use the Service for commercial purposes without authorization</li>
                <li>Impersonate others or provide false information</li>
              </ul>
              <p>
                We reserve the right to investigate and take appropriate action against users who violate these guidelines, 
                including but not limited to warning, suspension, or termination of accounts.
              </p>
            </div>
          </section>

          <Separator />

          <section id="privacy">
            <h2 className="text-2xl font-bold mb-4">5. Privacy and Data Protection</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                Your privacy is fundamental to our mission. Our comprehensive Privacy Policy, incorporated by reference 
                into these Terms, details how we collect, use, and protect your information.
              </p>
              <p>Key privacy commitments:</p>
              <ul>
                <li><strong>Data Minimization:</strong> We collect only information necessary for service functionality</li>
                <li><strong>User Control:</strong> You maintain control over your data with export and deletion options</li>
                <li><strong>Security:</strong> We employ industry-standard encryption and security measures</li>
                <li><strong>No Sale:</strong> We never sell your personal information to third parties</li>
                <li><strong>Transparency:</strong> Clear disclosure of all data practices and processing purposes</li>
              </ul>
              <p>
                For detailed information about our data practices, please review our 
                <Link href="/privacy" className="text-purple-600 hover:text-purple-800 underline">Privacy Policy</Link>.
              </p>
            </div>
          </section>

          <Separator />

          <section id="intellectual">
            <h2 className="text-2xl font-bold mb-4">6. Intellectual Property</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                The Service and its original content, features, and functionality are owned by Mindful Focus and are 
                protected by international copyright, trademark, patent, trade secret, and other intellectual property laws.
              </p>
              <p><strong>Our Content:</strong></p>
              <ul>
                <li>All text, graphics, user interfaces, visual interfaces, sounds, and computer code</li>
                <li>Assessment algorithms and cognitive training methodologies</li>
                <li>Research content and educational materials</li>
                <li>Trademarks, service marks, and trade names</li>
              </ul>
              <p><strong>Your Content:</strong></p>
              <ul>
                <li>You retain ownership of content you create or upload</li>
                <li>You grant us a limited license to use your content for service provision</li>
                <li>You represent that you have the right to grant this license</li>
                <li>We may remove content that violates these Terms</li>
              </ul>
            </div>
          </section>

          <Separator />

          <section id="limitation">
            <h2 className="text-2xl font-bold mb-4">7. Limitation of Liability</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                The Service is provided on an "AS IS" and "AS AVAILABLE" basis. We expressly disclaim all warranties 
                of any kind, whether express or implied, including but not limited to warranties of merchantability, 
                fitness for a particular purpose, and non-infringement.
              </p>
              <p><strong>Service Limitations:</strong></p>
              <ul>
                <li>We do not guarantee continuous, uninterrupted, or secure access</li>
                <li>We cannot guarantee the accuracy or completeness of information</li>
                <li>Results from cognitive assessments may vary and are not medical diagnoses</li>
                <li>Third-party integrations may have separate terms and limitations</li>
              </ul>
              <p>
                To the maximum extent permitted by applicable law, in no event shall Mindful Focus be liable for any 
                indirect, incidental, special, consequential, or punitive damages, including but not limited to loss 
                of profits, data, use, goodwill, or other intangible losses.
              </p>
            </div>
          </section>

          <Separator />

          <section id="termination">
            <h2 className="text-2xl font-bold mb-4">8. Termination</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                Either party may terminate these Terms at any time. We may terminate or suspend your account 
                immediately, without prior notice, for conduct that we believe violates these Terms or is harmful 
                to other users, us, or third parties.
              </p>
              <p><strong>Upon termination:</strong></p>
              <ul>
                <li>Your right to use the Service will cease immediately</li>
                <li>We may delete your account and all associated data</li>
                <li>You may request a copy of your data within 30 days</li>
                <li>Provisions that should survive termination will remain in effect</li>
              </ul>
              <p>
                You may terminate your account at any time through your account settings or by contacting us directly.
              </p>
            </div>
          </section>

          <Separator />

          <section id="changes">
            <h2 className="text-2xl font-bold mb-4">9. Changes to Terms</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                We reserve the right to modify these Terms at any time. We will provide notice of material changes 
                through the Service or via email. Your continued use of the Service after changes take effect 
                constitutes acceptance of the revised Terms.
              </p>
              <p><strong>Change notification process:</strong></p>
              <ul>
                <li>30-day advance notice for material changes</li>
                <li>Prominent display of changes on the Service</li>
                <li>Email notification to registered users</li>
                <li>Version history maintained for transparency</li>
              </ul>
            </div>
          </section>

          <Separator />

          <section id="contact">
            <h2 className="text-2xl font-bold mb-4">10. Contact Information</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <p>
                If you have any questions about these Terms of Service, please contact us:
              </p>
              <ul>
                <li><strong>Email:</strong> legal@mindful-focus.com</li>
                <li><strong>Address:</strong> Mindful Focus Legal Department, 123 Innovation Drive, San Francisco, CA 94105</li>
                <li><strong>Phone:</strong> +1 (555) 123-4567</li>
                <li><strong>Hours:</strong> Monday-Friday, 9:00 AM - 5:00 PM PST</li>
              </ul>
              <p>
                For general support inquiries, please use our 
                <Link href="/support" className="text-purple-600 hover:text-purple-800 underline">support center</Link>.
              </p>
            </div>
          </section>
        </div>

        {/* Footer Actions */}
        <div className="mt-16 p-6 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
          <div className="text-center">
            <h3 className="text-lg font-semibold mb-4">Have Questions About Our Terms?</h3>
            <p className="text-muted-foreground mb-6">
              Our legal team is here to help clarify any questions you may have about these terms of service.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild>
                <Link href="/contact">
                  Contact Legal Team
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/privacy">
                  <Shield className="w-4 h-4 mr-2" />
                  View Privacy Policy
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}