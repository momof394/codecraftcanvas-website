import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import OrbInterface from "@/components/orb-interface";
import AIAssistant from "@/components/ai-assistant";
import VoiceEmotionDetector from "@/components/voice-emotion-detector";
import { 
  Circle,
  Code,
  Play,
  Pause,
  Square,
  Save,
  Download,
  Upload,
  Brain,
  Palette,
  Layers,
  Eye,
  Settings,
  Zap,
  Sparkles,
  Target,
  Heart,
  Mic,
  Volume2,
  FileCode,
  Brush,
  Grid,
  Move,
  RotateCcw
} from "lucide-react";

interface CodeElement {
  id: string;
  type: 'function' | 'variable' | 'class' | 'component' | 'orb';
  name: string;
  code: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  connections: string[];
  mood?: number;
  energy?: number;
}

interface OrbCanvasState {
  elements: CodeElement[];
  selectedElement: string | null;
  isRunning: boolean;
  orbMood: number;
  canvasMode: 'design' | 'code' | 'emotional';
}

export default function OrbCanvasPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [canvasState, setCanvasState] = useState<OrbCanvasState>({
    elements: [
      {
        id: 'main-orb',
        type: 'orb',
        name: 'Emotional Core',
        code: 'function emotionalCore() {\n  return { mood: currentMood, energy: energy };\n}',
        x: 400,
        y: 300,
        width: 120,
        height: 120,
        color: '#8B5CF6',
        connections: [],
        mood: 3,
        energy: 3
      }
    ],
    selectedElement: null,
    isRunning: false,
    orbMood: 3,
    canvasMode: 'design'
  });

  const [newElement, setNewElement] = useState<{
    type: 'function' | 'variable' | 'class' | 'component' | 'orb';
    name: string;
    code: string;
  }>({
    type: 'function',
    name: '',
    code: ''
  });

  const [isAIMode, setIsAIMode] = useState(false);
  const [voiceMode, setVoiceMode] = useState(false);

  // Canvas drawing effect
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    ctx.strokeStyle = '#f0f0f0';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 20) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 20) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Draw elements
    canvasState.elements.forEach(element => {
      if (element.type === 'orb') {
        // Draw orb with emotional glow
        const gradient = ctx.createRadialGradient(
          element.x + element.width/2, 
          element.y + element.height/2, 
          0,
          element.x + element.width/2, 
          element.y + element.height/2, 
          element.width/2
        );
        gradient.addColorStop(0, element.color + '80');
        gradient.addColorStop(1, element.color + '20');
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(
          element.x + element.width/2, 
          element.y + element.height/2, 
          element.width/2, 
          0, 
          2 * Math.PI
        );
        ctx.fill();

        // Draw pulse effect if high energy
        if (element.energy && element.energy >= 4) {
          ctx.strokeStyle = element.color + '60';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(
            element.x + element.width/2, 
            element.y + element.height/2, 
            element.width/2 + 10, 
            0, 
            2 * Math.PI
          );
          ctx.stroke();
        }

        // Draw inner reflection
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.beginPath();
        ctx.arc(
          element.x + element.width/3, 
          element.y + element.height/3, 
          15, 
          0, 
          2 * Math.PI
        );
        ctx.fill();
      } else {
        // Draw code blocks
        ctx.fillStyle = element.color + '20';
        ctx.fillRect(element.x, element.y, element.width, element.height);
        
        ctx.strokeStyle = element.color;
        ctx.lineWidth = 2;
        ctx.strokeRect(element.x, element.y, element.width, element.height);
        
        // Draw element name
        ctx.fillStyle = '#333';
        ctx.font = '12px sans-serif';
        ctx.fillText(element.name, element.x + 5, element.y + 15);
      }

      // Highlight selected element
      if (canvasState.selectedElement === element.id) {
        ctx.strokeStyle = '#8B5CF6';
        ctx.lineWidth = 3;
        ctx.setLineDash([5, 5]);
        ctx.strokeRect(element.x - 2, element.y - 2, element.width + 4, element.height + 4);
        ctx.setLineDash([]);
      }
    });

    // Draw connections
    canvasState.elements.forEach(element => {
      element.connections.forEach(connectionId => {
        const connectedElement = canvasState.elements.find(e => e.id === connectionId);
        if (connectedElement) {
          ctx.strokeStyle = '#8B5CF6';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(
            element.x + element.width/2,
            element.y + element.height/2
          );
          ctx.lineTo(
            connectedElement.x + connectedElement.width/2,
            connectedElement.y + connectedElement.height/2
          );
          ctx.stroke();
        }
      });
    });
  }, [canvasState]);

  const addElement = () => {
    if (!newElement.name || !newElement.code) return;

    const element: CodeElement = {
      id: Date.now().toString(),
      type: newElement.type,
      name: newElement.name,
      code: newElement.code,
      x: Math.random() * 400 + 100,
      y: Math.random() * 300 + 100,
      width: newElement.type === 'orb' ? 120 : 160,
      height: newElement.type === 'orb' ? 120 : 80,
      color: ['#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#3B82F6'][Math.floor(Math.random() * 5)],
      connections: []
    };

    setCanvasState(prev => ({
      ...prev,
      elements: [...prev.elements, element]
    }));

    setNewElement({ type: 'function', name: '', code: '' });
  };

  const runCanvas = () => {
    setCanvasState(prev => ({ ...prev, isRunning: !prev.isRunning }));
    
    // Simulate code execution with orb emotional feedback
    if (!canvasState.isRunning) {
      const interval = setInterval(() => {
        setCanvasState(prev => ({
          ...prev,
          elements: prev.elements.map(element => {
            if (element.type === 'orb') {
              return {
                ...element,
                energy: Math.max(1, Math.min(5, element.energy! + (Math.random() - 0.5) * 2))
              };
            }
            return element;
          })
        }));
      }, 1000);

      setTimeout(() => {
        clearInterval(interval);
        setCanvasState(prev => ({ ...prev, isRunning: false }));
      }, 5000);
    }
  };

  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    // Find clicked element
    const clickedElement = canvasState.elements.find(element => 
      x >= element.x && x <= element.x + element.width &&
      y >= element.y && y <= element.y + element.height
    );

    setCanvasState(prev => ({
      ...prev,
      selectedElement: clickedElement ? clickedElement.id : null
    }));
  };

  const selectedElement = canvasState.elements.find(e => e.id === canvasState.selectedElement);

  return (
    <div className="min-h-screen p-6 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <Circle className="w-8 h-8 text-purple-600" />
                <h1 className="text-3xl font-bold text-foreground">
                  Orb Canvas Studio
                </h1>
              </div>
              <p className="text-muted-foreground max-w-2xl">
                Create interactive emotional code experiences with visual programming and AI collaboration.
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant={canvasState.isRunning ? "default" : "secondary"}>
                {canvasState.isRunning ? "Running" : "Stopped"}
              </Badge>
              <Button
                onClick={runCanvas}
                variant={canvasState.isRunning ? "destructive" : "default"}
              >
                {canvasState.isRunning ? (
                  <>
                    <Square className="w-4 h-4 mr-2" />
                    Stop
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Run
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Orb State Control */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Emotional State</CardTitle>
              </CardHeader>
              <CardContent>
                <OrbInterface 
                  currentMood={canvasState.orbMood}
                  onStateChange={(state) => {
                    setCanvasState(prev => ({
                      ...prev,
                      orbMood: state.mood,
                      elements: prev.elements.map(element => 
                        element.type === 'orb' 
                          ? { ...element, mood: state.mood, energy: state.energy }
                          : element
                      )
                    }));
                  }}
                />
              </CardContent>
            </Card>

            {/* Add Elements */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Add Element</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select 
                  value={newElement.type} 
                  onValueChange={(value: any) => setNewElement({...newElement, type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="function">Function</SelectItem>
                    <SelectItem value="variable">Variable</SelectItem>
                    <SelectItem value="class">Class</SelectItem>
                    <SelectItem value="component">Component</SelectItem>
                    <SelectItem value="orb">Emotion Orb</SelectItem>
                  </SelectContent>
                </Select>
                
                <Input 
                  placeholder="Element name"
                  value={newElement.name}
                  onChange={(e) => setNewElement({...newElement, name: e.target.value})}
                />
                
                <Textarea 
                  placeholder="Code or description"
                  value={newElement.code}
                  onChange={(e) => setNewElement({...newElement, code: e.target.value})}
                  rows={3}
                />
                
                <Button onClick={addElement} className="w-full">
                  <FileCode className="w-4 h-4 mr-2" />
                  Add to Canvas
                </Button>
              </CardContent>
            </Card>

            {/* Mode Toggles */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Canvas Modes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-col space-y-2">
                  <Button 
                    variant={isAIMode ? "default" : "outline"}
                    onClick={() => setIsAIMode(!isAIMode)}
                    className="w-full"
                  >
                    <Brain className="w-4 h-4 mr-2" />
                    AI Collaboration
                  </Button>
                  
                  <Button 
                    variant={voiceMode ? "default" : "outline"}
                    onClick={() => setVoiceMode(!voiceMode)}
                    className="w-full"
                  >
                    <Mic className="w-4 h-4 mr-2" />
                    Voice Control
                  </Button>
                  
                  <Button variant="outline" className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Export Canvas
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Canvas Area */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="canvas" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="canvas">Canvas</TabsTrigger>
                <TabsTrigger value="code">Code View</TabsTrigger>
                <TabsTrigger value="ai" className={isAIMode ? "bg-purple-100" : ""}>AI Chat</TabsTrigger>
                <TabsTrigger value="voice" className={voiceMode ? "bg-blue-100" : ""}>Voice</TabsTrigger>
              </TabsList>

              {/* Canvas Tab */}
              <TabsContent value="canvas">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Interactive Canvas</CardTitle>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">
                          {canvasState.elements.length} elements
                        </Badge>
                        <Button size="sm" variant="outline">
                          <Grid className="w-4 h-4 mr-2" />
                          Grid
                        </Button>
                        <Button size="sm" variant="outline">
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Reset
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="relative">
                      <canvas
                        ref={canvasRef}
                        width={800}
                        height={600}
                        className="border rounded-lg bg-white w-full h-96 cursor-crosshair"
                        onClick={handleCanvasClick}
                      />
                      
                      {canvasState.isRunning && (
                        <div className="absolute top-4 right-4 flex items-center space-x-2 bg-green-100 px-3 py-1 rounded-full">
                          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                          <span className="text-green-700 text-sm font-medium">Running</span>
                        </div>
                      )}
                    </div>

                    {/* Element Details */}
                    {selectedElement && (
                      <div className="mt-4 p-4 bg-muted rounded-lg">
                        <h4 className="font-medium mb-2">{selectedElement.name}</h4>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Type:</span> {selectedElement.type}
                          </div>
                          <div>
                            <span className="text-muted-foreground">Position:</span> ({selectedElement.x}, {selectedElement.y})
                          </div>
                          {selectedElement.mood && (
                            <div>
                              <span className="text-muted-foreground">Mood:</span> {selectedElement.mood}/5
                            </div>
                          )}
                          {selectedElement.energy && (
                            <div>
                              <span className="text-muted-foreground">Energy:</span> {selectedElement.energy}/5
                            </div>
                          )}
                        </div>
                        <div className="mt-3">
                          <span className="text-muted-foreground text-sm">Code:</span>
                          <pre className="mt-1 p-2 bg-background rounded text-sm overflow-x-auto">
                            {selectedElement.code}
                          </pre>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Code View Tab */}
              <TabsContent value="code">
                <Card>
                  <CardHeader>
                    <CardTitle>Generated Code</CardTitle>
                    <CardDescription>
                      View and edit the code representation of your canvas
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <pre className="text-sm">
                        {canvasState.elements.map(element => (
                          <div key={element.id} className="mb-4 p-3 bg-muted rounded">
                            <div className="text-purple-600 font-medium">// {element.name} ({element.type})</div>
                            <div className="mt-1">{element.code}</div>
                          </div>
                        ))}
                      </pre>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* AI Chat Tab */}
              <TabsContent value="ai">
                <Card>
                  <CardHeader>
                    <CardTitle>AI Creative Partner</CardTitle>
                    <CardDescription>
                      Collaborate with AI to enhance your orb canvas experience
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <AIAssistant />
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Voice Tab */}
              <TabsContent value="voice">
                <Card>
                  <CardHeader>
                    <CardTitle>Voice-Controlled Canvas</CardTitle>
                    <CardDescription>
                      Use voice commands and emotion detection to control your canvas
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <VoiceEmotionDetector 
                      onEmotionDetected={(analysis) => {
                        // Update orb state based on voice emotion
                        const emotionToMood: Record<string, number> = {
                          'happy': 5,
                          'excited': 5,
                          'calm': 4,
                          'neutral': 3,
                          'stressed': 2,
                          'sad': 1,
                          'angry': 1
                        };
                        const detectedMood = emotionToMood[analysis.emotion] || 3;
                        setCanvasState(prev => ({
                          ...prev,
                          orbMood: detectedMood,
                          elements: prev.elements.map(element => 
                            element.type === 'orb' 
                              ? { ...element, mood: detectedMood, energy: Math.round(analysis.audioFeatures.energy / 20) }
                              : element
                          )
                        }));
                      }}
                      onTranscriptUpdate={(transcript) => {
                        // Voice commands for canvas control
                        const lowerTranscript = transcript.toLowerCase();
                        if (lowerTranscript.includes('run canvas')) {
                          if (!canvasState.isRunning) runCanvas();
                        } else if (lowerTranscript.includes('stop canvas')) {
                          if (canvasState.isRunning) runCanvas();
                        }
                      }}
                    />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}