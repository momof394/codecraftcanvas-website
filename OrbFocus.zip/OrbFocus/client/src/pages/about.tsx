import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Brain, 
  Users, 
  Target, 
  Award, 
  Heart, 
  Shield, 
  Lightbulb,
  CheckCircle,
  Quote
} from "lucide-react";
import { Link } from "wouter";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            About Orb Focus Studio
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            We're pioneering the future of digital creativity by combining cutting-edge design technology 
            with intuitive interfaces to help creators, professionals, and teams optimize their creative workflows and productivity.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Badge variant="secondary" className="text-sm py-2 px-4">
              <Brain className="w-4 h-4 mr-2" />
              Evidence-Based
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              <Shield className="w-4 h-4 mr-2" />
              Privacy-First
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              <Award className="w-4 h-4 mr-2" />
              Clinically Validated
            </Badge>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <Card className="border-2 border-purple-200 dark:border-purple-800">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Target className="w-6 h-6 mr-3 text-purple-600" />
                  Our Mission
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  To democratize access to advanced cognitive wellness tools, empowering individuals to 
                  understand and optimize their mental performance through personalized, science-backed 
                  interventions that adapt to their unique neurological profile and lifestyle needs.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-blue-200 dark:border-blue-800">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Lightbulb className="w-6 h-6 mr-3 text-blue-600" />
                  Our Vision
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  A world where every individual has the tools and knowledge to achieve their optimal 
                  cognitive state, where mental wellness is proactive rather than reactive, and where 
                  technology serves as a bridge to deeper self-understanding and personal growth.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Core Values */}
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Our Core Values</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              These principles guide everything we do, from product development to user support.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <CardTitle>Privacy & Security</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Your cognitive data is deeply personal. We employ end-to-end encryption and 
                  give you complete control over your information with transparent data practices.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mb-4">
                  <Brain className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <CardTitle>Scientific Rigor</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Every feature is grounded in peer-reviewed neuroscience research and validated 
                  through clinical studies with measurable outcomes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                  <Heart className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle>Accessibility</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Cognitive wellness tools should be available to everyone, regardless of technical 
                  expertise, neurological differences, or economic background.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Research Foundation */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Research Foundation</h2>
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Our platform is built on decades of neuroscience research from leading institutions 
              worldwide, ensuring every feature has scientific backing.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-semibold mb-6">Key Research Areas</h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Cognitive Load Theory</h4>
                    <p className="text-sm text-muted-foreground">
                      Understanding how the brain processes information to optimize learning and focus
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Neuroplasticity Research</h4>
                    <p className="text-sm text-muted-foreground">
                      Leveraging the brain's ability to reorganize and form new neural connections
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Emotional Regulation Studies</h4>
                    <p className="text-sm text-muted-foreground">
                      Evidence-based techniques for managing stress and emotional responses
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Executive Function Development</h4>
                    <p className="text-sm text-muted-foreground">
                      Supporting working memory, cognitive flexibility, and inhibitory control
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Research Partnerships</CardTitle>
                <CardDescription>
                  We collaborate with leading academic institutions to advance cognitive wellness research
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <h4 className="font-semibold text-purple-900 dark:text-purple-100">Stanford Neuroscience Institute</h4>
                    <p className="text-sm text-purple-700 dark:text-purple-300">
                      Collaborative research on attention training and cognitive enhancement
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <h4 className="font-semibold text-blue-900 dark:text-blue-100">MIT Brain and Cognitive Sciences</h4>
                    <p className="text-sm text-blue-700 dark:text-blue-300">
                      Joint studies on computational models of human cognition
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <h4 className="font-semibold text-green-900 dark:text-green-100">Harvard Medical School</h4>
                    <p className="text-sm text-green-700 dark:text-green-300">
                      Clinical validation of digital therapeutic interventions
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Philosophy */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Our Team Philosophy</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We believe in the power of interdisciplinary collaboration to solve complex cognitive challenges.
            </p>
          </div>

          <div className="space-y-8">
            <Card className="p-6">
              <div className="flex items-start space-x-4">
                <Quote className="w-8 h-8 text-purple-600 mt-2 flex-shrink-0" />
                <div>
                  <p className="text-lg text-muted-foreground italic mb-4">
                    "Our diverse team of neuroscientists, cognitive psychologists, software engineers, 
                    and user experience designers work together to create tools that are not only 
                    scientifically sound but also genuinely helpful in people's daily lives."
                  </p>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
                      <Users className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold">The Mindful Focus Team</p>
                      <p className="text-sm text-muted-foreground">Cognitive Wellness Experts</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Brain className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                    </div>
                    <h3 className="font-semibold mb-2">Neuroscience Experts</h3>
                    <p className="text-sm text-muted-foreground">
                      PhD researchers with expertise in cognitive neuroscience, neuroplasticity, and brain imaging
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Heart className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                    </div>
                    <h3 className="font-semibold mb-2">Clinical Psychologists</h3>
                    <p className="text-sm text-muted-foreground">
                      Licensed practitioners specializing in cognitive behavioral therapy and mindfulness interventions
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Lightbulb className="w-8 h-8 text-green-600 dark:text-green-400" />
                    </div>
                    <h3 className="font-semibold mb-2">Technology Innovators</h3>
                    <p className="text-sm text-muted-foreground">
                      Engineers and designers creating intuitive, accessible, and scientifically-grounded digital experiences
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Join Us in Advancing Cognitive Wellness
          </h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Whether you're a researcher, clinician, or someone interested in optimizing your cognitive performance, 
            we invite you to be part of this important work.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild className="text-lg px-8 py-6">
              <Link href="/journal">
                <Brain className="w-5 h-5 mr-2" />
                Try Our Platform
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="text-lg px-8 py-6 border-white text-white hover:bg-white hover:text-purple-600">
              <Link href="/pricing">
                <Users className="w-5 h-5 mr-2" />
                Learn More
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}