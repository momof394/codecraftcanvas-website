import { useRoute } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { 
  Calendar, 
  Clock, 
  Share2, 
  Bookmark, 
  ThumbsUp, 
  MessageCircle,
  ArrowLeft,
  Twitter,
  Linkedin,
  Facebook
} from "lucide-react";
import { Link } from "wouter";

const blogPosts = {
  "ai-design-workflows": {
    title: "The Future of Digital Design: AI-Powered Creative Workflows",
    subtitle: "How artificial intelligence is revolutionizing creative productivity and design processes",
    author: "Sarah Chen",
    role: "Design Director",
    publishDate: "December 15, 2023",
    readTime: "8 min read",
    category: "Design Technology",
    tags: ["AI", "Design", "Productivity", "Automation"],
    content: `
      <p>The landscape of digital design is undergoing a profound transformation. As artificial intelligence becomes increasingly sophisticated, we're witnessing a fundamental shift in how creators approach their work, streamline their processes, and push the boundaries of what's possible in digital creativity.</p>

      <h2>The Evolution of Design Tools</h2>
      <p>Traditional design workflows have long been constrained by time-intensive manual processes. Designers spend countless hours on repetitive tasks: resizing assets, maintaining brand consistency, organizing files, and adapting designs for multiple formats. This paradigm is rapidly changing as AI-powered tools emerge to handle these routine operations, freeing creators to focus on conceptual and strategic work.</p>

      <p>Modern AI design assistants can now intelligently suggest layout improvements, automatically generate color palettes that align with brand guidelines, and even create entire design variations based on a single concept. These capabilities represent more than mere automation—they constitute a genuine partnership between human creativity and machine intelligence.</p>

      <h2>Intelligent Asset Management</h2>
      <p>One of the most significant impacts of AI in design workflows is in asset management. Traditional approaches to organizing design files, fonts, images, and resources have relied heavily on manual categorization and folder structures. AI-powered systems can now automatically tag, categorize, and organize design assets based on visual content, style characteristics, and usage patterns.</p>

      <p>This intelligent organization extends beyond simple file management. Advanced systems can suggest appropriate assets for specific projects, identify similar design elements across different projects, and even predict which resources will be needed based on project parameters. The result is a dramatic reduction in time spent searching for and organizing creative resources.</p>

      <h2>Automated Design Optimization</h2>
      <p>Performance optimization has become crucial in digital design, particularly for web and mobile applications. AI-powered tools can now automatically optimize designs for different screen sizes, device capabilities, and performance requirements. This includes intelligent compression of images, automatic responsive layout adjustments, and real-time performance monitoring.</p>

      <p>Beyond technical optimization, AI can analyze user interaction patterns to suggest design improvements that enhance user experience. This data-driven approach to design optimization provides insights that would be impossible to gather through traditional methods.</p>

      <h2>Collaborative Intelligence</h2>
      <p>Team collaboration in design projects has been enhanced significantly through AI-powered platforms. These systems can automatically merge design contributions from multiple team members, identify conflicting changes, and suggest resolutions. Version control becomes more intuitive as AI can track design evolution and provide meaningful summaries of changes across iterations.</p>

      <p>Real-time collaboration features powered by AI can also provide instant feedback on design consistency, brand compliance, and technical feasibility. This immediate feedback loop accelerates the design process and reduces the need for extensive revision cycles.</p>

      <h2>The Human Element Remains Central</h2>
      <p>While AI transforms the technical aspects of design workflows, the core creative process remains fundamentally human. The most successful AI-powered design tools amplify human creativity rather than replace it. They handle routine tasks efficiently while providing designers with more time and mental space for conceptual thinking, strategic planning, and creative exploration.</p>

      <p>The future of design lies not in choosing between human creativity and artificial intelligence, but in creating seamless partnerships that leverage the strengths of both. As these tools continue to evolve, we can expect even more sophisticated assistance that enhances rather than diminishes the uniquely human aspects of creative work.</p>

      <h2>Looking Forward</h2>
      <p>The integration of AI into design workflows represents just the beginning of a broader transformation in creative industries. As these technologies mature, we anticipate even more intelligent assistance in areas such as concept generation, user research analysis, and predictive design trends.</p>

      <p>For designers and creative professionals, adapting to these changes isn't optional—it's essential for remaining competitive and relevant in an evolving industry. The organizations and individuals who embrace AI-powered workflows today will be best positioned to lead the creative industries of tomorrow.</p>
    `,
    imageUrl: "/api/placeholder/800/400"
  }
};

export default function BlogPostPage() {
  const [, params] = useRoute("/blog/:id");
  const postId = params?.id || "ai-design-workflows";
  const post = blogPosts[postId as keyof typeof blogPosts] || blogPosts["ai-design-workflows"];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="py-8 px-4 sm:px-6 lg:px-8 border-b">
        <div className="max-w-4xl mx-auto">
          <Link href="/blog">
            <Button variant="ghost" className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Button>
          </Link>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Badge variant="secondary">{post.category}</Badge>
              {post.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold text-foreground leading-tight">
              {post.title}
            </h1>
            
            <p className="text-xl text-muted-foreground">
              {post.subtitle}
            </p>
            
            <div className="flex items-center justify-between pt-4">
              <div className="flex items-center space-x-4">
                <Avatar className="w-12 h-12">
                  <AvatarImage src="/api/placeholder/48/48" />
                  <AvatarFallback>{post.author.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">{post.author}</p>
                  <p className="text-sm text-muted-foreground">{post.role}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>{post.publishDate}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{post.readTime}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Article Content */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <article className="lg:col-span-3">
              {/* Featured Image */}
              <div className="mb-8">
                <div className="aspect-video bg-gradient-to-br from-purple-400 to-indigo-600 rounded-lg"></div>
              </div>
              
              {/* Article Body */}
              <div 
                className="prose prose-lg max-w-none dark:prose-invert"
                dangerouslySetInnerHTML={{ __html: post.content }}
              />
              
              {/* Article Footer */}
              <div className="mt-12 pt-8 border-t">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Button variant="outline" size="sm">
                      <ThumbsUp className="w-4 h-4 mr-2" />
                      Like (24)
                    </Button>
                    <Button variant="outline" size="sm">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Comment (8)
                    </Button>
                    <Button variant="outline" size="sm">
                      <Bookmark className="w-4 h-4 mr-2" />
                      Save
                    </Button>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground mr-2">Share:</span>
                    <Button variant="ghost" size="sm">
                      <Twitter className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Linkedin className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Facebook className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Author Bio */}
              <Card className="mt-8">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <Avatar className="w-16 h-16">
                      <AvatarImage src="/api/placeholder/64/64" />
                      <AvatarFallback>{post.author.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold">{post.author}</h3>
                      <p className="text-muted-foreground mb-2">{post.role}</p>
                      <p className="text-sm leading-relaxed">
                        Sarah is a seasoned design director with over 10 years of experience in digital product design. 
                        She specializes in AI-powered design tools and has led design teams at several Fortune 500 companies. 
                        Sarah is passionate about the intersection of technology and creativity.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </article>
            
            {/* Sidebar */}
            <aside className="space-y-6">
              {/* Table of Contents */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Table of Contents</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li><a href="#evolution" className="text-purple-600 hover:text-purple-800">The Evolution of Design Tools</a></li>
                    <li><a href="#asset-management" className="text-purple-600 hover:text-purple-800">Intelligent Asset Management</a></li>
                    <li><a href="#optimization" className="text-purple-600 hover:text-purple-800">Automated Design Optimization</a></li>
                    <li><a href="#collaboration" className="text-purple-600 hover:text-purple-800">Collaborative Intelligence</a></li>
                    <li><a href="#human-element" className="text-purple-600 hover:text-purple-800">The Human Element</a></li>
                    <li><a href="#future" className="text-purple-600 hover:text-purple-800">Looking Forward</a></li>
                  </ul>
                </CardContent>
              </Card>
              
              {/* Related Articles */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Related Articles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-l-2 border-purple-200 pl-4">
                      <h4 className="font-medium text-sm mb-1">
                        <a href="#" className="hover:text-purple-600">
                          Building Responsive Design Systems
                        </a>
                      </h4>
                      <p className="text-xs text-muted-foreground">
                        Learn how to create scalable design systems that work across all devices.
                      </p>
                    </div>
                    <div className="border-l-2 border-purple-200 pl-4">
                      <h4 className="font-medium text-sm mb-1">
                        <a href="#" className="hover:text-purple-600">
                          Color Theory for Digital Interfaces
                        </a>
                      </h4>
                      <p className="text-xs text-muted-foreground">
                        Master the psychology and application of color in user interface design.
                      </p>
                    </div>
                    <div className="border-l-2 border-purple-200 pl-4">
                      <h4 className="font-medium text-sm mb-1">
                        <a href="#" className="hover:text-purple-600">
                          Accessibility in Modern Design
                        </a>
                      </h4>
                      <p className="text-xs text-muted-foreground">
                        Essential principles for creating inclusive digital experiences.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Newsletter Signup */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Stay Updated</CardTitle>
                  <CardDescription>
                    Get the latest design insights and tutorials delivered to your inbox.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <input 
                      type="email" 
                      placeholder="Enter your email"
                      className="w-full px-3 py-2 border rounded-md text-sm"
                    />
                    <Button className="w-full" size="sm">
                      Subscribe
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
}