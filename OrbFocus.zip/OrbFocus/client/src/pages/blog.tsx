import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Calendar, 
  Clock, 
  User, 
  ArrowRight, 
  Search,
  Brain,
  Lightbulb,
  Target,
  Heart,
  Zap,
  BookOpen
} from "lucide-react";
import { Link } from "wouter";

export default function BlogPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const blogPosts = [
    {
      id: 1,
      title: "The Future of Digital Design: AI-Powered Creative Workflows",
      excerpt: "How artificial intelligence is revolutionizing creative productivity and design processes for modern teams and individual creators.",
      content: "AI-powered design tools are transforming how we approach creative work. From intelligent layout suggestions to automated asset management, these technologies enable designers to focus on strategic thinking while handling routine tasks efficiently. This comprehensive guide explores the latest AI design tools and how to integrate them into your creative workflow for maximum productivity.",
      author: "Sarah Chen",
      date: "2025-01-28",
      readTime: "8 min read",
      category: "Design Technology",
      tags: ["ai", "design-tools", "productivity", "workflow"],
      featured: true
    },
    {
      id: 2,
      title: "Building Responsive Design Systems That Scale",
      excerpt: "Learn how to create comprehensive design systems that maintain consistency across all devices and platforms while enabling rapid development.",
      content: "A well-designed design system is the foundation of successful digital products. It ensures consistency, accelerates development, and improves user experience across all touchpoints. This article covers the essential components of scalable design systems, from typography and color palettes to component libraries and documentation strategies that keep teams aligned and productive.",
      author: "Michael Rodriguez",
      date: "2025-01-25",
      readTime: "10 min read",
      category: "Design Systems",
      tags: ["design-systems", "scalability", "consistency", "development"],
      featured: true
    },
    {
      id: 3,
      title: "Color Theory for Digital Interfaces",
      excerpt: "Master the psychology and application of color in user interface design to create more engaging and accessible digital experiences.",
      content: "Color is one of the most powerful tools in a designer's arsenal. It influences emotions, guides user attention, and communicates brand values. This comprehensive guide explores color theory fundamentals, accessibility considerations, and practical techniques for creating effective color palettes for digital products. Learn how to use color strategically to enhance user experience and drive engagement.",
      author: "Emily Watson",
      date: "2025-01-22",
      readTime: "12 min read",
      category: "UI Design",
      tags: ["color-theory", "ui-design", "accessibility", "user-experience"],
      featured: false
    },
    {
      id: 4,
      title: "Typography That Converts: A Designer's Guide",
      excerpt: "Learn how strategic typography choices can improve readability, enhance user experience, and drive better business outcomes.",
      content: "Typography is more than just choosing pretty fonts—it's about creating clear communication that guides users through your digital experience. This guide covers typography fundamentals, web font optimization, hierarchy principles, and accessibility considerations. Discover how the right typography choices can significantly impact user engagement and conversion rates.",
      author: "James Liu",
      date: "2025-01-20",
      readTime: "7 min read",
      category: "Typography",
      tags: ["typography", "user-experience", "conversion", "accessibility"],
      featured: false
    },
    {
      id: 5,
      title: "Accessibility in Modern Design: Beyond Compliance",
      excerpt: "Creating inclusive digital experiences that work for everyone while driving business value and user satisfaction.",
      content: "Accessibility isn't just about compliance—it's about creating better experiences for all users. This comprehensive guide covers modern accessibility practices, from color contrast and keyboard navigation to screen reader optimization and cognitive accessibility. Learn how inclusive design principles can expand your audience and improve overall user experience.",
      author: "Rachel Kim",
      date: "2025-01-18",
      readTime: "9 min read",
      category: "Accessibility",
      tags: ["accessibility", "inclusive-design", "user-experience", "compliance"],
      featured: false
    },
    {
      id: 6,
      title: "The Future of Design Tools: What's Next for Creators",
      excerpt: "Exploring emerging technologies and trends that are shaping the next generation of digital design and creative tools.",
      content: "The design tool landscape is evolving rapidly, with new technologies opening unprecedented possibilities for creative expression and workflow optimization. From AI-powered design assistants to collaborative virtual reality environments, this article explores cutting-edge developments shaping the future of digital creativity. We'll examine emerging trends, innovative tools, and how they'll impact the way designers work in the coming years.",
      author: "Alex Thompson",
      date: "2025-01-15",
      readTime: "11 min read",
      category: "Design Trends",
      tags: ["design-tools", "innovation", "future-trends", "technology"],
      featured: false
    }
  ];

  const categories = ["All", "Design Technology", "Design Systems", "UI Design", "Typography", "Accessibility", "Design Trends"];
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === "All" || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredPosts = blogPosts.filter(post => post.featured);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Design & Productivity Insights
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Professional design articles, industry insights, and practical strategies for optimizing 
            your creative workflow and digital productivity.
          </p>
          
          {/* Search */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 px-4 sm:px-6 lg:px-8 border-b">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="mb-2"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Articles */}
      {selectedCategory === "All" && searchTerm === "" && (
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Featured Articles</h2>
            <div className="grid md:grid-cols-2 gap-8">
              {featuredPosts.map((post) => (
                <Card key={post.id} className="border-2 border-purple-200 dark:border-purple-800 hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary" className="bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                        <BookOpen className="w-3 h-3 mr-1" />
                        {post.category}
                      </Badge>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="w-4 h-4 mr-1" />
                        {post.readTime}
                      </div>
                    </div>
                    <CardTitle className="text-xl hover:text-purple-600 transition-colors">
                      <Link href={`/blog/${post.id}`}>
                        {post.title}
                      </Link>
                    </CardTitle>
                    <CardDescription className="text-base">
                      {post.excerpt}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <User className="w-4 h-4 mr-1" />
                        {post.author}
                        <span className="mx-2">•</span>
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(post.date).toLocaleDateString()}
                      </div>
                      <Button variant="ghost" size="sm" asChild>
                        <Link href={`/blog/${post.id}`}>
                          Read More
                          <ArrowRight className="w-4 h-4 ml-1" />
                        </Link>
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-4">
                      {post.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Articles */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-foreground">
              {selectedCategory === "All" ? "All Articles" : `${selectedCategory} Articles`}
            </h2>
            <div className="text-sm text-muted-foreground">
              {filteredPosts.length} article{filteredPosts.length !== 1 ? 's' : ''} found
            </div>
          </div>

          <div className="grid gap-8">
            {filteredPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <Badge variant="secondary" className={`
                          ${post.category === 'Neuroscience' ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300' : ''}
                          ${post.category === 'Brain Science' ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300' : ''}
                          ${post.category === 'Cognitive Skills' ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' : ''}
                          ${post.category === 'Digital Wellness' ? 'bg-orange-100 dark:bg-orange-900 text-orange-700 dark:text-orange-300' : ''}
                          ${post.category === 'Stress Management' ? 'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300' : ''}
                          ${post.category === 'Future Technology' ? 'bg-cyan-100 dark:bg-cyan-900 text-cyan-700 dark:text-cyan-300' : ''}
                        `}>
                          <Brain className="w-3 h-3 mr-1" />
                          {post.category}
                        </Badge>
                        {post.featured && (
                          <Badge variant="default" className="bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300">
                            Featured
                          </Badge>
                        )}
                      </div>
                      
                      <h3 className="text-2xl font-bold mb-3 hover:text-purple-600 transition-colors">
                        <Link href={`/blog/${post.id}`}>
                          {post.title}
                        </Link>
                      </h3>
                      
                      <p className="text-muted-foreground mb-4 leading-relaxed">
                        {post.excerpt}
                      </p>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        {post.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-muted-foreground">
                          <User className="w-4 h-4 mr-2" />
                          {post.author}
                          <span className="mx-3">•</span>
                          <Calendar className="w-4 h-4 mr-2" />
                          {new Date(post.date).toLocaleDateString()}
                          <span className="mx-3">•</span>
                          <Clock className="w-4 h-4 mr-2" />
                          {post.readTime}
                        </div>
                        
                        <Button variant="ghost" asChild>
                          <Link href={`/blog/${post.id}`}>
                            Read Article
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="text-center py-16">
              <Brain className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No articles found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your search terms or browse different categories
              </p>
              <Button onClick={() => { setSearchTerm(""); setSelectedCategory("All"); }}>
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Stay Updated with Latest Research
          </h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Get weekly insights on cognitive wellness, neuroscience breakthroughs, 
            and evidence-based strategies delivered to your inbox.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Input 
              placeholder="Enter your email" 
              className="bg-white/10 border-white/30 text-white placeholder:text-white/70"
            />
            <Button size="lg" variant="secondary" className="text-purple-600 font-semibold">
              Subscribe
            </Button>
          </div>
          <p className="text-sm opacity-70 mt-4">
            No spam, unsubscribe anytime. Read our <Link href="/privacy" className="underline">privacy policy</Link>.
          </p>
        </div>
      </section>
    </div>
  );
}