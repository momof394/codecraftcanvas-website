import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  Check, 
  Star, 
  Zap, 
  Crown,
  Palette,
  FileImage,
  Download,
  Brush,
  Layers,
  Cloud,
  Sparkles,
  Users,
  Shield
} from "lucide-react";

export default function PricingPage() {
  const [isAnnual, setIsAnnual] = useState(false);

  const plans = [
    {
      name: "Free",
      description: "Perfect for getting started",
      price: { monthly: 0, annual: 0 },
      icon: Palette,
      badge: null,
      features: [
        "5 projects per month",
        "Basic templates",
        "Standard quality exports",
        "PNG & JPEG exports",
        "Basic shapes & icons",
        "Community support"
      ],
      limitations: [
        "Watermark on exports",
        "Limited cloud storage (100MB)",
        "No premium templates",
        "No advanced drawing tools"
      ],
      cta: "Get Started",
      popular: false
    },
    {
      name: "Pro",
      description: "For serious creators and professionals",
      price: { monthly: 19.99, annual: 89.99 },
      icon: Star,
      badge: "Most Popular",
      features: [
        "Unlimited projects",
        "All premium templates",
        "High-quality exports",
        "PDF, PNG & JPEG exports",
        "Advanced drawing tools",
        "All premium assets",
        "Procreate-style brushes",
        "Layer management",
        "Cloud sync (10GB)",
        "Priority support",
        "No watermarks",
        "Commercial license"
      ],
      limitations: [],
      cta: "Start Pro Trial",
      popular: true
    },
    {
      name: "Enterprise",
      description: "For teams and organizations",
      price: { monthly: 49.99, annual: 299.99 },
      icon: Crown,
      badge: "Best Value",
      features: [
        "Everything in Pro",
        "Team collaboration",
        "Unlimited cloud storage",
        "Brand kit & templates",
        "Advanced export options",
        "API access",
        "Custom integrations",
        "Dedicated support",
        "Usage analytics",
        "Admin dashboard",
        "Single sign-on (SSO)",
        "Custom branding"
      ],
      limitations: [],
      cta: "Contact Sales",
      popular: false
    }
  ];

  const getPrice = (plan: any) => {
    const price = isAnnual ? plan.price.annual : plan.price.monthly;
    if (price === 0) return "Free";
    if (isAnnual) return `$${price}/year`;
    return `$${price}/month`;
  };

  const getSavings = (plan: any) => {
    if (plan.price.annual === 0) return null;
    const monthlyCost = plan.price.monthly * 12;
    const savings = monthlyCost - plan.price.annual;
    return Math.round((savings / monthlyCost) * 100);
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
            Choose the perfect plan for your creative needs. Start free and upgrade as you grow.
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4">
            <span className={`text-sm ${!isAnnual ? 'text-gray-900 dark:text-white font-semibold' : 'text-gray-500'}`}>
              Monthly
            </span>
            <Switch
              checked={isAnnual}
              onCheckedChange={setIsAnnual}
            />
            <span className={`text-sm ${isAnnual ? 'text-gray-900 dark:text-white font-semibold' : 'text-gray-500'}`}>
              Annual
            </span>
            <Badge variant="secondary" className="ml-2">
              Save up to 50%
            </Badge>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const savings = getSavings(plan);
            
            return (
              <Card 
                key={plan.name} 
                className={`relative ${plan.popular ? 'border-purple-300 shadow-lg scale-105' : ''}`}
              >
                {plan.badge && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-purple-600 text-white">
                      {plan.badge}
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-4">
                  <div className={`w-12 h-12 mx-auto rounded-lg flex items-center justify-center mb-4 ${
                    plan.name === 'Pro' ? 'bg-purple-100 dark:bg-purple-900' :
                    plan.name === 'Enterprise' ? 'bg-yellow-100 dark:bg-yellow-900' :
                    'bg-gray-100 dark:bg-gray-800'
                  }`}>
                    <Icon className={`w-6 h-6 ${
                      plan.name === 'Pro' ? 'text-purple-600 dark:text-purple-400' :
                      plan.name === 'Enterprise' ? 'text-yellow-600 dark:text-yellow-400' :
                      'text-gray-600 dark:text-gray-400'
                    }`} />
                  </div>
                  
                  <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                  <CardDescription className="text-base">{plan.description}</CardDescription>
                  
                  <div className="mt-4">
                    <div className="text-4xl font-bold text-gray-900 dark:text-white">
                      {getPrice(plan)}
                    </div>
                    {isAnnual && savings && (
                      <div className="text-sm text-green-600 dark:text-green-400 font-medium">
                        Save {savings}% annually
                      </div>
                    )}
                    {!isAnnual && plan.price.monthly > 0 && (
                      <div className="text-sm text-gray-500">
                        billed monthly
                      </div>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent>
                  <Button 
                    className={`w-full mb-6 ${plan.popular ? 'bg-purple-600 hover:bg-purple-700' : ''}`}
                    variant={plan.popular ? "default" : "outline"}
                  >
                    {plan.cta}
                  </Button>
                  
                  <div className="space-y-3">
                    <h4 className="font-semibold text-gray-900 dark:text-white">
                      What's included:
                    </h4>
                    <ul className="space-y-2">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <Check className="w-4 h-4 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-gray-600 dark:text-gray-300">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    {plan.limitations.length > 0 && (
                      <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                        <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                          Limitations:
                        </h4>
                        <ul className="space-y-1">
                          {plan.limitations.map((limitation, index) => (
                            <li key={index} className="text-sm text-gray-500 dark:text-gray-400">
                              • {limitation}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Feature Comparison */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-8">
            Compare Features
          </h2>
          
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700">
                      <th className="text-left p-4 font-semibold text-gray-900 dark:text-white">
                        Features
                      </th>
                      <th className="text-center p-4 font-semibold text-gray-900 dark:text-white">
                        Free
                      </th>
                      <th className="text-center p-4 font-semibold text-gray-900 dark:text-white">
                        Pro
                      </th>
                      <th className="text-center p-4 font-semibold text-gray-900 dark:text-white">
                        Enterprise
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { feature: "Projects per month", free: "5", pro: "Unlimited", enterprise: "Unlimited" },
                      { feature: "Premium templates", free: "❌", pro: "✅", enterprise: "✅" },
                      { feature: "HD exports", free: "❌", pro: "✅", enterprise: "✅" },
                      { feature: "No watermarks", free: "❌", pro: "✅", enterprise: "✅" },
                      { feature: "Cloud storage", free: "100MB", pro: "10GB", enterprise: "Unlimited" },
                      { feature: "Advanced drawing tools", free: "❌", pro: "✅", enterprise: "✅" },
                      { feature: "Team collaboration", free: "❌", pro: "❌", enterprise: "✅" },
                      { feature: "API access", free: "❌", pro: "❌", enterprise: "✅" },
                      { feature: "Priority support", free: "❌", pro: "✅", enterprise: "✅" },
                    ].map((row, index) => (
                      <tr key={index} className="border-b border-gray-100 dark:border-gray-800">
                        <td className="p-4 text-gray-900 dark:text-white font-medium">
                          {row.feature}
                        </td>
                        <td className="p-4 text-center text-gray-600 dark:text-gray-300">
                          {row.free}
                        </td>
                        <td className="p-4 text-center text-gray-600 dark:text-gray-300">
                          {row.pro}
                        </td>
                        <td className="p-4 text-center text-gray-600 dark:text-gray-300">
                          {row.enterprise}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-8">
            Frequently Asked Questions
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                question: "Can I cancel my subscription anytime?",
                answer: "Yes, you can cancel your subscription at any time. You'll continue to have access to Pro features until the end of your billing period."
              },
              {
                question: "Do you offer refunds?",
                answer: "We offer a 30-day money-back guarantee for all paid plans. If you're not satisfied, contact us for a full refund."
              },
              {
                question: "What's included in the free plan?",
                answer: "The free plan includes 5 projects per month, basic templates, standard exports, and access to basic design tools with watermarks."
              },
              {
                question: "Can I upgrade or downgrade my plan?",
                answer: "Yes, you can change your plan at any time. Upgrades take effect immediately, and downgrades take effect at your next billing cycle."
              },
              {
                question: "Do you offer educational discounts?",
                answer: "Yes, we offer 50% discounts for students and educators. Contact us with proof of enrollment or employment for verification."
              },
              {
                question: "What file formats can I export?",
                answer: "Free users can export PNG and JPEG. Pro and Enterprise users can export PDF, PNG, and JPEG in high quality without watermarks."
              }
            ].map((faq, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-lg">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-purple-600 to-blue-600 border-0">
            <CardContent className="p-8 text-white">
              <h2 className="text-3xl font-bold mb-4">
                Ready to start creating?
              </h2>
              <p className="text-xl mb-8 opacity-90">
                Join thousands of creators who trust Vision for Web to bring their ideas to life.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" variant="secondary" asChild>
                  <Link href="/editor">
                    <Zap className="w-5 h-5 mr-2" />
                    Start Creating Free
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-purple-600">
                  Contact Sales
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}