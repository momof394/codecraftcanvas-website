import EnhancedJournal from "@/components/enhanced-journal";

export default function JournalPage() {
  return <EnhancedJournal />;
}