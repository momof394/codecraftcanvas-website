import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Shield } from "lucide-react";
import { Link } from "wouter";

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen p-4 relative">
      {/* Nature Background */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-gradient-to-br from-pink-300 to-rose-200 blur-xl gentle-sway"></div>
        <div className="absolute bottom-1/4 right-1/4 w-40 h-40 rounded-full bg-gradient-to-br from-green-200 to-emerald-200 blur-2xl gentle-sway"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 fixed-layout"
        >
          <div className="flex items-center justify-between mb-6">
            <Link href="/">
              <Button variant="outline" className="glass-effect safe-spacing">
                <ArrowLeft size={16} className="mr-2" />
                Back to Garden
              </Button>
            </Link>
            <div className="flex-1 text-center">
              <div className="inline-flex items-center gap-3 mb-2">
                <Shield className="text-emerald-600" size={32} />
                <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  Privacy Policy
                </h1>
              </div>
              <p className="text-gray-600">Your privacy and wellness data protection</p>
            </div>
            <div className="w-24"></div>
          </div>
        </motion.div>

        {/* Privacy Policy Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="glass-effect border-emerald-200/30 shadow-2xl backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl text-center text-emerald-700">
                🌿 Mindfulfocusorb Privacy Policy
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-green max-w-none">
              <div className="space-y-6 text-gray-700 leading-relaxed">

                <section>
                  <h2 className="text-xl font-semibold text-emerald-700 mb-4">Security Policy</h2>
                  
                  <h3 className="text-lg font-medium text-emerald-600 mb-3">Supported Versions</h3>
                  <p className="mb-4">
                    The following versions of our Mindfulfocusorb project are currently being supported with security updates:
                  </p>
                  
                  <div className="bg-white/70 rounded-lg p-4 mb-6">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b border-emerald-200">
                          <th className="text-left py-2 px-4 font-medium">Version</th>
                          <th className="text-left py-2 px-4 font-medium">Supported</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-emerald-100">
                          <td className="py-2 px-4">5.1.x</td>
                          <td className="py-2 px-4 text-green-600 font-medium">✅ Supported</td>
                        </tr>
                        <tr className="border-b border-emerald-100">
                          <td className="py-2 px-4">5.0.x</td>
                          <td className="py-2 px-4 text-red-600 font-medium">❌ Not Supported</td>
                        </tr>
                        <tr className="border-b border-emerald-100">
                          <td className="py-2 px-4">4.0.x</td>
                          <td className="py-2 px-4 text-green-600 font-medium">✅ Supported</td>
                        </tr>
                        <tr>
                          <td className="py-2 px-4">&lt; 4.0</td>
                          <td className="py-2 px-4 text-red-600 font-medium">❌ Not Supported</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <h3 className="text-lg font-medium text-emerald-600 mb-3">Reporting a Vulnerability</h3>
                  <p className="mb-4">
                    We take security seriously and appreciate your help in keeping Mindfulfocusorb safe for all users. If you discover a security vulnerability, please follow these guidelines:
                  </p>
                  
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 mb-4">
                    <ul className="space-y-2 text-emerald-800">
                      <li>• Report vulnerabilities through our secure reporting system</li>
                      <li>• Expect regular updates on reported vulnerabilities</li>
                      <li>• We will communicate acceptance or decline of reported issues</li>
                      <li>• Response times vary based on severity and complexity</li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-emerald-700 mb-3">Data Protection</h2>
                  <p>
                    Mindfulfocusorb prioritizes your privacy and mental health data security. All journal entries, mood tracking, and therapy session data are stored locally in your browser using localStorage technology, ensuring your personal wellness information never leaves your device.
                  </p>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-emerald-700 mb-3">Local Data Storage</h2>
                  <p>
                    Our application uses browser localStorage to maintain your wellness data privately on your device. This means:
                  </p>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>No personal data is transmitted to external servers</li>
                    <li>Your journal entries remain completely private</li>
                    <li>Mood tracking data stays on your device</li>
                    <li>AI therapy conversations are processed locally when possible</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-emerald-700 mb-3">Your Rights</h2>
                  <p>
                    As a user of Mindfulfocusorb, you have complete control over your data:
                  </p>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Access and modify your wellness data at any time</li>
                    <li>Export your journal entries and mood tracking data</li>
                    <li>Delete all stored data from your browser</li>
                    <li>Use the application offline after initial load</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-xl font-semibold text-emerald-700 mb-3">Contact Information</h2>
                  <p>
                    For security concerns, privacy questions, or vulnerability reports, please reach out through our support channels. We are committed to maintaining a safe and secure environment for your mental wellness journey.
                  </p>
                </section>

                <div className="border-t border-emerald-200 pt-6 mt-8">
                  <p className="text-sm text-gray-500 text-center">
                    Last updated: January 2025 | Mindfulfocusorb Security Policy
                  </p>
                </div>

              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Back to Garden Button */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-center mt-8"
        >
          <Link href="/">
            <Button className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 safe-spacing">
              🌸 Return to Your Wellness Garden
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}