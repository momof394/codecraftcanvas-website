import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Download, 
  ExternalLink, 
  BookOpen, 
  Video, 
  Headphones, 
  FileText,
  Brain,
  Target,
  Heart,
  Lightbulb,
  Users,
  Clock,
  Star,
  PlayCircle
} from "lucide-react";
import { Link } from "wouter";

export default function ResourcesPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const resources = {
    guides: [
      {
        id: 1,
        title: "Complete Guide to Cognitive Assessment",
        description: "Comprehensive overview of cognitive assessment tools, interpretation guidelines, and practical applications for personal development.",
        downloadUrl: "#",
        fileSize: "2.4 MB",
        pages: 45,
        category: "Assessment",
        difficulty: "Beginner",
        estimatedTime: "60 minutes",
        featured: true
      },
      {
        id: 2,
        title: "Executive Function Training Manual",
        description: "Evidence-based exercises and strategies for improving working memory, cognitive flexibility, and inhibitory control.",
        downloadUrl: "#",
        fileSize: "3.1 MB", 
        pages: 68,
        category: "Training",
        difficulty: "Intermediate",
        estimatedTime: "90 minutes",
        featured: true
      },
      {
        id: 3,
        title: "Mindfulness for Cognitive Wellness",
        description: "Practical mindfulness techniques specifically designed to enhance cognitive function and reduce mental fatigue.",
        downloadUrl: "#",
        fileSize: "1.8 MB",
        pages: 32,
        category: "Mindfulness",
        difficulty: "Beginner",
        estimatedTime: "45 minutes",
        featured: false
      },
      {
        id: 4,
        title: "Neuroplasticity and Lifestyle Optimization",
        description: "Science-backed strategies for enhancing brain plasticity through nutrition, exercise, sleep, and cognitive training.",
        downloadUrl: "#",
        fileSize: "4.2 MB",
        pages: 89,
        category: "Lifestyle",
        difficulty: "Advanced",
        estimatedTime: "120 minutes",
        featured: false
      }
    ],
    videos: [
      {
        id: 1,
        title: "Understanding Your Cognitive Profile",
        description: "Learn how to interpret cognitive assessment results and develop personalized improvement strategies.",
        duration: "28:45",
        videoUrl: "#",
        thumbnail: "/api/placeholder/320/180",
        category: "Assessment",
        difficulty: "Beginner",
        views: 15420,
        featured: true
      },
      {
        id: 2,
        title: "Advanced Attention Training Techniques",
        description: "Master sophisticated attention training exercises used by cognitive researchers and clinicians.",
        duration: "42:15",
        videoUrl: "#",
        thumbnail: "/api/placeholder/320/180",
        category: "Training",
        difficulty: "Advanced",
        views: 8930,
        featured: true
      },
      {
        id: 3,
        title: "Building Cognitive Resilience",
        description: "Strategies for maintaining cognitive performance under stress and challenging conditions.",
        duration: "35:22",
        videoUrl: "#",
        thumbnail: "/api/placeholder/320/180",
        category: "Resilience",
        difficulty: "Intermediate",
        views: 12150,
        featured: false
      },
      {
        id: 4,
        title: "The Science of Cognitive Load",
        description: "Deep dive into cognitive load theory and its practical applications for learning and productivity.",
        duration: "51:30",
        videoUrl: "#",
        thumbnail: "/api/placeholder/320/180",
        category: "Science",
        difficulty: "Advanced",
        views: 6780,
        featured: false
      }
    ],
    podcasts: [
      {
        id: 1,
        title: "Cognitive Wellness Weekly",
        description: "Weekly conversations with leading researchers, clinicians, and practitioners in the field of cognitive wellness.",
        episodes: 47,
        duration: "30-45 min",
        podcastUrl: "#",
        category: "Research",
        rating: 4.8,
        featured: true
      },
      {
        id: 2,
        title: "The Neuroscience Hour",
        description: "In-depth discussions about the latest neuroscience research and its implications for cognitive enhancement.",
        episodes: 32,
        duration: "60 min",
        podcastUrl: "#",
        category: "Science",
        rating: 4.9,
        featured: true
      },
      {
        id: 3,
        title: "Mindful Productivity",
        description: "Practical strategies for optimizing cognitive performance in work and daily life through mindful practices.",
        episodes: 28,
        duration: "25-35 min",
        podcastUrl: "#",
        category: "Productivity",
        rating: 4.7,
        featured: false
      }
    ],
    research: [
      {
        id: 1,
        title: "Meta-Analysis: Cognitive Training Effectiveness",
        description: "Comprehensive analysis of 127 studies examining the effectiveness of various cognitive training interventions.",
        authors: "Dr. Sarah Chen, Dr. Michael Rodriguez, Dr. Emily Watson",
        journal: "Journal of Cognitive Enhancement",
        year: 2024,
        doi: "10.1001/jce.2024.0123",
        downloadUrl: "#",
        category: "Training",
        openAccess: true,
        featured: true
      },
      {
        id: 2,
        title: "Neuroplasticity Mechanisms in Adult Learning",
        description: "Novel findings on the cellular and molecular mechanisms underlying adult neuroplasticity and cognitive improvement.",
        authors: "Dr. Alex Thompson, Dr. Rachel Kim",
        journal: "Nature Neuroscience",
        year: 2024,
        doi: "10.1038/nn.2024.456",
        downloadUrl: "#",
        category: "Neuroscience",
        openAccess: false,
        featured: true
      },
      {
        id: 3,
        title: "Digital Therapeutics for Executive Function",
        description: "Clinical trial results demonstrating the efficacy of digital interventions for executive function disorders.",
        authors: "Dr. James Liu, Dr. Maria Santos",
        journal: "Digital Medicine",
        year: 2024,
        doi: "10.1016/dm.2024.789",
        downloadUrl: "#",
        category: "Digital Health",
        openAccess: true,
        featured: false
      }
    ],
    tools: [
      {
        id: 1,
        title: "Cognitive Assessment Battery",
        description: "Comprehensive suite of validated cognitive assessments for attention, memory, and executive function.",
        type: "Assessment Tool",
        platform: "Web Application",
        accessUrl: "#",
        category: "Assessment",
        pricing: "Free",
        featured: true
      },
      {
        id: 2,
        title: "Attention Training Simulator",
        description: "Adaptive training program that adjusts difficulty based on your performance to optimize cognitive gains.",
        type: "Training Platform",
        platform: "Web & Mobile",
        accessUrl: "#",
        category: "Training",
        pricing: "Premium",
        featured: true
      },
      {
        id: 3,
        title: "Cognitive Load Calculator",
        description: "Tool for analyzing and optimizing cognitive load in learning materials and work environments.",
        type: "Analysis Tool",
        platform: "Web Application",
        accessUrl: "#",
        category: "Analysis",
        pricing: "Free",
        featured: false
      }
    ]
  };

  const categories = ["All", "Assessment", "Training", "Mindfulness", "Science", "Research", "Productivity"];
  const [selectedCategory, setSelectedCategory] = useState("All");

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Cognitive Wellness Resources
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Comprehensive collection of evidence-based resources to support your cognitive wellness journey. 
            From research papers to practical guides, everything you need for cognitive optimization.
          </p>
          
          {/* Search */}
          <div className="max-w-md mx-auto relative mb-8">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search resources..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="mb-2"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Resource Tabs */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <Tabs defaultValue="guides" className="w-full">
            <TabsList className="grid w-full grid-cols-5 mb-8">
              <TabsTrigger value="guides" className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Guides
              </TabsTrigger>
              <TabsTrigger value="videos" className="flex items-center gap-2">
                <Video className="w-4 h-4" />
                Videos
              </TabsTrigger>
              <TabsTrigger value="podcasts" className="flex items-center gap-2">
                <Headphones className="w-4 h-4" />
                Podcasts
              </TabsTrigger>
              <TabsTrigger value="research" className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                Research
              </TabsTrigger>
              <TabsTrigger value="tools" className="flex items-center gap-2">
                <Brain className="w-4 h-4" />
                Tools
              </TabsTrigger>
            </TabsList>

            {/* Guides Tab */}
            <TabsContent value="guides">
              <div className="grid md:grid-cols-2 gap-6">
                {resources.guides.map((guide) => (
                  <Card key={guide.id} className={`${guide.featured ? 'border-2 border-purple-200 dark:border-purple-800' : ''} hover:shadow-lg transition-shadow`}>
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300">
                          <FileText className="w-3 h-3 mr-1" />
                          {guide.category}
                        </Badge>
                        {guide.featured && (
                          <Badge variant="default" className="bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300">
                            Featured
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="text-xl">{guide.title}</CardTitle>
                      <CardDescription>{guide.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <span>{guide.pages} pages</span>
                          <span>{guide.fileSize}</span>
                          <span>{guide.estimatedTime}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <Badge variant="outline" className="text-xs">
                            {guide.difficulty}
                          </Badge>
                          <Button size="sm">
                            <Download className="w-4 h-4 mr-2" />
                            Download PDF
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Videos Tab */}
            <TabsContent value="videos">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {resources.videos.map((video) => (
                  <Card key={video.id} className={`${video.featured ? 'border-2 border-purple-200 dark:border-purple-800' : ''} hover:shadow-lg transition-shadow`}>
                    <CardContent className="p-0">
                      <div className="relative">
                        <div className="w-full h-48 bg-gradient-to-br from-purple-100 to-blue-100 dark:from-purple-900 to-blue-900 flex items-center justify-center">
                          <PlayCircle className="w-16 h-16 text-purple-600 dark:text-purple-400" />
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 rounded text-sm">
                          {video.duration}
                        </div>
                        {video.featured && (
                          <Badge className="absolute top-2 left-2 bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300">
                            Featured
                          </Badge>
                        )}
                      </div>
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="secondary" className="text-xs">
                            {video.category}
                          </Badge>
                          <div className="flex items-center text-xs text-muted-foreground">
                            <Users className="w-3 h-3 mr-1" />
                            {video.views.toLocaleString()}
                          </div>
                        </div>
                        <h3 className="font-semibold mb-2">{video.title}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{video.description}</p>
                        <div className="flex items-center justify-between">
                          <Badge variant="outline" className="text-xs">
                            {video.difficulty}
                          </Badge>
                          <Button size="sm">
                            <PlayCircle className="w-4 h-4 mr-2" />
                            Watch
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Podcasts Tab */}
            <TabsContent value="podcasts">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {resources.podcasts.map((podcast) => (
                  <Card key={podcast.id} className={`${podcast.featured ? 'border-2 border-purple-200 dark:border-purple-800' : ''} hover:shadow-lg transition-shadow`}>
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300">
                          <Headphones className="w-3 h-3 mr-1" />
                          {podcast.category}
                        </Badge>
                        {podcast.featured && (
                          <Badge variant="default" className="bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300">
                            Featured
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="text-xl">{podcast.title}</CardTitle>
                      <CardDescription>{podcast.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <span>{podcast.episodes} episodes</span>
                          <span>{podcast.duration}</span>
                          <div className="flex items-center">
                            <Star className="w-4 h-4 mr-1 text-yellow-500" />
                            {podcast.rating}
                          </div>
                        </div>
                        <Button className="w-full" size="sm">
                          <Headphones className="w-4 h-4 mr-2" />
                          Listen Now
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Research Tab */}
            <TabsContent value="research">
              <div className="space-y-6">
                {resources.research.map((paper) => (
                  <Card key={paper.id} className={`${paper.featured ? 'border-2 border-purple-200 dark:border-purple-800' : ''} hover:shadow-lg transition-shadow`}>
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <Badge variant="secondary" className="bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300">
                              <BookOpen className="w-3 h-3 mr-1" />
                              {paper.category}
                            </Badge>
                            {paper.openAccess && (
                              <Badge variant="outline" className="text-green-600 border-green-600">
                                Open Access
                              </Badge>
                            )}
                            {paper.featured && (
                              <Badge variant="default" className="bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300">
                                Featured
                              </Badge>
                            )}
                          </div>
                          <h3 className="text-xl font-bold mb-2">{paper.title}</h3>
                          <p className="text-muted-foreground mb-3">{paper.description}</p>
                          <div className="text-sm text-muted-foreground mb-3">
                            <p><strong>Authors:</strong> {paper.authors}</p>
                            <p><strong>Journal:</strong> {paper.journal} ({paper.year})</p>
                            <p><strong>DOI:</strong> {paper.doi}</p>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <Button size="sm">
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                          <Button variant="outline" size="sm">
                            <ExternalLink className="w-4 h-4 mr-2" />
                            View Online
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Tools Tab */}
            <TabsContent value="tools">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {resources.tools.map((tool) => (
                  <Card key={tool.id} className={`${tool.featured ? 'border-2 border-purple-200 dark:border-purple-800' : ''} hover:shadow-lg transition-shadow`}>
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300">
                          <Brain className="w-3 h-3 mr-1" />
                          {tool.category}
                        </Badge>
                        {tool.featured && (
                          <Badge variant="default" className="bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300">
                            Featured
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="text-xl">{tool.title}</CardTitle>
                      <CardDescription>{tool.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <span>{tool.type}</span>
                          <span>{tool.platform}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <Badge variant="outline" className={`text-xs ${tool.pricing === 'Free' ? 'text-green-600 border-green-600' : 'text-purple-600 border-purple-600'}`}>
                            {tool.pricing}
                          </Badge>
                          <Button size="sm">
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Access Tool
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Start Your Cognitive Wellness Journey?
          </h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Access our complete platform with personalized assessments, training programs, 
            and progress tracking tools designed by cognitive scientists.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild className="text-purple-600 font-semibold">
              <Link href="/journal">
                <Brain className="w-5 h-5 mr-2" />
                Start Free Assessment
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="border-white text-white hover:bg-white hover:text-purple-600">
              <Link href="/pricing">
                <Target className="w-5 h-5 mr-2" />
                View Plans
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}