import { useState, useEffect } from "react";
import { useParams, useLocation, Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Save, 
  Download, 
  Plus,
  FileImage,
  Sparkles,
  Palette,
  ArrowLeft,
  Brain,
  Circle,
  Home,
  Settings,
  Upload,
  Layers
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import DesignCanvas from "@/components/design-canvas";
import type { Project, Template } from "../../../shared/schema";

// Project creation dialog
function NewProjectDialog({ isOpen, onClose, onProjectCreated }: { 
  isOpen: boolean; 
  onClose: () => void;
  onProjectCreated?: (project: Project) => void;
}) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("journal");
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createProject = useMutation({
    mutationFn: async (projectData: any) => {
      return apiRequest("/api/projects", {
        method: "POST",
        body: JSON.stringify(projectData),
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Project Created",
        description: "Your new project has been created successfully.",
      });
      onProjectCreated?.(data);
      onClose();
      setTitle("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create project. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    createProject.mutate({
      title: title.trim(),
      category,
      dimensions,
      canvasData: { elements: [] },
      backgroundColor: "#ffffff",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Project</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="title">Project Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter project title..."
              required
            />
          </div>
          <div>
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="journal">Journal</SelectItem>
                <SelectItem value="planner">Planner</SelectItem>
                <SelectItem value="cover">Cover Design</SelectItem>
                <SelectItem value="artwork">Artwork</SelectItem>
                <SelectItem value="document">Document</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="width">Width (px)</Label>
              <Input
                id="width"
                type="number"
                value={dimensions.width}
                onChange={(e) => setDimensions(prev => ({ ...prev, width: parseInt(e.target.value) }))}
                min="100"
                max="3000"
              />
            </div>
            <div>
              <Label htmlFor="height">Height (px)</Label>
              <Input
                id="height"
                type="number"
                value={dimensions.height}
                onChange={(e) => setDimensions(prev => ({ ...prev, height: parseInt(e.target.value) }))}
                min="100"
                max="3000"
              />
            </div>
          </div>
          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={createProject.isPending}>
              {createProject.isPending ? "Creating..." : "Create Project"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Template selection dialog
function TemplateDialog({ isOpen, onClose, onTemplateSelect }: {
  isOpen: boolean;
  onClose: () => void;
  onTemplateSelect: (template: Template) => void;
}) {
  const { data: templates = [] } = useQuery<Template[]>({
    queryKey: ["/api/templates"],
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Choose a Template</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="journal">Journal</TabsTrigger>
            <TabsTrigger value="planner">Planner</TabsTrigger>
            <TabsTrigger value="cover">Cover</TabsTrigger>
            <TabsTrigger value="social_media">Social</TabsTrigger>
          </TabsList>
          <TabsContent value="all" className="mt-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-h-96 overflow-y-auto">
              {templates.map((template) => (
                <Card 
                  key={template.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => onTemplateSelect(template)}
                >
                  <CardContent className="p-4">
                    <div className="aspect-[3/4] bg-gradient-to-br from-purple-100 to-blue-100 rounded-lg mb-3 flex items-center justify-center">
                      <FileImage className="w-8 h-8 text-purple-500" />
                    </div>
                    <h4 className="font-semibold text-sm mb-1">{template.title}</h4>
                    <p className="text-xs text-muted-foreground mb-2">{template.description}</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="text-xs">
                        {template.category}
                      </Badge>
                      {template.isPremium && (
                        <Badge className="text-xs">Pro</Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export default function EditorPage() {
  const { projectId } = useParams<{ projectId?: string }>();
  const [, setLocation] = useLocation();
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [showNewProjectDialog, setShowNewProjectDialog] = useState(false);
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch project if projectId is provided
  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
    enabled: !!projectId,
  });

  // Fetch user projects for quick access
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  useEffect(() => {
    if (project) {
      setCurrentProject(project);
    }
  }, [project]);

  // Save project mutation
  const saveProject = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      return apiRequest(`/api/projects/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Project Saved",
        description: "Your project has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save project. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = (canvasData: any) => {
    if (!currentProject) return;
    
    saveProject.mutate({
      id: currentProject.id,
      data: {
        canvasData,
        updatedAt: new Date().toISOString(),
      },
    });
  };

  const handleExport = (format: 'pdf' | 'png' | 'jpeg') => {
    // Export functionality will be handled by the DesignCanvas component
    toast({
      title: `Exporting as ${format.toUpperCase()}`,
      description: "Your design is being exported...",
    });
  };

  const handleProjectCreated = (newProject: Project) => {
    setCurrentProject(newProject);
    setLocation(`/editor/${newProject.id}`);
  };

  const handleTemplateSelect = (template: Template) => {
    // Create a new project based on the template
    const newProject: Partial<Project> = {
      title: `${template.title} - Copy`,
      category: template.category,
      templateId: template.id,
      canvasData: template.canvasData,
      dimensions: template.dimensions,
      backgroundColor: "#ffffff",
    };
    
    // This would normally create the project via API
    setShowTemplateDialog(false);
    setShowNewProjectDialog(true);
  };

  // Show loading state
  if (projectId && projectLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading project...</p>
        </div>
      </div>
    );
  }

  // Show project selection if no current project
  if (!currentProject && !showNewProjectDialog) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="border-b bg-card">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Home
                </Link>
              </Button>
              <div>
                <h1 className="text-xl font-semibold">Design Studio</h1>
                <p className="text-sm text-muted-foreground">Create and edit your designs</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button asChild variant="outline">
                <Link href="/journal">
                  <Brain className="w-4 h-4 mr-2" />
                  Wellness Hub
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Project Selection */}
        <div className="max-w-6xl mx-auto p-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Start Creating</h2>
            <p className="text-muted-foreground mb-8">
              Choose how you'd like to start your design project
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-purple-300"
                onClick={() => setShowNewProjectDialog(true)}
              >
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Plus className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">Blank Canvas</h3>
                  <p className="text-sm text-muted-foreground">
                    Start with a completely blank canvas and create from scratch
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-blue-300"
                onClick={() => setShowTemplateDialog(true)}
              >
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <FileImage className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">Use Template</h3>
                  <p className="text-sm text-muted-foreground">
                    Choose from our collection of professional templates
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-green-300"
                onClick={() => {/* Handle recent projects */}}
              >
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Palette className="w-8 h-8 text-green-600 dark:text-green-400" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">Recent Projects</h3>
                  <p className="text-sm text-muted-foreground">
                    Continue working on your existing projects
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Recent Projects List */}
          {projects.length > 0 && (
            <div>
              <h3 className="text-xl font-semibold mb-6">Recent Projects</h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {projects.slice(0, 6).map((proj) => (
                  <Card 
                    key={proj.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => {
                      setCurrentProject(proj);
                      setLocation(`/editor/${proj.id}`);
                    }}
                  >
                    <CardContent className="p-4">
                      <div className="aspect-[4/3] bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg mb-3 flex items-center justify-center">
                        <Palette className="w-8 h-8 text-gray-400" />
                      </div>
                      <h4 className="font-semibold mb-1">{proj.title}</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        {proj.description || 'No description'}
                      </p>
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary" className="text-xs">
                          {proj.category}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {proj.updatedAt ? new Date(proj.updatedAt).toLocaleDateString() : 'Recently updated'}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Dialogs */}
        <NewProjectDialog 
          isOpen={showNewProjectDialog}
          onClose={() => setShowNewProjectDialog(false)}
          onProjectCreated={handleProjectCreated}
        />
        <TemplateDialog
          isOpen={showTemplateDialog}
          onClose={() => setShowTemplateDialog(false)}
          onTemplateSelect={handleTemplateSelect}
        />
      </div>
    );
  }

  // Main editor interface
  return (
    <div className="h-screen bg-background flex flex-col">
      {/* Top Header */}
      <div className="border-b bg-card p-2 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/">
              <Home className="w-4 h-4" />
            </Link>
          </Button>
          <div className="flex items-center space-x-2">
            <h1 className="font-semibold">
              {currentProject?.title || 'Untitled Project'}
            </h1>
            <Badge variant="secondary" className="text-xs">
              {currentProject?.category}
            </Badge>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => currentProject && handleSave(currentProject.canvasData)}
            disabled={saveProject.isPending}
          >
            <Save className="w-4 h-4 mr-1" />
            {saveProject.isPending ? 'Saving...' : 'Save'}
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link href="/journal">
              <Brain className="w-4 h-4 mr-1" />
              Wellness
            </Link>
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowNewProjectDialog(true)}
          >
            <Plus className="w-4 h-4 mr-1" />
            New
          </Button>
        </div>
      </div>

      {/* Main Canvas */}
      <div className="flex-1">
        <DesignCanvas
          projectId={currentProject?.id}
          templateData={currentProject}
          onSave={handleSave}
          onExport={handleExport}
        />
      </div>

      {/* Dialogs */}
      <NewProjectDialog 
        isOpen={showNewProjectDialog}
        onClose={() => setShowNewProjectDialog(false)}
        onProjectCreated={handleProjectCreated}
      />
    </div>
  );
}