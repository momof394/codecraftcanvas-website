import { useState, useEffect } from "react";

interface DailyAffirmationState {
  shouldShow: boolean;
  lastShown: string | null;
  dismissed: string | null;
  enabled: boolean;
}

export function useDailyAffirmation() {
  const [state, setState] = useState<DailyAffirmationState>(() => {
    if (typeof window === 'undefined') {
      return {
        shouldShow: false,
        lastShown: null,
        dismissed: null,
        enabled: true
      };
    }

    const saved = localStorage.getItem('daily-affirmation-state');
    const defaultState = {
      shouldShow: false,
      lastShown: null,
      dismissed: null,
      enabled: true
    };

    if (!saved) return defaultState;

    try {
      return { ...defaultState, ...JSON.parse(saved) };
    } catch {
      return defaultState;
    }
  });

  const [isLoaded, setIsLoaded] = useState(false);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    if (typeof window !== 'undefined' && isLoaded) {
      localStorage.setItem('daily-affirmation-state', JSON.stringify(state));
    }
  }, [state, isLoaded]);

  // Check if we should show the affirmation
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const today = new Date().toDateString();
    
    // Don't show if disabled
    if (!state.enabled) {
      setIsLoaded(true);
      return;
    }

    // Don't show if dismissed today
    if (state.dismissed === today) {
      setIsLoaded(true);
      return;
    }

    // Show if never shown or not shown today
    const shouldShow = !state.lastShown || state.lastShown !== today;
    
    setState(prev => ({ ...prev, shouldShow }));
    setIsLoaded(true);
  }, [state.enabled, state.dismissed, state.lastShown]);

  const markAsShown = () => {
    const today = new Date().toDateString();
    setState(prev => ({
      ...prev,
      shouldShow: false,
      lastShown: today
    }));
  };

  const dismissForToday = () => {
    const today = new Date().toDateString();
    setState(prev => ({
      ...prev,
      shouldShow: false,
      dismissed: today,
      lastShown: today
    }));
  };

  const enable = () => {
    setState(prev => ({ ...prev, enabled: true }));
  };

  const disable = () => {
    setState(prev => ({ 
      ...prev, 
      enabled: false, 
      shouldShow: false 
    }));
  };

  const reset = () => {
    setState({
      shouldShow: false,
      lastShown: null,
      dismissed: null,
      enabled: true
    });
  };

  // Calculate streak (days in a row the affirmation was shown)
  const getStreak = (): number => {
    if (typeof window === 'undefined') return 0;

    const streakData = localStorage.getItem('affirmation-streak');
    if (!streakData) return 0;

    try {
      const { count, lastDate } = JSON.parse(streakData);
      const today = new Date().toDateString();
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      
      // If shown today, return current streak
      if (lastDate === today) return count;
      
      // If shown yesterday, we could continue the streak
      if (lastDate === yesterday && state.lastShown === today) {
        return count + 1;
      }
      
      // Streak broken
      return 0;
    } catch {
      return 0;
    }
  };

  const updateStreak = () => {
    if (typeof window === 'undefined') return;

    const today = new Date().toDateString();
    const currentStreak = getStreak();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    
    const streakData = localStorage.getItem('affirmation-streak');
    let newCount = 1;

    if (streakData) {
      try {
        const { count, lastDate } = JSON.parse(streakData);
        if (lastDate === yesterday) {
          newCount = count + 1;
        }
      } catch {
        // Invalid data, start fresh
      }
    }

    localStorage.setItem('affirmation-streak', JSON.stringify({
      count: newCount,
      lastDate: today
    }));
  };

  return {
    shouldShow: isLoaded && state.shouldShow,
    isEnabled: state.enabled,
    markAsShown: () => {
      markAsShown();
      updateStreak();
    },
    dismissForToday,
    enable,
    disable,
    reset,
    getStreak,
    isLoaded
  };
}