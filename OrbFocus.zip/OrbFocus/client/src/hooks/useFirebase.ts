import { useEffect, useState } from "react";
import { auth, db, storage, analytics, appCheck } from "@/lib/firebase";
import type { User } from "firebase/auth";

export function useFirebase() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setUser(user);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return {
    user,
    loading,
    auth,
    db,
    storage,
    analytics,
    appCheck
  };
}