import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "next-themes";
import { useDailyAffirmation } from "@/hooks/use-daily-affirmation";

// Pages
import HomePage from "@/pages/home";
import EditorPage from "@/pages/editor";
import TemplatesPage from "@/pages/templates";
import AssetsPage from "@/pages/assets";
import ExportsPage from "@/pages/exports";
import PricingPage from "@/pages/pricing";
import ProjectHubPage from "@/pages/journal";
import ClientsPage from "@/pages/clients";
import OrbCanvasPage from "@/pages/orb-canvas";
import NotFoundPage from "@/pages/not-found";
import AboutPage from "@/pages/about";
import BlogPage from "@/pages/blog";
import BlogPostPage from "@/pages/blog-post";
import TermsPage from "@/pages/terms";
import ResourcesPage from "@/pages/resources";
import PrivacyPolicyPage from "@/pages/privacy-policy";
import ContactPage from "@/pages/contact";

// Components
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import MicroAffirmationSplash from "@/components/micro-affirmation-splash";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 10, // 10 minutes (replaces cacheTime in v5)
    },
  },
});

function App() {
  const { shouldShow, markAsShown, dismissForToday } = useDailyAffirmation();

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
        <div className="min-h-screen bg-background">
          <Navbar />
          <main>
            <Switch>
              <Route path="/" component={HomePage} />
              <Route path="/editor/:projectId?" component={EditorPage} />
              <Route path="/templates" component={TemplatesPage} />
              <Route path="/assets" component={AssetsPage} />
              <Route path="/journal" component={ProjectHubPage} />
              <Route path="/clients" component={ClientsPage} />
              <Route path="/orb-canvas" component={OrbCanvasPage} />
              <Route path="/exports" component={ExportsPage} />
              <Route path="/pricing" component={PricingPage} />
              <Route path="/about" component={AboutPage} />
              <Route path="/blog" component={BlogPage} />
              <Route path="/blog/:id" component={BlogPostPage} />
              <Route path="/terms" component={TermsPage} />
              <Route path="/resources" component={ResourcesPage} />
              <Route path="/privacy" component={PrivacyPolicyPage} />
              <Route path="/contact" component={ContactPage} />
              <Route component={NotFoundPage} />
            </Switch>
          </main>
          <Footer />
          <Toaster />
          
          {/* Daily Affirmation Splash Screen */}
          {shouldShow && (
            <MicroAffirmationSplash
              onClose={markAsShown}
              onDismiss={dismissForToday}
            />
          )}
        </div>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;