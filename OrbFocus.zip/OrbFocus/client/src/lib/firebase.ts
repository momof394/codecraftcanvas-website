// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { initializeAppCheck, ReCaptchaV3Provider } from "firebase/app-check";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC2A6-pz9HVPlGgDMEDgkSaic9hwYCuRcE",
  authDomain: "flash-antler-456808-v4.firebaseapp.com",
  projectId: "flash-antler-456808-v4",
  storageBucket: "flash-antler-456808-v4.firebasestorage.app",
  messagingSenderId: "1085732608506",
  appId: "1:1085732608506:web:9e286c4cf7e831c9406c43",
  measurementId: "G-V4LTS8LCHN"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase App Check with ReCAPTCHA v3
const appCheck = initializeAppCheck(app, {
  provider: new ReCaptchaV3Provider('6LdoqSgrAAAAF2ttawi6gMB9N_F0N7eDLYdZFK'),
  isTokenAutoRefreshEnabled: true
});

// Initialize Firebase services
const analytics = getAnalytics(app);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export { app, analytics, auth, db, storage, appCheck };