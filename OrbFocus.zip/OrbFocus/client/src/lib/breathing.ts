export interface BreathingPattern {
  name: string;
  phases: BreathingPhase[];
  totalDuration: number;
  description: string;
}

export interface BreathingPhase {
  name: 'inhale' | 'hold' | 'exhale' | 'pause';
  duration: number; // in seconds
  instruction: string;
}

export const breathingPatterns: Record<string, BreathingPattern> = {
  '4-7-8': {
    name: '4-7-8 Breathing',
    description: 'Calming technique for anxiety relief',
    totalDuration: 19, // 4 + 7 + 8
    phases: [
      {
        name: 'inhale',
        duration: 4,
        instruction: 'Breathe in slowly through your nose'
      },
      {
        name: 'hold',
        duration: 7,
        instruction: 'Hold your breath gently'
      },
      {
        name: 'exhale',
        duration: 8,
        instruction: 'Exhale slowly through your mouth'
      }
    ]
  },
  'box': {
    name: 'Box Breathing',
    description: 'Equal timing for focus and balance',
    totalDuration: 16, // 4 + 4 + 4 + 4
    phases: [
      {
        name: 'inhale',
        duration: 4,
        instruction: 'Breathe in slowly'
      },
      {
        name: 'hold',
        duration: 4,
        instruction: 'Hold your breath'
      },
      {
        name: 'exhale',
        duration: 4,
        instruction: 'Breathe out slowly'
      },
      {
        name: 'pause',
        duration: 4,
        instruction: 'Pause before the next breath'
      }
    ]
  }
};

export function createBreathingTimer(
  patternId: string,
  onPhaseChange: (phase: BreathingPhase, progress: number) => void,
  onComplete: () => void
) {
  const pattern = breathingPatterns[patternId];
  if (!pattern) throw new Error(`Unknown breathing pattern: ${patternId}`);
  
  let currentPhaseIndex = 0;
  let phaseProgress = 0;
  let intervalId: NodeJS.Timeout;
  
  const tick = () => {
    const currentPhase = pattern.phases[currentPhaseIndex];
    phaseProgress += 0.1; // Update every 100ms
    
    const progress = phaseProgress / currentPhase.duration;
    onPhaseChange(currentPhase, Math.min(progress, 1));
    
    if (phaseProgress >= currentPhase.duration) {
      currentPhaseIndex++;
      phaseProgress = 0;
      
      if (currentPhaseIndex >= pattern.phases.length) {
        clearInterval(intervalId);
        onComplete();
        return;
      }
    }
  };
  
  intervalId = setInterval(tick, 100);
  
  return () => clearInterval(intervalId);
}
