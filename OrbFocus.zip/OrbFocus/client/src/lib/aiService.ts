// Client-side AI service using pre-programmed responses
// This provides a free AI therapy experience without requiring API keys

export interface TherapyMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  emotionalAnalysis?: {
    sentiment: number; // -1 to 1
    emotions: string[];
    intensity: number; // 0 to 1
  };
}

export interface TherapyAnalysis {
  emotionalState: {
    primaryEmotion: string;
    intensity: number;
    triggers: string[];
    copingStrategies: string[];
  };
  insights: {
    patterns: string[];
    progressNotes: string[];
    concernAreas: string[];
  };
  recommendations: {
    immediateActions: string[];
    longTermGoals: string[];
    resources: string[];
  };
}

export class LocalAIService {
  private responseTemplates = {
    empathetic: {
      greetings: [
        "Hello, and welcome to our session together. I'm here to listen and support you in whatever you're going through. This is a safe space where you can share openly. What would you like to talk about today?",
        "I'm so glad you're here. It takes courage to reach out for support, and I want you to know that your feelings and experiences are completely valid. How are you feeling right now?",
        "Welcome to this safe space. I'm here to provide you with compassionate support and understanding. Whatever you're going through, you don't have to face it alone. What's on your mind today?"
      ],
      responses: [
        "I hear you, and what you're sharing sounds really difficult. It takes courage to open up about these feelings.",
        "Thank you for trusting me with this. Your feelings are completely valid, and it's okay to feel this way.",
        "That sounds really challenging. How has this been affecting you day to day?",
        "I can sense the weight of what you're carrying. You don't have to go through this alone.",
        "What you've shared resonates with me. How long have you been feeling this way?",
        "I can see how much this means to you. It's natural to feel overwhelmed sometimes.",
        "Your awareness of these feelings shows real strength. Tell me more about what this experience has been like for you.",
        "I appreciate you being so open with me. These emotions you're describing are very human and understandable."
      ],
      followups: [
        "How are you taking care of yourself during this difficult time?",
        "What has helped you cope with similar feelings in the past?",
        "Have you been able to talk to anyone else about this?",
        "What would it look like if this situation improved, even just a little?",
        "What do you need most right now to feel supported?"
      ]
    },
    analytical: {
      greetings: [
        "Welcome to our therapy session. I'm here to help you understand patterns in your thoughts and behaviors. We'll work systematically to identify areas for growth. What specific challenges would you like to address?",
        "Hello. Let's approach your concerns methodically. By identifying patterns and understanding underlying causes, we can develop effective strategies for change. What brings you here today?",
        "I'm glad you're here. Together, we'll analyze your experiences to gain insights and develop practical solutions. What would you like to focus on in our session?"
      ],
      responses: [
        "Let's explore this pattern. When did you first notice these thoughts or feelings emerging?",
        "I'm noticing some themes in what you've shared. Can you help me understand what typically triggers these experiences?",
        "That's a helpful insight. Let's break this down into smaller components we can work with.",
        "Based on what you've described, it seems like there might be some cognitive patterns we can examine together.",
        "How do you think this situation connects to other experiences you've had?",
        "Let's identify the specific thoughts that precede these emotional responses.",
        "What evidence do you have that supports or contradicts these thoughts?",
        "Can you walk me through the sequence of events that typically leads to this feeling?"
      ],
      followups: [
        "What patterns do you notice in when this happens?",
        "How might we test this thought or belief?",
        "What would be a more balanced way to view this situation?",
        "What small experiment could we try this week?",
        "How could you track this pattern to gather more data?"
      ]
    },
    motivational: {
      greetings: [
        "I'm so glad you're here today! Taking this step shows incredible strength and commitment to your wellbeing. You have the power to create positive change in your life. What goals are you excited to work toward?",
        "Welcome! Your decision to seek support demonstrates real courage and wisdom. I believe in your ability to overcome challenges and thrive. What positive changes would you like to see in your life?",
        "It's wonderful to meet you! The fact that you're here shows you're ready to invest in yourself and your mental health. I'm excited to support you on this journey. What would you like to accomplish?"
      ],
      responses: [
        "I love that you're being so open and honest! That self-awareness is a real strength.",
        "You're doing great by talking through this. Every step you take toward understanding yourself better is progress!",
        "I can see your resilience shining through, even in this difficult situation. That's something to build on!",
        "What you've shared shows real insight and growth. How can we use this awareness to move forward?",
        "You have so much wisdom already within you. What do you think might be a good next step?",
        "That's a fantastic insight! You're already showing the kind of thinking that leads to positive change.",
        "I'm impressed by how you're approaching this challenge. What strengths can you draw on here?",
        "You've overcome difficulties before - what did that teach you about your own capabilities?"
      ],
      followups: [
        "What strengths do you see in yourself that could help here?",
        "What's one small step you could take this week toward your goal?",
        "How will you celebrate when you make progress on this?",
        "What would your best friend say about your ability to handle this?",
        "What possibilities do you see opening up as you work on this?"
      ]
    }
  };

  private sessionContexts = {
    general: "Today we're having a general therapy session focused on overall wellbeing and mental health.",
    anxiety: "This session is focused on anxiety management and developing coping strategies for anxious thoughts and feelings.",
    depression: "We're working together on depression support, focusing on mood improvement and building positive momentum.",
    adhd: "This session is tailored for ADHD support, focusing on executive function, attention, and neurodivergent strengths.",
    crisis: "This is a crisis support session. Your safety and immediate wellbeing are our top priority."
  };

  private emotionWords = {
    positive: ["hopeful", "grateful", "peaceful", "confident", "content", "optimistic", "relieved", "proud"],
    negative: ["anxious", "sad", "frustrated", "overwhelmed", "lonely", "angry", "stressed", "worried"],
    neutral: ["curious", "thoughtful", "reflective", "calm", "focused", "attentive", "present"]
  };

  async startTherapySession(
    sessionType: string = "general",
    personality: string = "empathetic"
  ): Promise<{ sessionId: string; response: string; analysis: TherapyAnalysis }> {
    await this.simulateDelay();
    
    const responses = this.responseTemplates[personality as keyof typeof this.responseTemplates]?.greetings || 
                     this.responseTemplates.empathetic.greetings;
    
    const response = this.getRandomResponse(responses);
    const sessionId = crypto.randomUUID();
    
    const analysis = this.generateInitialAnalysis(sessionType);
    
    return { sessionId, response, analysis };
  }

  async continueTherapySession(
    sessionHistory: TherapyMessage[],
    newMessage: string,
    personality: string = "empathetic"
  ): Promise<{ response: string; analysis: TherapyAnalysis }> {
    await this.simulateDelay();
    
    const messageAnalysis = this.analyzeMessage(newMessage);
    const response = this.generateContextualResponse(newMessage, sessionHistory, personality, messageAnalysis);
    const analysis = this.generateSessionAnalysis(sessionHistory, newMessage, messageAnalysis);
    
    return { response, analysis };
  }

  async analyzeJournalEntry(content: string): Promise<{
    sentiment: number;
    emotionalTone: string;
    themes: string[];
    insights: string[];
    recommendations: string[];
  }> {
    await this.simulateDelay();
    
    const analysis = this.analyzeMessage(content);
    const themes = this.extractThemes(content);
    
    return {
      sentiment: analysis.sentiment,
      emotionalTone: analysis.emotions[0] || "neutral",
      themes,
      insights: this.generateInsights(content, analysis),
      recommendations: this.generateRecommendations(analysis, themes)
    };
  }

  private analyzeMessage(message: string): { sentiment: number; emotions: string[]; intensity: number } {
    const lowerMessage = message.toLowerCase();
    
    // Simple sentiment analysis
    const positiveWords = ["good", "great", "happy", "better", "progress", "hope", "grateful", "peaceful", "confident"];
    const negativeWords = ["bad", "terrible", "sad", "worse", "struggle", "difficult", "anxious", "depressed", "overwhelmed"];
    
    let positiveCount = 0;
    let negativeCount = 0;
    
    positiveWords.forEach(word => {
      if (lowerMessage.includes(word)) positiveCount++;
    });
    
    negativeWords.forEach(word => {
      if (lowerMessage.includes(word)) negativeCount++;
    });
    
    const sentiment = positiveCount > negativeCount ? 
      Math.min(0.8, 0.1 + (positiveCount * 0.2)) : 
      Math.max(-0.8, -0.1 - (negativeCount * 0.2));
    
    // Determine emotions
    const emotions: string[] = [];
    if (sentiment > 0.3) {
      emotions.push(...this.emotionWords.positive.slice(0, 2));
    } else if (sentiment < -0.3) {
      emotions.push(...this.emotionWords.negative.slice(0, 2));
    } else {
      emotions.push(...this.emotionWords.neutral.slice(0, 2));
    }
    
    const intensity = Math.abs(sentiment) + (message.length > 100 ? 0.2 : 0);
    
    return { sentiment, emotions, intensity: Math.min(intensity, 1) };
  }

  private generateContextualResponse(
    message: string,
    history: TherapyMessage[],
    personality: string,
    analysis: { sentiment: number; emotions: string[]; intensity: number }
  ): string {
    const templates = this.responseTemplates[personality as keyof typeof this.responseTemplates] || 
                     this.responseTemplates.empathetic;
    
    // Choose response type based on message analysis and history length
    if (history.length < 3) {
      return this.getRandomResponse(templates.responses);
    } else if (history.length % 3 === 0) {
      return this.getRandomResponse(templates.followups);
    } else {
      return this.getRandomResponse(templates.responses);
    }
  }

  private generateInitialAnalysis(sessionType: string): TherapyAnalysis {
    return {
      emotionalState: {
        primaryEmotion: "curious",
        intensity: 0.3,
        triggers: [],
        copingStrategies: []
      },
      insights: {
        patterns: [],
        progressNotes: ["Session started with positive engagement"],
        concernAreas: []
      },
      recommendations: {
        immediateActions: ["Take deep breaths", "Practice mindful awareness"],
        longTermGoals: ["Develop healthy coping strategies", "Build emotional resilience"],
        resources: ["Breathing exercises", "Mindfulness techniques", "Journaling"]
      }
    };
  }

  private generateSessionAnalysis(
    history: TherapyMessage[],
    newMessage: string,
    messageAnalysis: { sentiment: number; emotions: string[]; intensity: number }
  ): TherapyAnalysis {
    return {
      emotionalState: {
        primaryEmotion: messageAnalysis.emotions[0] || "neutral",
        intensity: messageAnalysis.intensity,
        triggers: this.extractTriggers(newMessage),
        copingStrategies: this.suggestCopingStrategies(messageAnalysis)
      },
      insights: {
        patterns: this.identifyPatterns(history),
        progressNotes: this.generateProgressNotes(messageAnalysis, history.length),
        concernAreas: messageAnalysis.sentiment < -0.5 ? ["Emotional distress indicators"] : []
      },
      recommendations: {
        immediateActions: this.generateImmediateActions(messageAnalysis),
        longTermGoals: ["Continue building emotional awareness", "Develop personalized coping toolkit"],
        resources: this.suggestResources(messageAnalysis)
      }
    };
  }

  private extractThemes(content: string): string[] {
    const themes: string[] = [];
    const lowerContent = content.toLowerCase();
    
    const themeKeywords = {
      "relationships": ["friend", "family", "partner", "relationship", "social"],
      "work": ["job", "work", "career", "boss", "colleague", "stress"],
      "self-care": ["tired", "sleep", "exercise", "health", "self"],
      "emotions": ["feel", "emotion", "mood", "anxiety", "depression"],
      "goals": ["goal", "future", "plan", "dream", "aspiration"]
    };
    
    Object.entries(themeKeywords).forEach(([theme, keywords]) => {
      if (keywords.some(keyword => lowerContent.includes(keyword))) {
        themes.push(theme);
      }
    });
    
    return themes.length > 0 ? themes : ["general wellbeing"];
  }

  private extractTriggers(message: string): string[] {
    const triggers: string[] = [];
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes("stress") || lowerMessage.includes("pressure")) {
      triggers.push("stressful situations");
    }
    if (lowerMessage.includes("work") || lowerMessage.includes("job")) {
      triggers.push("work-related stress");
    }
    if (lowerMessage.includes("relationship") || lowerMessage.includes("family")) {
      triggers.push("interpersonal challenges");
    }
    
    return triggers;
  }

  private suggestCopingStrategies(analysis: { sentiment: number; emotions: string[]; intensity: number }): string[] {
    const strategies: string[] = [];
    
    if (analysis.intensity > 0.7) {
      strategies.push("grounding techniques", "deep breathing");
    }
    if (analysis.sentiment < -0.3) {
      strategies.push("self-compassion practices", "mindful observation");
    } else {
      strategies.push("positive reinforcement", "gratitude practice");
    }
    
    return strategies;
  }

  private identifyPatterns(history: TherapyMessage[]): string[] {
    const patterns: string[] = [];
    
    if (history.length > 5) {
      patterns.push("Consistent engagement in therapy process");
    }
    if (history.length > 3) {
      patterns.push("Building therapeutic rapport");
    }
    
    return patterns;
  }

  private generateProgressNotes(analysis: { sentiment: number; emotions: string[]; intensity: number }, sessionLength: number): string[] {
    const notes: string[] = [];
    
    if (analysis.sentiment > 0) {
      notes.push("Positive emotional expression observed");
    }
    if (sessionLength > 5) {
      notes.push("Strong engagement throughout session");
    }
    if (analysis.intensity < 0.5) {
      notes.push("Emotional regulation appears stable");
    }
    
    return notes.length > 0 ? notes : ["Session progressing normally"];
  }

  private generateImmediateActions(analysis: { sentiment: number; emotions: string[]; intensity: number }): string[] {
    const actions: string[] = [];
    
    if (analysis.intensity > 0.7) {
      actions.push("Practice 4-7-8 breathing technique");
    }
    if (analysis.sentiment < -0.5) {
      actions.push("Engage in gentle self-care activity");
    } else {
      actions.push("Continue mindful awareness");
    }
    
    actions.push("Take notes on insights from this session");
    
    return actions;
  }

  private generateInsights(content: string, analysis: { sentiment: number; emotions: string[]; intensity: number }): string[] {
    const insights: string[] = [];
    
    if (content.length > 200) {
      insights.push("Detailed self-reflection shows strong self-awareness");
    }
    if (analysis.sentiment > 0.3) {
      insights.push("Positive emotional processing evident");
    }
    if (analysis.intensity > 0.6) {
      insights.push("High emotional intensity suggests significant processing");
    }
    
    return insights.length > 0 ? insights : ["Healthy emotional expression through writing"];
  }

  private generateRecommendations(analysis: { sentiment: number; emotions: string[]; intensity: number }, themes: string[]): string[] {
    const recommendations: string[] = [];
    
    if (themes.includes("relationships")) {
      recommendations.push("Consider exploring communication techniques");
    }
    if (themes.includes("work")) {
      recommendations.push("Practice stress management techniques");
    }
    if (analysis.intensity > 0.7) {
      recommendations.push("Try progressive muscle relaxation");
    }
    
    recommendations.push("Continue regular journaling practice");
    
    return recommendations;
  }

  private suggestResources(analysis: { sentiment: number; emotions: string[]; intensity: number }): string[] {
    const resources: string[] = [];
    
    if (analysis.intensity > 0.6) {
      resources.push("Guided meditation apps", "Breathing exercise videos");
    }
    if (analysis.sentiment < -0.3) {
      resources.push("Self-compassion exercises", "Mood tracking tools");
    } else {
      resources.push("Gratitude journaling", "Mindfulness practices");
    }
    
    return resources;
  }

  private getRandomResponse(responses: string[]): string {
    return responses[Math.floor(Math.random() * responses.length)];
  }

  private async simulateDelay(): Promise<void> {
    // Simulate realistic AI response time
    const delay = 800 + Math.random() * 1200; // 0.8-2 seconds
    await new Promise(resolve => setTimeout(resolve, delay));
  }
}

export const localAI = new LocalAIService();