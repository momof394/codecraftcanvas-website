import { QueryClient } from "@tanstack/react-query";

// Default fetcher function for TanStack Query
export const apiRequest = async (url: string, options?: RequestInit): Promise<any> => {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
    ...options,
  });

  if (!response.ok) {
    throw new Error(`Request failed: ${response.statusText}`);
  }

  return response.json();
};

// Helper for making POST/PUT/DELETE requests with data
export const apiRequestWithData = async (method: string, url: string, data?: any, options?: RequestInit): Promise<any> => {
  return apiRequest(url, {
    method,
    body: data ? JSON.stringify(data) : undefined,
    ...options,
  });
};

// Query client instance
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: ({ queryKey }) => apiRequest(queryKey[0] as string),
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 10, // 10 minutes (replaces cacheTime in v5)
    },
  },
});