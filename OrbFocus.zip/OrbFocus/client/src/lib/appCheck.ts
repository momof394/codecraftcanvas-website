import { getToken, getLimitedUseToken } from 'firebase/app-check';
import { appCheck } from './firebase';

/**
 * Get App Check token for API requests
 * @param forceRefresh - Whether to force refresh the token
 * @returns Promise with the App Check token
 */
export const getAppCheckToken = async (forceRefresh = false) => {
  try {
    const appCheckTokenResponse = await getToken(appCheck, forceRefresh);
    return appCheckTokenResponse.token;
  } catch (err) {
    console.error('Failed to get App Check token:', err);
    throw err;
  }
};

/**
 * Get limited use App Check token for sensitive operations
 * @returns Promise with the limited use App Check token
 */
export const getLimitedUseAppCheckToken = async () => {
  try {
    const appCheckTokenResponse = await getLimitedUseToken(appCheck);
    return appCheckTokenResponse.token;
  } catch (err) {
    console.error('Failed to get limited use App Check token:', err);
    throw err;
  }
};

/**
 * Make API call with App Check token
 * @param url - API endpoint URL
 * @param options - Fetch options
 * @param useLimitedToken - Whether to use limited use token for sensitive operations
 * @returns Promise with the API response
 */
export const callApiWithAppCheck = async (
  url: string, 
  options: RequestInit = {}, 
  useLimitedToken = false
) => {
  try {
    const token = useLimitedToken 
      ? await getLimitedUseAppCheckToken()
      : await getAppCheckToken();

    const response = await fetch(url, {
      ...options,
      headers: {
        ...options.headers,
        'X-Firebase-AppCheck': token,
      }
    });

    return response;
  } catch (err) {
    console.error('API call with App Check failed:', err);
    throw err;
  }
};