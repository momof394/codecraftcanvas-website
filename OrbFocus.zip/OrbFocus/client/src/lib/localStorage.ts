// Local storage utilities for client-only deployment
// Legacy types for backward compatibility with existing components
interface MoodEntry {
  id: string;
  userId: string;
  mood: number;
  energy: number;
  anxiety: number;
  notes?: string;
  tags?: string[];
  timestamp: Date;
}

interface JournalEntry {
  id: string;
  userId: string;
  content: string;
  mood?: number;
  tags?: string[];
  createdAt: Date;
  updatedAt: Date;
}

interface Task {
  id: string;
  userId: string;
  title: string;
  description?: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  category?: string;
  dueDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

interface UserSettings {
  id: string;
  userId: string;
  theme: 'light' | 'dark' | 'system';
  notifications: boolean;
  emailUpdates: boolean;
  privacy: {
    shareData: boolean;
    analytics: boolean;
  };
  preferences: {
    defaultMoodScale: number;
    reminderTime?: string;
    weekStartsOn: number;
  };
}

const STORAGE_KEYS = {
  MOOD_ENTRIES: 'bodydouble-mood-entries',
  JOURNAL_ENTRIES: 'bodydouble-journal-entries',
  TASKS: 'bodydouble-tasks',
  USER_SETTINGS: 'bodydouble-user-settings'
} as const;

// Helper functions for localStorage operations
function getFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.warn(`Error reading from localStorage for key ${key}:`, error);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.warn(`Error saving to localStorage for key ${key}:`, error);
  }
}

// Mood entries
export function getMoodEntries(): MoodEntry[] {
  return getFromStorage(STORAGE_KEYS.MOOD_ENTRIES, []);
}

export function saveMoodEntry(entry: Omit<MoodEntry, 'id' | 'timestamp'>): MoodEntry {
  const entries = getMoodEntries();
  const newEntry: MoodEntry = {
    ...entry,
    id: crypto.randomUUID(),
    timestamp: new Date(),
    userId: 'local-user'
  };
  entries.push(newEntry);
  saveToStorage(STORAGE_KEYS.MOOD_ENTRIES, entries);
  return newEntry;
}

// Journal entries
export function getJournalEntries(): JournalEntry[] {
  return getFromStorage(STORAGE_KEYS.JOURNAL_ENTRIES, []);
}

export function saveJournalEntry(entry: Omit<JournalEntry, 'id' | 'createdAt' | 'updatedAt'>): JournalEntry {
  const entries = getJournalEntries();
  const newEntry: JournalEntry = {
    ...entry,
    id: crypto.randomUUID(),
    createdAt: new Date(),
    updatedAt: new Date(),
    userId: 'local-user'
  };
  entries.push(newEntry);
  saveToStorage(STORAGE_KEYS.JOURNAL_ENTRIES, entries);
  return newEntry;
}

export function updateJournalEntry(id: string, content: string): JournalEntry | null {
  const entries = getJournalEntries();
  const entryIndex = entries.findIndex(e => e.id === id);
  if (entryIndex === -1) return null;
  
  entries[entryIndex] = {
    ...entries[entryIndex],
    content,
    updatedAt: new Date()
  };
  saveToStorage(STORAGE_KEYS.JOURNAL_ENTRIES, entries);
  return entries[entryIndex];
}

export function deleteJournalEntry(id: string): boolean {
  const entries = getJournalEntries();
  const filteredEntries = entries.filter(e => e.id !== id);
  if (filteredEntries.length === entries.length) return false;
  
  saveToStorage(STORAGE_KEYS.JOURNAL_ENTRIES, filteredEntries);
  return true;
}

// Tasks
export function getTasks(): Task[] {
  return getFromStorage(STORAGE_KEYS.TASKS, []);
}

export function saveTask(task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>): Task {
  const tasks = getTasks();
  const newTask: Task = {
    ...task,
    id: crypto.randomUUID(),
    createdAt: new Date(),
    updatedAt: new Date(),
    userId: 'local-user'
  };
  tasks.push(newTask);
  saveToStorage(STORAGE_KEYS.TASKS, tasks);
  return newTask;
}

export function updateTask(id: string, updates: Partial<Pick<Task, 'completed' | 'title' | 'description' | 'estimatedTime'>>): Task | null {
  const tasks = getTasks();
  const taskIndex = tasks.findIndex(t => t.id === id);
  if (taskIndex === -1) return null;
  
  tasks[taskIndex] = {
    ...tasks[taskIndex],
    ...updates
  };
  saveToStorage(STORAGE_KEYS.TASKS, tasks);
  return tasks[taskIndex];
}

export function deleteTask(id: string): boolean {
  const tasks = getTasks();
  const filteredTasks = tasks.filter(t => t.id !== id);
  if (filteredTasks.length === tasks.length) return false;
  
  saveToStorage(STORAGE_KEYS.TASKS, filteredTasks);
  return true;
}

// User settings
export function getUserSettings(): UserSettings {
  return getFromStorage(STORAGE_KEYS.USER_SETTINGS, {
    id: 'local-user',
    userId: 'local-user',
    currentMood: 'calm',
    therapyPreferences: {},
    journalCustomization: {
      theme: 'default',
      fontFamily: 'serif',
      fontSize: 'medium',
      backgroundColor: '#ffffff',
      textColor: '#333333'
    },
    aiPersonality: 'empathetic',
    crisisContacts: [],
    privacySettings: {},
    notificationSettings: {},
    soundVolume: 70,
    preferences: {},
    updatedAt: new Date()
  });
}

export function updateUserSettings(settings: Partial<UserSettings>): UserSettings {
  const currentSettings = getUserSettings();
  const updatedSettings = {
    ...currentSettings,
    ...settings,
    updatedAt: new Date()
  };
  saveToStorage(STORAGE_KEYS.USER_SETTINGS, updatedSettings);
  return updatedSettings;
}

// AI Journal entries with stickers and customization
const STORAGE_KEYS_AI = {
  AI_JOURNAL_ENTRIES: 'ai_journal_entries',
  THERAPY_SESSIONS: 'therapy_sessions',
  MENTAL_HEALTH_GOALS: 'mental_health_goals',
  CRISIS_LOGS: 'crisis_logs',
  CUSTOM_STICKERS: 'custom_stickers'
} as const;

export interface CustomSticker {
  id: string;
  name: string;
  emoji?: string;
  svgContent?: string;
  color: string;
  category: string;
  createdAt: Date;
}

export interface JournalSticker {
  stickerId: string;
  x: number;
  y: number;
  size: number;
  rotation: number;
}

export interface EnhancedJournalEntry {
  id: string;
  userId: string;
  title?: string;
  content: string;
  stickers: JournalSticker[];
  customization: {
    fontFamily: string;
    fontSize: string;
    backgroundColor: string;
    textColor: string;
    backgroundPattern?: string;
  };
  aiAnalysis?: any;
  emotionalTone?: string;
  tags: string[];
  entryType: string;
  isPrivate: boolean;
  aiRecommendations?: any;
  createdAt: Date;
  updatedAt: Date;
}

// Default sticker collection
const DEFAULT_STICKERS: CustomSticker[] = [
  { id: '1', name: 'Happy', emoji: '😊', color: '#FFD700', category: 'emotions', createdAt: new Date() },
  { id: '2', name: 'Sad', emoji: '😢', color: '#87CEEB', category: 'emotions', createdAt: new Date() },
  { id: '3', name: 'Anxious', emoji: '😰', color: '#FFA07A', category: 'emotions', createdAt: new Date() },
  { id: '4', name: 'Grateful', emoji: '🙏', color: '#98FB98', category: 'emotions', createdAt: new Date() },
  { id: '5', name: 'Strong', emoji: '💪', color: '#FF6347', category: 'empowerment', createdAt: new Date() },
  { id: '6', name: 'Peaceful', emoji: '🕊️', color: '#E6E6FA', category: 'wellness', createdAt: new Date() },
  { id: '7', name: 'Star', emoji: '⭐', color: '#FFD700', category: 'achievements', createdAt: new Date() },
  { id: '8', name: 'Heart', emoji: '❤️', color: '#FF69B4', category: 'love', createdAt: new Date() },
  { id: '9', name: 'Sunshine', emoji: '☀️', color: '#FFA500', category: 'wellness', createdAt: new Date() },
  { id: '10', name: 'Rainbow', emoji: '🌈', color: '#FF69B4', category: 'hope', createdAt: new Date() }
];

export function getCustomStickers(): CustomSticker[] {
  const stored = getFromStorage(STORAGE_KEYS_AI.CUSTOM_STICKERS, DEFAULT_STICKERS);
  return stored.map(sticker => ({
    ...sticker,
    createdAt: new Date(sticker.createdAt)
  }));
}

export function createCustomSticker(sticker: Omit<CustomSticker, 'id' | 'createdAt'>): CustomSticker {
  const stickers = getCustomStickers();
  const newSticker: CustomSticker = {
    ...sticker,
    id: crypto.randomUUID(),
    createdAt: new Date()
  };
  stickers.push(newSticker);
  saveToStorage(STORAGE_KEYS_AI.CUSTOM_STICKERS, stickers);
  return newSticker;
}

export function deleteCustomSticker(id: string): boolean {
  const stickers = getCustomStickers();
  const filteredStickers = stickers.filter(s => s.id !== id);
  if (filteredStickers.length === stickers.length) return false;
  
  saveToStorage(STORAGE_KEYS_AI.CUSTOM_STICKERS, filteredStickers);
  return true;
}

export function getAiJournalEntries(): EnhancedJournalEntry[] {
  const stored = getFromStorage(STORAGE_KEYS_AI.AI_JOURNAL_ENTRIES, []);
  return stored.map((entry: any) => ({
    ...entry,
    createdAt: new Date(entry.createdAt),
    updatedAt: new Date(entry.updatedAt)
  }));
}

export function createAiJournalEntry(entry: Omit<EnhancedJournalEntry, 'id' | 'userId' | 'createdAt' | 'updatedAt'>): EnhancedJournalEntry {
  const entries = getAiJournalEntries();
  const newEntry: EnhancedJournalEntry = {
    ...entry,
    id: crypto.randomUUID(),
    userId: 'local-user',
    createdAt: new Date(),
    updatedAt: new Date()
  };
  entries.unshift(newEntry);
  saveToStorage(STORAGE_KEYS_AI.AI_JOURNAL_ENTRIES, entries);
  return newEntry;
}

export function updateAiJournalEntry(id: string, updates: Partial<EnhancedJournalEntry>): EnhancedJournalEntry | null {
  const entries = getAiJournalEntries();
  const entryIndex = entries.findIndex(e => e.id === id);
  if (entryIndex === -1) return null;
  
  entries[entryIndex] = {
    ...entries[entryIndex],
    ...updates,
    updatedAt: new Date()
  };
  saveToStorage(STORAGE_KEYS_AI.AI_JOURNAL_ENTRIES, entries);
  return entries[entryIndex];
}

export function deleteAiJournalEntry(id: string): boolean {
  const entries = getAiJournalEntries();
  const filteredEntries = entries.filter(e => e.id !== id);
  if (filteredEntries.length === entries.length) return false;
  
  saveToStorage(STORAGE_KEYS_AI.AI_JOURNAL_ENTRIES, filteredEntries);
  return true;
}