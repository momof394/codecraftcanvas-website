const affirmations = [
  "You are doing the best you can with what you have right now",
  "Progress, not perfection, is what matters",
  "It's okay to take things one step at a time",
  "Your feelings are valid and you don't have to justify them",
  "Small wins are still wins worth celebrating",
  "You deserve compassion, especially from yourself",
  "It's okay to rest when you need to",
  "You are worthy of care and kindness",
  "Every day you get through is an accomplishment",
  "You don't have to be productive to be valuable",
  "Your pace is your pace, and that's perfectly okay",
  "You are allowed to have bad days",
  "Asking for help is a sign of strength, not weakness",
  "You are enough, exactly as you are right now",
  "It's okay to prioritize your mental health",
  "You don't have to have it all figured out",
  "Your efforts matter, even when they feel small",
  "You are allowed to change your mind",
  "It's okay to say no to protect your energy",
  "You are doing better than you think you are",
  "Your struggles don't define your worth",
  "It's okay to take up space",
  "You are allowed to have needs and boundaries",
  "Tomorrow is a fresh start with new possibilities",
  "You are braver than you believe and stronger than you seem"
];

export function getRandomAffirmation(): string {
  const randomIndex = Math.floor(Math.random() * affirmations.length);
  return affirmations[randomIndex];
}