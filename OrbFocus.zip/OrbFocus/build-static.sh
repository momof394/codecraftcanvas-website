#!/bin/bash

# Orb Focus Studio - Replit Static Deployment Build Script
# This script applies all the suggested deployment fixes for Replit static hosting

set -e

echo "🌟 Building Orb Focus Studio for Replit static deployment..."

# Clean any existing build
echo "🧹 Cleaning previous build..."
rm -rf dist/assets dist/index.html dist/public client/dist

# Build the application (this creates files in dist/public/)
echo "⚡ Building application..."
vite build

# Verify dist/public was created
if [ ! -d "dist/public" ]; then
    echo "❌ Build failed - dist/public directory not found"
    exit 1
fi

# Copy static files from dist/public/ to dist/ for Replit deployment
echo "📦 Copying static files to deployment directory..."
cp -r dist/public/* dist/

# Remove the public subdirectory since we've copied everything to the root
rm -rf dist/public

# Verify the build
echo "🔍 Verifying build output..."
if [ ! -f "dist/index.html" ]; then
    echo "❌ Build failed - index.html not found in dist/"
    exit 1
fi

if [ ! -d "dist/assets" ]; then
    echo "❌ Build failed - assets directory not found in dist/"
    exit 1
fi

# Check if index.html has a proper title
if ! grep -q "<title>" dist/index.html; then
    echo "❌ Build failed - index.html missing title tag"
    exit 1
fi

echo "✅ Build completed successfully!"
echo "📁 Static files ready in: dist/"
echo ""
echo "🚀 Deployment fixes applied:"
echo "  ✓ Build command generates static files"
echo "  ✓ Files placed in correct directory (dist/)"
echo "  ✓ index.html has proper title tag"
echo "  ✓ Build output matches .replit publicDir configuration"
echo ""
echo "🎯 Ready for Replit deployment:"
echo "  • Static files are in dist/ directory"
echo "  • Build command: ./build-static.sh"
echo "  • Public directory: dist (as configured in .replit)"
echo ""
echo "🧪 Test locally:"
echo "  cd dist && python3 -m http.server 8080"
echo "  Then visit: http://localhost:8080"