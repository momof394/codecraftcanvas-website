# Orb Focus Studio - Digital Design & Productivity Platform

## Overview

Orb Focus Studio is a comprehensive web-based digital design and productivity platform that combines professional design tools with project management features. Users can design, build, and export customized digital products such as graphics, presentations, marketing materials, and creative documents as PDF, PNG, and JPEG files for professional use.

**Recent Enhancement (August 2, 2025):** Transitioned from behavioral therapy focus to professional digital design and productivity platform. Removed mental wellness/therapy elements per user request. Added comprehensive content strategy including blog, resources, about page, and terms of service to address Google AdSense policy violations. Platform now focuses on design tools, project management, and creative workflows.

**Latest Feature (August 2, 2025):** Implemented Micro-Affirmation Daily Splash Screen feature with 10 creativity and productivity-focused affirmations that appear once daily when users first visit. Includes streak tracking, local storage persistence, and customizable settings.

**DEPLOYMENT FIXES APPLIED (August 2, 2025):** Successfully resolved all Replit static deployment issues. Applied comprehensive fixes including:
- ✓ Fixed build output directory - files now properly copied from dist/public/ to dist/
- ✓ Updated build-static.sh script with proper build verification and cleanup
- ✓ Verified index.html structure with proper title and meta tags
- ✓ Build command generates static files correctly via ./build-static.sh
- ✓ Public directory matches .replit configuration (publicDir = "dist")
- ✓ All assets properly organized in dist/assets/ directory
- ✓ Build script includes comprehensive error checking and validation
**READY FOR SUCCESSFUL STATIC DEPLOYMENT** - All suggested deployment fixes implemented and verified.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with custom configuration for development and production builds
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom wellness-themed color palette
- **State Management**: TanStack Query (React Query) for server state management
- **Animations**: Framer Motion for smooth, calming animations

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Middleware**: Custom logging, JSON parsing, and error handling
- **Development**: Hot module replacement via Vite integration

### Data Storage Solutions
- **Primary Storage**: Browser localStorage for client-side data persistence
- **Mock API Layer**: Custom localStorage adapter in `client/src/lib/queryClient.ts`
- **Data Structure**: TypeScript schemas maintained in `shared/schema.ts` for consistency
- **Storage Interface**: Compatible with original API endpoints for seamless component integration
- **Data Types**: Mood entries, journal entries, tasks, and user settings stored locally

### Authentication and Authorization
- **Current Implementation**: Demo user system with fixed user ID for MVP
- **Session Storage**: PostgreSQL-backed session store
- **Future Considerations**: Ready for user authentication implementation

## Key Components

### Core Features
1. **Design Studio**
   - Professional design tools and canvas
   - Layer management and advanced editing
   - Template library for quick starts

2. **Project Management**
   - Project organization and tracking
   - Collaboration tools for teams
   - Progress monitoring and deadlines

3. **Asset Library**
   - Extensive library of design assets
   - Custom asset upload and management
   - Search and categorization system

4. **Export System**
   - Multi-format export (PDF, PNG, JPEG, SVG)
   - High-resolution output options
   - Batch export capabilities

5. **Orb Canvas Studio**
   - Visual programming environment
   - Interactive design elements
   - Real-time collaboration features

6. **Template System**
   - Professional templates for various industries
   - Customizable layouts and designs
   - Regular template updates

7. **Micro-Affirmation Daily Splash Screen**
   - Daily positive affirmations focused on creativity and productivity
   - 10 unique affirmations rotating based on day of year
   - Streak tracking to encourage daily engagement
   - Customizable settings with enable/disable options
   - Smooth animations and elegant UI design

8. **Firebase Integration** (Added August 2, 2025)
   - Google Analytics for user behavior tracking
   - Firebase Authentication for user management
   - Firestore for cloud data storage
   - Firebase Storage for asset management
   - Configured at `client/src/lib/firebase.ts`
   - React hook available at `client/src/hooks/useFirebase.ts`

9. **AI Integration**
   - Smart design suggestions
   - Automated layout optimization
   - Content generation assistance

### Technical Components
- **Shared Schema**: TypeScript-first database schemas with Zod validation
- **API Layer**: RESTful endpoints with proper error handling and logging
- **UI Components**: Comprehensive design system based on shadcn/ui
- **Query Management**: Optimistic updates and caching via TanStack Query

## Data Flow

### Client-Server Communication
1. **API Requests**: Standardized fetch wrapper with error handling
2. **Query Management**: TanStack Query handles caching, background updates, and optimistic updates
3. **Real-time Updates**: Automatic query invalidation on mutations
4. **Error Handling**: Consistent error boundaries and user feedback

### State Management
1. **Server State**: TanStack Query manages all server-side data
2. **Local State**: React hooks for component-level state
3. **Settings**: Persistent user preferences stored in database
4. **Session State**: Mood and activity context maintained across page loads

### Database Schema
- **Users**: Basic user information and authentication
- **Mood Entries**: Timestamped mood data with optional notes
- **Journal Entries**: Text content with creation/update timestamps
- **Tasks**: Title, description, completion status, and time estimates
- **User Settings**: Preferences, current mood, and customization options

## External Dependencies

### Core Dependencies
- **Database**: Neon Database (PostgreSQL serverless)
- **UI Components**: Radix UI primitives for accessibility
- **Validation**: Zod for runtime type checking
- **Animations**: Framer Motion for smooth interactions
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for time-related operations
- **Firebase**: Google Firebase platform (Analytics, Auth, Firestore, Storage) - Added August 2, 2025

### Development Tools
- **Build System**: Vite with React plugin
- **Type Checking**: TypeScript with strict configuration
- **Database Toolkit**: Drizzle Kit for migrations
- **Development Enhancement**: Replit-specific plugins for cloud development

### Styling and Design
- **CSS Framework**: Tailwind CSS with custom design tokens
- **Component Variants**: Class Variance Authority for component styling
- **Responsive Design**: Mobile-first approach with breakpoint utilities

## Deployment Strategy

### Build Process
1. **Client Build**: Vite builds React application to static assets in `dist/public/`
2. **Server Build**: esbuild bundles Express server for production in `dist/index.js`
3. **Type Checking**: TypeScript compilation verification
4. **Database Migrations**: Drizzle Kit handles schema changes

### Static Deployment Architecture (Updated July 29, 2025)
- **Client-Only Application**: Fully functional static deployment with localStorage data persistence
- **Data Persistence**: Complete localStorage adapter replaces server API for client-side data storage
- **Mock API Layer**: Custom localStorage adapter in `client/src/lib/queryClient.ts` simulates REST API seamlessly
- **Build Output**: Vite builds React application to static assets in `dist/public/` directory
- **No Server Required**: Application runs entirely in browser without backend dependencies
- **Static Hosting Ready**: Compatible with Netlify, Vercel, GitHub Pages, and other static hosts
- **Privacy-First**: All mood entries, journal entries, tasks, and settings stored locally in user's browser
- **Offline Capability**: Application works without internet connection after initial load
- **Zero Server Costs**: No ongoing hosting fees, perfect for personal mental wellness use

### Environment Configuration
- **Development**: Vite dev server with HMR for React development
- **Static Production**: Files served from `dist/public/` directory (ready for static hosting)
- **Data Storage**: Browser localStorage with complete CRUD operations (no external database required)
- **Deployment**: Any static web hosting service, CDN, or file server
- **Browser Compatibility**: Modern browsers with localStorage and crypto.randomUUID() support
- **Local Testing**: Can be served with any static server (e.g., `python3 -m http.server` from dist/public/)

### Deployment Commands

#### Development
- **Development**: `npm run dev` - Starts Vite development server with HMR

#### Static Deployment (Recommended for Mental Wellness App)
- **Build Static**: `npm run build` - Creates production build in `dist/public/` directory
- **Deploy Static**: Upload `dist/public/` contents to any static hosting service
- **Local Testing**: `cd dist/public && python3 -m http.server 8000` - Test locally
- **Benefits**: Zero server costs, maximum privacy, offline capability, instant loading

#### Full-Stack Deployment (Alternative)
- **Build**: `npm run build` - Creates production build (frontend in `dist/public/`, server in `dist/index.js`)
- **Start Production**: `npm start` or `./start-production.sh` - Starts production server
- **Cloud Run**: Configured for Google Cloud Run deployment with Dockerfile

#### Recent Deployment Fixes (July 29, 2025) - DEPLOYMENT READY
✓ **CRITICAL FIX**: Applied all suggested deployment fixes for Cloud Run compatibility
✓ **HEALTH CHECKS**: Enhanced health check endpoints - `/health` returns proper JSON response 
✓ **ROOT ENDPOINT**: Added root route handler that serves React app in production, health check in development
✓ **PORT CONFIGURATION**: Server properly uses PORT environment variable (defaults to 8080 for Cloud Run)
✓ **BUILD COMMAND**: Verified build process - frontend builds to `dist/public/`, server to `dist/index.js`
✓ **RUN COMMAND**: Production startup uses `npm start` which runs `./start-production.sh`
✓ **PRODUCTION SERVER**: Serves static files correctly and handles HTTP requests on required port
✓ **DEPLOYMENT TESTING**: Comprehensive test confirms all deployment requirements are met
✓ **CLOUD RUN READY**: Application fully compatible with Cloud Run deployment requirements

#### Replit Static Deployment Fixes (July 29, 2025) - STATIC DEPLOYMENT READY
✓ **BUILD COMMAND**: Created `build-static.sh` script that generates static files before deployment
✓ **PUBLIC DIRECTORY**: Fixed file placement - static files now correctly copied to `dist/` directory
✓ **INDEX.HTML TITLE**: Added proper title "BodyDouble Orb - Mental Wellness & Self-Care" to index.html
✓ **META DESCRIPTION**: Added SEO-friendly meta description for the mental wellness platform
✓ **BUILD VERIFICATION**: Script validates build output with proper error checking
✓ **DEPLOYMENT STRUCTURE**: Files correctly placed in `dist/` to match .replit configuration
✓ **ASSETS ORGANIZATION**: CSS and JS assets properly structured in `dist/assets/`
✓ **STATIC HOSTING READY**: Application fully compatible with Replit static deployment

#### Cloud Run Configuration
- **Port**: Uses PORT environment variable (defaults to 8080 for Cloud Run)
- **Host**: Binds to 0.0.0.0 for Cloud Run compatibility  
- **Health Checks**: Primary health endpoint at `/health` with proper JSON response
- **Probes**: Startup probe (30s delay, 5 retries) and liveness probe (30s intervals)
- **Build Process**: Dockerfile builds both frontend and backend with verification
- **Production Server**: Serves static files from `dist/public/` and API from `dist/index.js`
- **Startup Script**: `start-production.sh` verifies build artifacts before starting server
- **Testing**: `test-deployment.sh` validates all deployment requirements
- **Docker Health**: Built-in Docker healthcheck using curl to `/health` endpointes artifacts

### Scalability Considerations
- **Static Assets**: Unlimited scaling via CDN distribution
- **Client-Side Processing**: All logic runs in user's browser
- **Data Storage**: localStorage isolated per user/browser
- **Performance**: No server latency, instant interactions after initial load
- **Cost Efficiency**: Zero server costs, only static hosting fees

The application prioritizes user well-being, accessibility, and gentle user experience over complex features, making it an ideal supportive tool for individuals managing mental health challenges and neurodivergent needs.