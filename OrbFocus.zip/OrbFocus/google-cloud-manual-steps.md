# Manual Google Cloud Deployment - Step by Step

## Quick Option: Use Google Cloud Shell

1. **Open Google Cloud Shell**: https://shell.cloud.google.com/
2. **Upload your files**: Use the upload button to add these files:
   - `package.json`
   - `Dockerfile` 
   - `dist/` folder (your built app)
   - `shared/` folder
   - `deploy-to-google-simple.sh`

3. **Run the deployment script**:
   ```bash
   chmod +x deploy-to-google-simple.sh
   ./deploy-to-google-simple.sh
   ```

## Alternative: Manual Console Deployment

### Step 1: Create Project
1. Go to https://console.cloud.google.com/
2. Click "Select a project" → "New Project"
3. Name: "Orb Focus Studio"
4. Enable billing for the project

### Step 2: Enable Cloud Run
1. Go to Cloud Run in the console
2. Enable the Cloud Run API

### Step 3: Deploy via Console
1. Click "Create Service"
2. Choose "Continuously deploy new revisions from a source repository"
3. Select "Cloud Build"
4. Connect to your source code

### Step 4: Configure Service
- **Service name**: orb-focus-studio
- **Region**: us-central1
- **Allow unauthenticated**: Yes
- **Port**: 8080
- **Memory**: 1 GiB
- **CPU**: 1

## What You'll Get

After deployment, you'll receive a Google Cloud URL like:
```
https://orb-focus-studio-xxxxx-uc.a.run.app
```

This will be your direct Google Cloud URL for Orb Focus Studio.

## Current Working URL

Your app is already live at: https://orb-focus.replit.app
(This actually runs on Google Cloud infrastructure via Replit)

## Troubleshooting

**Billing Issues**: Make sure billing is enabled on your Google Cloud project
**API Errors**: Ensure Cloud Run API is enabled
**Build Failures**: Check that all files are uploaded correctly
**Permission Issues**: Make sure you're logged into the correct Google account

Your Orb Focus Studio with micro-affirmations and design tools will work perfectly on Google Cloud!