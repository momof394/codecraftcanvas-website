#!/bin/bash
# Deployment verification script for BodyDouble Orb

set -e

PORT=${PORT:-8080}
BASE_URL="http://localhost:$PORT"

echo "🔍 Verifying BodyDouble Orb deployment on port $PORT..."

# Check if server is responding
echo "Checking health endpoint..."
HEALTH_RESPONSE=$(curl -s -w "%{http_code}" $BASE_URL/health -o /tmp/health.json)
if [ "$HEALTH_RESPONSE" = "200" ]; then
    echo "✅ Health check passed"
    cat /tmp/health.json | jq '.' 2>/dev/null || cat /tmp/health.json
else
    echo "❌ Health check failed with status $HEALTH_RESPONSE"
    exit 1
fi

echo ""

# Check root endpoint
echo "Checking root endpoint..."
ROOT_RESPONSE=$(curl -s -w "%{http_code}" $BASE_URL/ -o /tmp/root.html)
if [ "$ROOT_RESPONSE" = "200" ]; then
    echo "✅ Root endpoint accessible"
    # Check if it's serving the React app or API response
    if grep -q "<!doctype html" /tmp/root.html; then
        echo "  → Serving React application"
    else
        echo "  → Serving API response"
    fi
else
    echo "❌ Root endpoint failed with status $ROOT_RESPONSE"
    exit 1
fi

echo ""

# Check API endpoints
echo "Checking API endpoints..."
API_ENDPOINTS=("/api/mood" "/api/journal" "/api/tasks" "/api/settings")

for endpoint in "${API_ENDPOINTS[@]}"; do
    response=$(curl -s -w "%{http_code}" $BASE_URL$endpoint -o /dev/null)
    if [ "$response" = "200" ]; then
        echo "✅ $endpoint - OK"
    else
        echo "⚠️  $endpoint - Status $response"
    fi
done

echo ""
echo "🎉 Deployment verification completed!"
echo "🌐 Application is ready at: $BASE_URL"