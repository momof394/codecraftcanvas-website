# Google Cloud Direct Deployment Setup

## Step 1: Google Cloud Project Setup

1. **Go to Google Cloud Console**: https://console.cloud.google.com/
2. **Create New Project**:
   - Click "Select a project" → "New Project"
   - Project name: "orb-focus-studio" (or your preferred name)
   - Note your PROJECT_ID (usually auto-generated)

3. **Enable Required APIs**:
   ```bash
   gcloud services enable cloudbuild.googleapis.com
   gcloud services enable run.googleapis.com
   gcloud services enable containerregistry.googleapis.com
   ```

## Step 2: Install Google Cloud CLI

### Windows:
Download from: https://cloud.google.com/sdk/docs/install-sdk

### Mac/Linux:
```bash
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
```

## Step 3: Authentication & Configuration

```bash
# Login to Google Cloud
gcloud auth login

# Set your project (replace with your actual PROJECT_ID)
gcloud config set project YOUR_PROJECT_ID

# Verify configuration
gcloud config list
```

## Step 4: Deploy Your App

From your project directory (Replit or local):

### Option A: Automated Build & Deploy
```bash
gcloud builds submit --config=cloudbuild.yaml
```

### Option B: Manual Steps
```bash
# Build Docker image
docker build -t gcr.io/YOUR_PROJECT_ID/orb-focus-studio .

# Push to Container Registry
docker push gcr.io/YOUR_PROJECT_ID/orb-focus-studio

# Deploy to Cloud Run
gcloud run deploy orb-focus-studio \
  --image gcr.io/YOUR_PROJECT_ID/orb-focus-studio \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080 \
  --memory 1Gi
```

## Step 5: Get Your Google Cloud URL

After deployment, you'll receive a URL like:
```
https://orb-focus-studio-[hash]-uc.a.run.app
```

To retrieve it later:
```bash
gcloud run services describe orb-focus-studio --region=us-central1 --format="value(status.url)"
```

## Step 6: Custom Domain (Optional)

1. **In Cloud Run Console**:
   - Go to your service
   - Click "Manage Custom Domains"
   - Add your domain

2. **DNS Configuration**:
   - Add CNAME record pointing to the Cloud Run URL

## Deployment Files Ready

Your project includes:
- ✅ `Dockerfile` - Container configuration
- ✅ `cloudbuild.yaml` - Automated build & deploy
- ✅ Health checks at `/health` endpoint
- ✅ Production build process

## Cost Estimate

- **Free tier**: 2 million requests/month
- **Typical usage**: $0-5/month
- **Pay only for usage**: No fixed costs

## Troubleshooting

**Build Errors**: Check `npm run build` works locally
**Deploy Errors**: Verify PROJECT_ID is correct
**Access Issues**: Ensure `--allow-unauthenticated` flag is used

Your Orb Focus Studio app is production-ready for Google Cloud!