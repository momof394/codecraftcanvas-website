#!/bin/bash

# Simple Google Cloud Deployment Script for Orb Focus Studio
# Run this in Google Cloud Shell (https://shell.cloud.google.com/)

echo "🚀 Deploying Orb Focus Studio to Google Cloud..."

# Step 1: Create project (replace with your preferred name)
PROJECT_ID="orb-focus-studio-$(date +%s)"
echo "Creating project: $PROJECT_ID"
gcloud projects create $PROJECT_ID --name="Orb Focus Studio"
gcloud config set project $PROJECT_ID

# Step 2: Enable billing (you need to do this manually in console)
echo "⚠️  Please enable billing for project $PROJECT_ID in the Google Cloud Console"
echo "   Go to: https://console.cloud.google.com/billing/linkedaccount?project=$PROJECT_ID"
read -p "Press Enter after enabling billing..."

# Step 3: Enable required APIs
echo "Enabling required APIs..."
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com

# Step 4: Create Dockerfile (if not exists)
cat > Dockerfile << 'EOF'
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./
RUN npm ci --only=production

# Copy built application
COPY dist/ ./dist/
COPY shared/ ./shared/

# Expose port
EXPOSE 8080

# Set environment variables
ENV NODE_ENV=production
ENV PORT=8080

# Start the application
CMD ["node", "dist/index.js"]
EOF

# Step 5: Deploy using Cloud Run
echo "Deploying to Cloud Run..."
gcloud run deploy orb-focus-studio \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080 \
  --memory 1Gi \
  --cpu 1

# Step 6: Get the URL
echo "🎉 Deployment complete!"
URL=$(gcloud run services describe orb-focus-studio --region=us-central1 --format="value(status.url)")
echo "Your app is live at: $URL"
echo ""
echo "📋 Project Details:"
echo "   Project ID: $PROJECT_ID"
echo "   Service: orb-focus-studio"
echo "   Region: us-central1"
echo "   URL: $URL"