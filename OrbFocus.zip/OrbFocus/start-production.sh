#!/bin/bash
# Production startup script for BodyDouble Orb

set -e  # Exit on any error

# Set production environment
export NODE_ENV=production

# Use PORT environment variable or default to 8080 for Cloud Run
export PORT=${PORT:-8080}

# Verify build artifacts exist
if [ ! -f "dist/index.js" ]; then
    echo "ERROR: Server build file dist/index.js not found"
    exit 1
fi

if [ ! -d "dist/public" ]; then
    echo "ERROR: Client build directory dist/public not found"
    exit 1
fi

if [ ! -f "dist/public/index.html" ]; then
    echo "ERROR: Client index.html not found in dist/public"
    exit 1
fi

echo "Build verification passed"
echo "Server file: dist/index.js"
echo "Client files: dist/public/"
echo "Starting BodyDouble Orb in production mode on port $PORT"

# Start the production server
exec node dist/index.js