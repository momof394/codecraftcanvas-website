# Complete Google Cloud Deployment Commands

## Step 1: Initial Setup (One-time only)
```bash
# Install Google Cloud CLI (if not installed)
# Download from: https://cloud.google.com/sdk/docs/install

# Login to Google Cloud
gcloud auth login

# Create new project (replace PROJECT_ID with your choice, e.g., "orb-focus-studio-2025")
gcloud projects create PROJECT_ID --name="Orb Focus Studio"

# Set the project as default
gcloud config set project PROJECT_ID

# Enable required APIs
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com
gcloud services enable containerregistry.googleapis.com

# Set default region
gcloud config set run/region us-central1
```

## Step 2: Deploy Your App (Single Command)
```bash
# Deploy using Cloud Build (uses your cloudbuild.yaml file)
gcloud builds submit --config=cloudbuild.yaml
```

## Step 3: Get Your Google Cloud URL
```bash
# Get the live URL of your deployed app
gcloud run services describe orb-focus-studio --region=us-central1 --format="value(status.url)"
```

## Alternative: Manual Deployment Commands
If you prefer step-by-step:

```bash
# Build Docker image
docker build -t gcr.io/PROJECT_ID/orb-focus-studio .

# Push to Google Container Registry
docker push gcr.io/PROJECT_ID/orb-focus-studio

# Deploy to Cloud Run
gcloud run deploy orb-focus-studio \
  --image gcr.io/PROJECT_ID/orb-focus-studio \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080 \
  --memory 1Gi \
  --cpu 1 \
  --max-instances 10
```

## Important Notes:
- Replace `PROJECT_ID` with your actual Google Cloud project ID
- Your app files (cloudbuild.yaml, Dockerfile) are already configured
- The deployment will give you a URL like: `https://orb-focus-studio-xxxxx-uc.a.run.app`
- Cost: Usually $0-5/month with free tier covering most usage

## If You Get Quota Errors:
```bash
# Check current quotas
gcloud compute project-info describe --project=PROJECT_ID

# Request quota increase (if needed)
# Go to: https://console.cloud.google.com/iam-admin/quotas
```

Your Orb Focus Studio will be live on Google Cloud with these commands!