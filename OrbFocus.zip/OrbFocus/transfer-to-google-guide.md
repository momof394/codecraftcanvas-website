# Transfer Orb Focus Studio to Google Cloud Platform

## Quick Start Options

### Option 1: Direct Replit Deployment (Easiest)
1. Click "Deploy" button in Replit
2. Choose "Autoscale" deployment type
3. Your app will be automatically deployed to Google Cloud

### Option 2: Export and Manual Deployment

#### Step 1: Download Your Code
```bash
# From Replit terminal, create a downloadable archive
tar -czf orb-focus-studio.tar.gz --exclude=node_modules --exclude=.git --exclude=dist .
```

#### Step 2: Set Up Google Cloud Project
1. Go to https://console.cloud.google.com/
2. Create new project: "Orb Focus Studio"
3. Enable APIs:
   - Cloud Run API
   - Cloud Build API
   - Container Registry API

#### Step 3: Install Google Cloud CLI
Download from: https://cloud.google.com/sdk/docs/install

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
```

#### Step 4: Deploy Using Included Configuration
Your app includes production-ready deployment files:

**Automated Deployment:**
```bash
gcloud builds submit --config=cloudbuild.yaml
```

**Manual Deployment:**
```bash
# Build Docker image
docker build -t gcr.io/YOUR_PROJECT_ID/orb-focus-studio .

# Push to Google Container Registry
docker push gcr.io/YOUR_PROJECT_ID/orb-focus-studio

# Deploy to Cloud Run
gcloud run deploy orb-focus-studio \
  --image gcr.io/YOUR_PROJECT_ID/orb-focus-studio \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080 \
  --memory 1Gi
```

## What's Already Configured

Your app includes these production files:
- ✅ `Dockerfile` - Container configuration
- ✅ `cloudbuild.yaml` - Google Cloud Build setup
- ✅ Health check endpoints at `/health`
- ✅ Production build scripts
- ✅ Proper port configuration (8080)

## Post-Deployment Setup

1. **Custom Domain** (Optional)
   - Map your domain in Cloud Run console
   - Google handles SSL certificates automatically

2. **Environment Variables**
   - Set in Cloud Run console under "Variables & Secrets"
   - No additional variables needed for current setup

3. **Monitoring**
   - Cloud Run provides automatic monitoring
   - View logs and metrics in Google Cloud Console

## Cost Estimation

**Cloud Run Pricing:**
- Free tier: 2 million requests/month
- After free tier: ~$0.40 per million requests
- Memory: ~$0.0000025 per GB-second
- CPU: ~$0.0000240 per vCPU-second

**Estimated monthly cost for small app:** $0-5

## Support Resources

- Google Cloud Run Documentation: https://cloud.google.com/run/docs
- Cloud Build Documentation: https://cloud.google.com/build/docs
- Your app's deployment guide: See DEPLOYMENT.md in project

## Troubleshooting

**Build Failures:**
1. Check `npm run build` works locally
2. Verify all dependencies in package.json
3. Check Cloud Build logs in console

**Deployment Issues:**
1. Verify health endpoint: `curl YOUR_URL/health`
2. Check Cloud Run logs for errors
3. Ensure port 8080 is used (configured automatically)

Your Orb Focus Studio app is production-ready for Google Cloud!