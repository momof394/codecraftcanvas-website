#!/bin/bash

# BodyDouble Orb - Static Deployment Script
# This script builds the application for static hosting

set -e

echo "🌟 Building BodyDouble Orb for static deployment..."

# Clean any existing build
echo "🧹 Cleaning previous build..."
rm -rf dist client/dist

# Build only the frontend (skip server build)
echo "⚡ Building application..."
vite build

# Copy the built files to client/dist for easier deployment
echo "📦 Organizing build files..."
mkdir -p client/dist
cp -r dist/public/* client/dist/

# Check if build was successful
if [ ! -d "client/dist" ]; then
    echo "❌ Build failed - client/dist directory not found"
    exit 1
fi

if [ ! -f "client/dist/index.html" ]; then
    echo "❌ Build failed - index.html not found"
    exit 1
fi

echo "✅ Build completed successfully!"
echo "📁 Static files ready in: client/dist/"
echo ""
echo "🚀 Ready to deploy:"
echo "  • Netlify: Drag and drop the client/dist folder"
echo "  • Vercel: Connect repo and set output to client/dist"
echo "  • GitHub Pages: Upload client/dist contents"
echo "  • Surge.sh: Run 'surge client/dist'"
echo ""
echo "🧪 Test locally:"
echo "  cd client/dist && python3 -m http.server 8080"
echo "  Then visit: http://localhost:8080"